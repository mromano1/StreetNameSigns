@echo off
rem Opens Jupyter's file browser on this folder, so the notebook and the
rem scripts folder are one click away. Run setup.bat once first.
rem Keep this window open while you work; closing it stops the notebook.
setlocal
cd /d "%~dp0"
set "VENV_PY=%~dp0.venv\Scripts\python.exe"

if not exist "%VENV_PY%" (
    echo The notebook isn't set up yet. Double-click setup.bat first.
    pause
    exit /b 1
)

rem Use .venv's own Python kernel even if this computer has another
rem kernel named python3 registered for the user.
set "JUPYTER_PREFER_ENV_PATH=1"
"%VENV_PY%" -m notebook
if errorlevel 1 (
    echo.
    echo Jupyter didn't start. Run setup.bat again, then try again.
    pause
)
