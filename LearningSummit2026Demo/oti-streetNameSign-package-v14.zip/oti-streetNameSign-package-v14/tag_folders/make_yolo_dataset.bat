@echo off
rem Double-click to turn labels.csv here into a YOLO dataset (yolo_dataset\).
rem Run make_labels_csv.bat first. Uses the package's own Python if
rem setup.bat has run, otherwise any Python on this computer.
setlocal
cd /d "%~dp0"
set "VENV_PY=%~dp0..\.venv\Scripts\python.exe"

rem Pick one Python, then run once (an error must not trigger a second run).
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
if exist "%VENV_PY%" set "PY="%VENV_PY%""
%PY% make_yolo_dataset.py
echo.
pause
