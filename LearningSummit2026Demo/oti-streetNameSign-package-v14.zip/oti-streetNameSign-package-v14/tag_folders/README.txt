TAG FOLDERS: folders of images -> a label CSV -> a YOLO dataset
================================================================

Stand-alone and separate from the notebook: plain Python, works for any
labels, not just street signs.

1. Rename the folders tag_1, tag_2 and tag_3 to your labels. Make new
   folders for more labels. The folder name is the label.

   A folder named  background  holds images with none of your labels
   (YOLO learns from these what "nothing here" looks like).

2. Drop your images into the matching folder. Crop each image to one
   object first.

   An image with two labels: put it in a folder named with both, joined
   by "+", for example  cat+dog
   (or copy the same image into both folders; it's merged into one row).

3. Double-click make_labels_csv.bat
   It writes labels.csv here, with two columns:
     filename   the image's path, e.g. cat/photo_01.jpg
     label      its label(s), several joined by ";"

4. Double-click make_yolo_dataset.bat
   It turns labels.csv into a YOLO dataset in yolo_dataset\ (data.yaml,
   images\train, images\val, labels\train, labels\val), holding back about
   20% of each label's images for validation. Train on it with:

     yolo detect train data=yolo_dataset/data.yaml model=yolo26n.pt epochs=30

On a Mac, or from a terminal: python make_labels_csv.py, then
python make_yolo_dataset.py

Notes it may print:
  - a folder still named tag_1 (etc.): rename it, or its images get the
    label "tag_1".
  - a label with fewer than 5 images: all of them go to training, so
    validation has none of that label. Add more images.
