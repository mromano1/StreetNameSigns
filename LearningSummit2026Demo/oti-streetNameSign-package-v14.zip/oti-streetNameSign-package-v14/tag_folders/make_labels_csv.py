"""
Turns folders of images into a label CSV. Stand-alone: plain Python only,
nothing from the rest of this package.

How to use it:
  1. Rename the starter folders tag_1, tag_2, tag_3 to your labels, and make
     more folders for more labels. The folder name is the label.
     A folder named "background" holds images with none of your labels
     (YOLO trains on these as "nothing here").
  2. Put your images in those folders. An image with two labels can go in a
     folder named with both, joined by "+", e.g. "cat+dog". Copying the same
     image into two folders works too; the copies are merged into one row.
  3. Double-click make_labels_csv.bat (or run: python make_labels_csv.py).
     It writes labels.csv here, with two columns:
         filename   the image's path, relative to the CSV
         label      its label(s), several joined by ";"
  4. Then make_yolo_dataset.py turns labels.csv into a YOLO dataset.

Usage:
    python make_labels_csv.py               -> tag_folders/labels.csv
    python make_labels_csv.py --out my.csv  -> a different output file
"""
import argparse
import csv
import hashlib
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_CSV_NAME = "labels.csv"
COLUMNS = ["filename", "label"]
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
TAG_SEPARATORS = ("+", ";")  # in a folder name; the CSV always uses ";"
BACKGROUND = "background"
STARTER_NAME = re.compile(r"tag_\d+", re.IGNORECASE)  # the package ships tag_1, tag_2, tag_3
SKIP_FOLDERS = {"yolo_dataset"}  # make_yolo_dataset.py's output


def folder_labels(folder_name):
    """'Cat + Dog' -> ['cat', 'dog']."""
    raw = folder_name.strip().lower()
    for sep in TAG_SEPARATORS[1:]:
        raw = raw.replace(sep, TAG_SEPARATORS[0])
    labels = []
    for part in raw.split(TAG_SEPARATORS[0]):
        part = " ".join(part.split())
        if part and part not in labels:
            labels.append(part)
    return labels


def file_hash(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def collect(root):
    """Returns (images, notes). images maps a file hash to
    {"path": first copy found, "labels": merged labels}."""
    images = {}
    notes = []
    folders = sorted(d for d in root.iterdir()
                     if d.is_dir() and d.name not in SKIP_FOLDERS and not d.name.startswith((".", "_")))
    for folder in folders:
        found = sorted(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES)
        if not found:
            continue  # unused starter folder
        if STARTER_NAME.fullmatch(folder.name):
            notes.append(f"folder '{folder.name}' still has its starter name, so its images are labeled "
                         f"'{folder.name}'; rename it to the label you mean")
        labels = folder_labels(folder.name)
        if BACKGROUND in labels and len(labels) > 1:
            notes.append(f"folder '{folder.name}': '{BACKGROUND}' can't be combined with other labels, skipped")
            continue
        for image in found:
            entry = images.setdefault(file_hash(image), {"path": image, "labels": []})
            for label in labels:
                if label not in entry["labels"]:
                    entry["labels"].append(label)
    for entry in images.values():
        if BACKGROUND in entry["labels"] and len(entry["labels"]) > 1:
            notes.append(f"{entry['path'].name} is in a '{BACKGROUND}' folder and a labeled folder; "
                         f"kept the label(s)")
            entry["labels"].remove(BACKGROUND)
    return images, notes


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--folder", type=Path, default=HERE, help="folder holding the label folders (default: this one)")
    parser.add_argument("--out", type=Path, default=None, help=f"CSV to write (default: {DEFAULT_CSV_NAME} in --folder)")
    args = parser.parse_args()
    root = args.folder.resolve()
    out = (args.out or root / DEFAULT_CSV_NAME).resolve()

    images, notes = collect(root)
    if not images:
        raise SystemExit(f"No images found in label folders under {root}. "
                         f"Rename tag_1 (etc.) to a label and put images in it.")

    counts = {}
    with open(out, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        for entry in sorted(images.values(), key=lambda e: str(e["path"]).lower()):
            path = entry["path"]
            try:
                filename = path.relative_to(out.parent).as_posix()
            except ValueError:
                filename = str(path)
            writer.writerow({"filename": filename, "label": ";".join(entry["labels"])})
            for label in entry["labels"]:
                counts[label] = counts.get(label, 0) + 1

    print(f"Wrote {len(images)} images to {out}")
    for label, n in sorted(counts.items()):
        print(f"    {label}: {n}")
    for note in notes:
        print("  note:", note)


if __name__ == "__main__":
    main()
