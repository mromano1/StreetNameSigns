@echo off
rem Double-click to turn the tag folders here into labels.csv.
rem Uses the package's own Python if setup.bat has run, otherwise any Python
rem on this computer (the script needs nothing beyond plain Python).
setlocal
cd /d "%~dp0"
set "VENV_PY=%~dp0..\.venv\Scripts\python.exe"

rem Pick one Python, then run once (an error must not trigger a second run).
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
if exist "%VENV_PY%" set "PY="%VENV_PY%""
%PY% make_labels_csv.py
echo.
pause
