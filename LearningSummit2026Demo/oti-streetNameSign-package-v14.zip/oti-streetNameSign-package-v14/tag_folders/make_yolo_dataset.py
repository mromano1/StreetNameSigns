"""
Turns labels.csv (from make_labels_csv.py) into a YOLO detection dataset.
Stand-alone: plain Python only, nothing from the rest of this package. A
general-label copy of the package's scripts/prepare_yolo_dataset_physical.py.

  How it works: load_rows() reads the CSV and skips anything unusable
  (missing image, blank label, duplicate); split_rows() holds back 20% of
  each label for validation; write_split() copies the images and writes one
  box per label covering 90% of the image, since each image is assumed to
  be cropped to one object. data.yaml lists the labels as class names.

Output (in tag_folders/yolo_dataset/, rebuilt from scratch on every run):
    data.yaml
    images/train  images/val
    labels/train  labels/val

Train on it with Ultralytics, e.g.:
    yolo detect train data=yolo_dataset/data.yaml model=yolo26n.pt epochs=30

Usage:
    python make_yolo_dataset.py                    -> reads labels.csv here
    python make_yolo_dataset.py --csv my.csv --out my_dataset
"""
import argparse
import csv
import json
import random
import shutil
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_CSV = HERE / "labels.csv"
DEFAULT_OUT = HERE / "yolo_dataset"
BACKGROUND = "background"  # an image with no label: kept, with an empty label file

# Every label is the same near-full-image box. The images are already
# cropped to one object, so only the class carries information.
BBOX_CENTER = (0.5, 0.5)
BBOX_SIZE = (0.9, 0.9)

VAL_FRACTION = 0.2
MIN_FOR_VAL_SPLIT = 5  # a label with fewer images goes entirely to train
SEED = 42


def load_rows(csv_path):
    """Returns (rows, warnings). rows is a list of (image_path, labels);
    labels is [] for a background image. Images are looked up next to the
    CSV unless the filename is a full path."""
    rows = []
    warnings = []
    seen = set()
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            filename = (row.get("filename") or "").strip()
            raw = (row.get("label") or "").strip()
            image_path = csv_path.parent / filename
            if not image_path.exists():
                warnings.append(f"row for missing file, skipped: {filename}")
                continue
            if filename in seen:
                warnings.append(f"duplicate row, skipped: {filename}")
                continue
            seen.add(filename)
            if not raw:
                warnings.append(f"blank label, skipped: {filename}")
                continue
            labels = []
            for label in (t.strip() for t in raw.split(";")):
                if label and label != BACKGROUND and label not in labels:
                    labels.append(label)
            rows.append((image_path, labels))
    return rows, warnings


def split_rows(rows):
    """Splits so every label gets its share of validation images.
    Rarest label first, so scarce labels get first pick of the val budget
    before a more common label that shares images with them."""
    by_label = defaultdict(list)
    for idx, (_image_path, labels) in enumerate(rows):
        for label in (labels or [BACKGROUND]):
            by_label[label].append(idx)

    rng = random.Random(SEED)
    assigned = {}  # idx -> "train" | "val"
    for label in sorted(by_label, key=lambda l: len(by_label[l])):
        indices = by_label[label]
        if len(indices) < MIN_FOR_VAL_SPLIT:
            print(f"  '{label}': only {len(indices)} image(s), all going to train, val will have 0.")
            for idx in indices:
                assigned.setdefault(idx, "train")
            continue
        already_val = sum(1 for idx in indices if assigned.get(idx) == "val")
        target_val = max(1, round(len(indices) * VAL_FRACTION))
        unassigned = [idx for idx in indices if idx not in assigned]
        rng.shuffle(unassigned)
        slots = max(0, target_val - already_val)
        for idx in unassigned[:slots]:
            assigned[idx] = "val"
        for idx in unassigned[slots:]:
            assigned[idx] = "train"

    train = [rows[i] for i in range(len(rows)) if assigned.get(i, "train") == "train"]
    val = [rows[i] for i in range(len(rows)) if assigned.get(i) == "val"]
    return train, val


def write_split(name, items, class_ids, out_dir):
    img_dir = out_dir / "images" / name
    lbl_dir = out_dir / "labels" / name
    img_dir.mkdir(parents=True)
    lbl_dir.mkdir(parents=True)

    counts = defaultdict(int)
    used_names = set()
    for image_path, labels in items:
        # Two folders can each hold an image with the same file name; give
        # the second a numbered name so it doesn't overwrite the first.
        stem, suffix, n = image_path.stem, image_path.suffix, 1
        while f"{stem}{suffix}".lower() in used_names:
            n += 1
            stem = f"{image_path.stem}_{n}"
        used_names.add(f"{stem}{suffix}".lower())
        shutil.copy2(image_path, img_dir / f"{stem}{suffix}")
        cx, cy = BBOX_CENTER
        w, h = BBOX_SIZE
        lines = [f"{class_ids[label]} {cx} {cy} {w} {h}" for label in labels]
        (lbl_dir / f"{stem}.txt").write_text("\n".join(lines) + ("\n" if lines else ""))
        for label in (labels or [BACKGROUND]):
            counts[label] += 1

    print(f"{name}: {len(items)} images")
    for label, count in sorted(counts.items()):
        print(f"    {label}: {count}")


def write_data_yaml(out_dir, class_names):
    lines = [f"path: {out_dir.as_posix()}", "train: images/train", "val: images/val", "", "names:"]
    lines += [f"  {i}: {json.dumps(name)}" for i, name in enumerate(class_names)]
    (out_dir / "data.yaml").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--csv", type=Path, default=DEFAULT_CSV, help="labels CSV (default: labels.csv here)")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="dataset folder to (re)build (default: yolo_dataset here)")
    args = parser.parse_args()
    csv_path = args.csv.resolve()
    out_dir = args.out.resolve()
    if not csv_path.exists():
        raise SystemExit(f"{csv_path} not found. Run make_labels_csv.py first.")

    rows, warnings = load_rows(csv_path)
    for w in warnings:
        print("  skipped:", w)
    if not rows:
        raise SystemExit("No usable rows in the CSV. Nothing to write.")
    class_names = sorted({label for _path, labels in rows for label in labels})
    if not class_names:
        raise SystemExit(f"Every image is '{BACKGROUND}'. YOLO needs at least one real label.")

    print(f"{len(rows)} images, {len(class_names)} labels: {', '.join(class_names)}")
    print(f"Splitting (a label needs >= {MIN_FOR_VAL_SPLIT} images to get validation images):")
    train, val = split_rows(rows)

    if out_dir.exists():
        shutil.rmtree(out_dir)
    print()
    write_split("train", train, {name: i for i, name in enumerate(class_names)}, out_dir)
    write_split("val", val, {name: i for i, name in enumerate(class_names)}, out_dir)
    write_data_yaml(out_dir, class_names)
    if not val:
        print("\nNote: no validation images (every label has fewer than "
              f"{MIN_FOR_VAL_SPLIT}). Add images, or YOLO has nothing to score on.")
    print(f"\nDone. YOLO dataset written to {out_dir}")
    print(f"Train with:  yolo detect train data=\"{(out_dir / 'data.yaml').as_posix()}\" model=yolo26n.pt")


if __name__ == "__main__":
    main()
