The notebook saves its model reports (HTML) and broken-signs CSVs here.
