"""
Finds the real compass bearing of the street a sign/corner sits on, by
looking up the nearest LION (NYC's street centerline geodatabase) node
and matching one of its street segments by name. data/lion_corners.json
already stores, per node, a `segments` list of real {street, bearing_deg}
pairs -- see import_lion_corners.py for how that file gets built.

Used by cyclomedia_client.find_best_recording's street_bearing_deg
parameter to score how perpendicular a candidate recording's approach
angle is to the sign's own street, rather than just picking whatever's
closest -- see docs/superpowers/specs/2026-09-18-cyclomedia-best-
recording-scoring-design.md for why raw distance alone doesn't predict
sign legibility.

Usage:
    import lion_bearing_lookup as lion
    corners = lion.load_lion_corners()
    bearing = lion.nearest_street_bearing(40.70, -73.99, "MAIN STREET", corners)
"""
import json
from pathlib import Path

import paths

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_LION_CORNERS_PATH = paths.lion_corners()


def load_lion_corners(path=DEFAULT_LION_CORNERS_PATH):
    """Loads the whole lion_corners.json file (90,814 nodes in the real
    project data) as a plain list of dicts -- no filtering, since which
    subset is relevant depends entirely on the caller's own search area."""
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def nearest_street_bearing(lat, lon, on_street, lion_corners):
    """Finds the LION node nearest (lat, lon) -- a plain linear scan over
    lion_corners, since callers are expected to have already narrowed it
    to a local bounding-box subset rather than passing all 90,814 real
    nodes (a per-corner linear scan of the full file was fast enough for
    this design's own 538-corner cb211 validation, but a real caller
    iterating many corners should filter once up front, not per corner).
    Among that node's segments, returns the bearing_deg of the one whose
    street name matches on_street: exact match first (case-insensitive),
    then substring match either direction as a fallback for minor SIMS/
    LION naming differences (e.g. "MAIN ST" vs "MAIN STREET"). Returns
    None if lion_corners is empty or no segment's street matches at all
    -- the caller decides whether that's acceptable. Note that
    find_best_recording requires a real float for its street_bearing_deg
    parameter and will raise TypeError if passed None directly; it has
    no distance-only fallback for a no-LION-match corner today. Wiring
    up such a fallback (or otherwise handling a None return here) is an
    open item for a future integration effort, not something already
    implemented."""
    best_node, best_d2 = None, None
    for node in lion_corners:
        d2 = (node["lat"] - lat) ** 2 + (node["lon"] - lon) ** 2
        if best_d2 is None or d2 < best_d2:
            best_d2, best_node = d2, node
    if best_node is None:
        return None

    target = (on_street or "").strip().upper()
    for seg in best_node["segments"]:
        if seg["street"].strip().upper() == target:
            return seg["bearing_deg"]
    for seg in best_node["segments"]:
        seg_street = seg["street"].strip().upper()
        if target and (target in seg_street or seg_street in target):
            return seg["bearing_deg"]
    return None
