"""
Where to point the camera for each SIMS sign at an intersection (retrieval v3).

SIMS has no pole positions: every street-name sign's x/y is the intersection
point, and only sign_location ("N/E C", "S MEDIAN", ...) says where around the
intersection it stands. This module turns that label plus the LION legs of the
intersection (intersection_classifier.py) into a target point on the ground:

  corner / apex   where the two curb lines bounding that corner cross. Each curb
                  line is its street's centerline offset by half the curb-to-curb
                  width (LION StreetWidth_Max). A divided street has no width on
                  its generic centerline, so its curb is the near roadbed (LION
                  RB_Layer R) centerline offset plus half that roadbed's width.
  curb            the curb on that side of the intersection, where the street
                  running across that side meets the label's direction.
  top of T        the through street's far curb, opposite the stub.
  median          on the divided street's centerline, past the cross street's
                  curb and crosswalk (the median nose).
  mall / island / center-mall (CML)
                  a point on that side, wide shot only (no reliable geometry).

Then choose_recording() picks a Cyclomedia recording 5-12 m from the target
(preferring one between the target and the intersection's middle, so the camera
looks out at the corner diagonally), and pitch_deg() tilts the zoom up to sign
height from the camera's ground-level offset (a render response header).

Phase 0 (2026-10-05, Board 10): the curb-crossing corner put the camera 7-8 m
from the corner and the 55 deg tilted zoom read 8/10 previously unreadable
corners; median zooms read 4/4; at complex intersections (diagonals, ramps,
5-way splits) the corner model hit 1/11, so complex targets ask for a
detection-based zoom (detect_zoom.py) instead of a geometric one.

All geometry is EPSG:2263 (NY State Plane, US feet; x east, y north), bearings
are compass degrees (0 = north, clockwise).
"""
import math
import re

import cyclomedia_client as cc

FT_PER_M = 3.280833333
SIGN_CENTER_HEIGHT_M = 4.05     # street-name plate centre above ground
BEHIND_CURB_M = 0.7             # poles stand a little behind the curb line
DEFAULT_STREET_WIDTH_FT = 30.0  # when LION has no width for a single-centerline leg
DIVIDED_FALLBACK_HALF_FT = 40.0  # divided leg with no roadbed found nearby
ROADBED_SEARCH_FT = 200.0
FAR_CURB_WEDGE_DEG = 150.0      # a "corner" this open has no cross street: use the far curb
# Past the cross street's curb. Phase 0 used 1.5 m and read 4/4 median signs
# (about 25% off-centre); 4.5 m was tried live 2026-10-05 and moved one of two
# closer to centre and the other further off, so 1.5 m stays.
MEDIAN_NOSE_BEYOND_CURB_M = 1.5

COMPASS = {"N": 0, "NE": 45, "E": 90, "SE": 135, "S": 180, "SW": 225, "W": 270, "NW": 315}
OPPOSITE = {"NE": "SW", "SW": "NE", "NW": "SE", "SE": "NW"}
_SUFFIX_KIND = {"MEDIAN": "median", "APEX": "apex", "MALL": "mall", "ISL": "island", "CML": "cml",
                "CURB": "curb"}


def parse_sign_location(loc):
    """(kind, label) for a SIMS sign_location, or None when it says nothing
    usable about where the sign stands ("*NOTE", "N WSD", blank).

    "OPP N/E C" is read as the opposite corner (S/W): the sign faces the
    labelled corner from across the intersection. "X CURB" is the curb on
    that side of the intersection (not a corner). "CEN MED" is a median with
    no side (the median through the middle of the intersection)."""
    s = " ".join((loc or "").upper().split())
    if not s:
        return None
    m = re.fullmatch(r"(OPP )?([NS])/([EW]) C", s)
    if m:
        label = m.group(2) + m.group(3)
        return ("corner", OPPOSITE[label] if m.group(1) else label)
    if s == "TOP OF T":
        return ("top_of_t", None)
    if s == "CEN MED":
        return ("median", None)
    m = re.fullmatch(r"(N|S|E|W|NE|NW|SE|SW) (MEDIAN|APEX|MALL|ISL|CML|CURB)", s)
    if m:
        return (_SUFFIX_KIND[m.group(2)], m.group(1))
    return None


def _unit(bearing):
    return math.sin(math.radians(bearing)), math.cos(math.radians(bearing))


def _angdiff(a, b):
    return abs((a - b + 180) % 360 - 180)


def _nearest_on_polyline(xy, p):
    best, best_d = None, None
    for (x1, y1), (x2, y2) in zip(xy, xy[1:]):
        dx, dy = x2 - x1, y2 - y1
        L2 = dx * dx + dy * dy
        t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - x1) * dx + (p[1] - y1) * dy) / L2))
        q = (x1 + t * dx, y1 + t * dy)
        d = math.dist(q, p)
        if best_d is None or d < best_d:
            best, best_d = q, d
    return best, best_d


def leg_width(leg):
    """Curb-to-curb width (ft) of a leg: intersection_classifier legs carry
    LION's width as width_max (the Phase 0 prototype called it wmax)."""
    return leg.get("width_max") or leg.get("wmax") or DEFAULT_STREET_WIDTH_FT


def half_width(leg, normal, node_xy, roadbeds=()):
    """Distance (ft) from the leg's centerline to its curb on the side `normal`
    (a unit vector) points to."""
    if not leg.get("divided"):
        return leg_width(leg) / 2
    best = None
    ux, uy = _unit(leg["bearing"])
    for rb in roadbeds:
        if rb.get("street") != leg["street"] or len(rb.get("xy") or []) < 2:
            continue
        q, d = _nearest_on_polyline(rb["xy"], node_xy)
        if d > ROADBED_SEARCH_FT:
            continue
        dx, dy = q[0] - node_xy[0], q[1] - node_xy[1]
        if dx * ux + dy * uy < -20:  # a roadbed of the street's other half
            continue
        off = dx * normal[0] + dy * normal[1]
        if off <= 0:
            continue
        h = off + (rb.get("width_max") or DEFAULT_STREET_WIDTH_FT) / 2
        best = h if best is None else max(best, h)
    return best if best is not None else DIVIDED_FALLBACK_HALF_FT


def _vehicular(legs):
    return [l for l in legs if l.get("vehicular", True)]


def _far_curb(leg, node_xy, bearing, roadbeds):
    """Point where a ray from the node along `bearing` meets `leg`'s curb."""
    lu = _unit(leg["bearing"])
    n = (lu[1], -lu[0])
    bu = _unit(bearing)
    if n[0] * bu[0] + n[1] * bu[1] < 0:
        n = (-n[0], -n[1])
    h = half_width(leg, n, node_xy, roadbeds)
    s = max(math.sin(math.radians(_angdiff(bearing, leg["bearing"]))), 0.3)
    d = h / s
    return node_xy[0] + bu[0] * d, node_xy[1] + bu[1] * d


def _across_from_stub(through, others, node_xy, label_bearing, roadbeds):
    """A "corner" on the far side of a T: the through street's far curb, right
    across from the stub, shifted toward the label's side by half the stub's
    width (where the sign pole stands). Not a ray along the label bearing: on
    a rotated grid (Manhattan, about 29 deg) a compass label runs nearly
    parallel to the avenue and that ray met the curb far up the block."""
    lu = _unit(through["bearing"])
    n = (lu[1], -lu[0])
    bu = _unit(label_bearing)
    if n[0] * bu[0] + n[1] * bu[1] < 0:
        n = (-n[0], -n[1])
    h = half_width(through, n, node_xy, roadbeds)
    lean = lu[0] * bu[0] + lu[1] * bu[1]
    along = (0.0, 0.0) if abs(lean) < 0.1 else (lu if lean > 0 else (-lu[0], -lu[1]))  # straight across: no shift
    stub_half = max((leg_width(o) / 2 for o in others), default=DEFAULT_STREET_WIDTH_FT / 2)
    return (node_xy[0] + n[0] * h + along[0] * stub_half,
            node_xy[1] + n[1] * h + along[1] * stub_half)


def corner_point(legs, node_xy, label_bearing, roadbeds=()):
    """Curb corner in the wedge of legs holding label_bearing."""
    # >>> OTI CORE: where the sign probably stands (SIMS has no pole x/y) -----
    # Take the two streets on either side of the sign_location's direction
    # (e.g. NE). Shift each street's centerline out by half its width (LION)
    # to get its curb line; the sign is where the two curb lines cross.
    vlegs = _vehicular(legs)
    a = min(vlegs, key=lambda l: (label_bearing - l["bearing"]) % 360)  # counter-clockwise side
    b = min(vlegs, key=lambda l: (l["bearing"] - label_bearing) % 360)  # clockwise side
    wedge = (b["bearing"] - a["bearing"]) % 360
    if a is b:
        return _far_curb(a, node_xy, label_bearing, roadbeds)
    if wedge > FAR_CURB_WEDGE_DEG:
        return _across_from_stub(a, [l for l in vlegs if l is not a and l is not b], node_xy,
                                 label_bearing, roadbeds)
    ua, ub = _unit(a["bearing"]), _unit(b["bearing"])
    na = (ua[1], -ua[0])   # a rotated clockwise: into the wedge
    nb = (-ub[1], ub[0])   # b rotated counter-clockwise: into the wedge
    ha, hb = half_width(a, na, node_xy, roadbeds), half_width(b, nb, node_xy, roadbeds)
    det = na[0] * nb[1] - na[1] * nb[0]
    return (node_xy[0] + (ha * nb[1] - hb * na[1]) / det,
            node_xy[1] + (na[0] * hb - nb[0] * ha) / det)
    # <<< OTI CORE end ---------------------------------------------------------


def median_point(legs, node_xy, label_bearing, roadbeds=()):
    """Median nose: on the centerline of the (divided) leg nearest the label,
    past the cross street's curb and crosswalk. CEN MED (label None) is the
    intersection's middle."""
    if label_bearing is None:
        return node_xy
    vlegs = _vehicular(legs)
    div = [l for l in vlegs if l.get("divided")] or vlegs
    leg = min(div, key=lambda l: _angdiff(l["bearing"], label_bearing))
    cross = [l for l in vlegs if l["street"] != leg["street"]]
    hcross = max((leg_width(l) / 2 for l in cross), default=15.0)
    d = hcross + MEDIAN_NOSE_BEYOND_CURB_M * FT_PER_M
    ux, uy = _unit(leg["bearing"])
    return node_xy[0] + ux * d, node_xy[1] + uy * d


def _curb_point(legs, node_xy, label_bearing, roadbeds):
    across = min(_vehicular(legs), key=lambda l: abs(_angdiff(l["bearing"], label_bearing) - 90))
    return _far_curb(across, node_xy, label_bearing, roadbeds)


def _top_of_t_point(legs, node_xy, roadbeds):
    vlegs = _vehicular(legs)
    stubs = [l for l in vlegs if all(_angdiff(l["bearing"], o["bearing"]) < 145 for o in vlegs if o is not l)]
    if len(stubs) != 1:
        return None
    stub = stubs[0]
    through = min((l for l in vlegs if l is not stub), key=lambda l: abs(_angdiff(l["bearing"], stub["bearing"]) - 90))
    return _far_curb(through, node_xy, (stub["bearing"] + 180) % 360, roadbeds)


def targets_for_corner(class_row, sign_locations, node_xy, roadbeds=()):
    """Distinct aiming targets for one SIMS corner record, in the order their
    labels first appear. Each: kind, label, sign_locations (sorted, the SIMS
    values it covers), xy (EPSG:2263), method, zoom ("geometric" = aim the
    tilted 55 deg zoom at xy, "detect" = zoom on spatial-model detections in
    the wide shot, "none" = wide shot only)."""
    legs = class_row.get("legs") or []
    complex_ix = class_row.get("class") in ("complex", "no-match")
    found = {}
    for loc in sign_locations:
        parsed = parse_sign_location(loc)
        if not parsed or not _vehicular(legs):
            continue
        key = parsed
        if key in found:
            found[key]["sign_locations"].add(loc)
            continue
        kind, label = parsed
        bearing = COMPASS.get(label)
        if kind in ("corner", "apex"):
            xy, method = corner_point(legs, node_xy, bearing, roadbeds), "curb x curb"
            zoom = "detect" if complex_ix else "geometric"
        elif kind == "curb":
            xy, method = _curb_point(legs, node_xy, bearing, roadbeds), "curb on that side"
            zoom = "detect" if complex_ix else "geometric"
        elif kind == "top_of_t":
            xy = _top_of_t_point(legs, node_xy, roadbeds)
            method, zoom = "far curb opposite the stub", "geometric"
            if xy is None:
                xy, method, zoom = node_xy, "no single stub found", "detect"
        elif kind == "median":
            xy, method, zoom = median_point(legs, node_xy, bearing, roadbeds), "median nose", "geometric"
        else:  # mall, island, center mall
            xy, method, zoom = _curb_point(legs, node_xy, bearing, roadbeds), f"{kind} side (wide only)", "none"
        found[key] = {"kind": kind, "label": label, "sign_locations": {loc}, "xy": xy,
                      "method": method, "zoom": zoom}
    out = []
    for t in found.values():
        t["sign_locations"] = sorted(t["sign_locations"])
        out.append(t)
    return out


def choose_recording(target_ll, node_ll, recordings, lo=5.0, hi=12.0):
    """The recording to shoot a target from: lo-hi metres away, preferring one
    on the intersection's side of the target (within 60 deg of the direction
    target -> intersection middle, so it looks out at the corner), then
    closest to 8 m, then most head-on. Returns the recording dict plus
    dist_m, off_inward_deg and heading (camera -> target), or None."""
    # >>> OTI CORE: which panorama (v3 board pulls) ------------------------------
    # Candidates 5-12 m from the sign's estimated spot. Ranked by: on the
    # intersection's side of the spot (looking out at the corner) first, then
    # closest to 8 m, then most head-on. Heading = camera -> spot.
    tlat, tlon = target_ll
    inward = cc.bearing_deg(tlat, tlon, node_ll[0], node_ll[1])
    cands = []
    for r in recordings:
        if r.get("lat") is None:
            continue
        d = cc.haversine_meters(tlat, tlon, r["lat"], r["lon"])
        if not lo <= d <= hi:
            continue
        off = _angdiff(cc.bearing_deg(tlat, tlon, r["lat"], r["lon"]), inward)
        cands.append((off > 60, abs(d - 8), off, d, r))
    if not cands:
        return None
    _, _, off, d, r = min(cands, key=lambda c: c[:3])
    return dict(r, dist_m=round(d, 2), off_inward_deg=round(off, 1),
                heading=cc.bearing_deg(r["lat"], r["lon"], tlat, tlon))
    # <<< OTI CORE end ---------------------------------------------------------


def pitch_deg(ground_offset_m, dist_m, sign_height_m=SIGN_CENTER_HEIGHT_M, behind_curb_m=0.0):
    """Tilt (degrees, up positive) from a camera ground_offset_m above the
    ground to a sign sign_height_m up, dist_m + behind_curb_m away."""
    # >>> OTI CORE: tilt the zoom up to the sign (4.05 m plate height) ---------
    return round(math.degrees(math.atan2(sign_height_m - ground_offset_m, dist_m + behind_curb_m)), 1)
    # <<< OTI CORE end ---------------------------------------------------------


_TO_LL = None
_TO_XY = None


def xy_to_latlon(x, y):
    global _TO_LL
    if _TO_LL is None:
        from pyproj import Transformer
        _TO_LL = Transformer.from_crs("EPSG:2263", "EPSG:4326", always_xy=True)
    lon, lat = _TO_LL.transform(x, y)
    return lat, lon


def latlon_to_xy(lat, lon):
    global _TO_XY
    if _TO_XY is None:
        from pyproj import Transformer
        _TO_XY = Transformer.from_crs("EPSG:4326", "EPSG:2263", always_xy=True)
    return _TO_XY.transform(lon, lat)
