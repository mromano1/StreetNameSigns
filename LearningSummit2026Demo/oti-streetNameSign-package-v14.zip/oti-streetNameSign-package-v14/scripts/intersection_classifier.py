"""
Classifies every SIMS intersection by its LION topology and stores the result in
signs.db (table intersection_classes, read through the v_intersections view).

Why: SIMS gives no pole positions, only the intersection point and a corner label,
so how photos should be aimed depends on what kind of intersection it is. DOT's own
types (Karim's 6/10 notes) are 4-leg, dog-leg, T, and "complicated" (don't look for
missing signs there).

How: works on LION's generic centerline graph (RB_Layer B or G), which has one node
per intersection even where a divided street has two roadbeds (the R segments are
ignored here). Legs are the street segments touching the node, after merging nodes
joined by very short vehicular links (a traffic-triangle split drawn as two nodes).

Classes:
  4-leg      two streets crossing, both continuing through
  T          one street ends at the other
  dog-leg    a T whose cross street (same name) continues from another T on the
             other side of the through street within DOGLEG_FT (an offset
             intersection)
  complex    5+ legs, 3+ vehicular streets, a Y (3 legs, none straight), a 4-leg
             without two straight pairs, or a 2-leg bend
  no-match   no LION node joining the two SIMS streets near the SIMS point
Flags: divided_streets (legs that are generic centerlines of divided streets),
skew_deg (90 = square crossing), ped_legs (paths / non-vehicular legs present),
name_mismatch (matched on one street name only; LION calls the other leg something
else, e.g. LENOX AVENUE vs ESPLANADE GARDENS PLAZA).

Reads data/lion_network.db (built by import_lion_network.py with the sds env); this
module itself needs no fiona.

Usage:
    python intersection_classifier.py --board cb110
    python intersection_classifier.py --all
"""
import argparse
import json
import math
import re
import sqlite3
import time
from collections import Counter, defaultdict

import paths
import signs_db

CLASSIFIER_VERSION = "1"
SEARCH_FT = 300          # how far from the SIMS point a matching node may be
MISMATCH_SEARCH_FT = 120  # tighter radius when only one street name matches
MERGE_FT = 60            # vehicular links shorter than this are internal to one intersection
DOGLEG_FT = 220          # max offset between the two halves of a dog-leg
DOGLEG_MAX_HOPS = 4      # 2-leg shape nodes walked through while looking for the other half
STRAIGHT_DEG = 35        # two legs within this of 180 deg apart are one street passing through
BOARD_MARGIN_FT = 1500   # LION loaded around a board's corners
GENERIC_LAYERS = ("B", "G")
VEHICULAR_RW = {"1", "2", "3", "4", "9", "13"}
VEHICULAR_FEATURES = {"0", "6", "C"}
PED_WORDS = ("PEDESTRIAN", " PATH", "WALKWAY", "GREENWAY", "STEP STREET")
_GRID_CELL_FT = 500

_WORD_ABBREVIATIONS = {
    "AVENUE": "AV", "STREET": "ST", "BOULEVARD": "BL", "PLACE": "PL", "ROAD": "RD",
    "DRIVE": "DR", "PARKWAY": "PKWY", "TERRACE": "TER", "EAST": "E", "WEST": "W",
    "NORTH": "N", "SOUTH": "S", "SAINT": "ST", "JUNIOR": "JR",
}


# --- street names -------------------------------------------------------------

def norm_street(name):
    """Upper case, punctuation and repeated spaces dropped, common words
    abbreviated, ordinal suffixes dropped (116TH -> 116)."""
    s = re.sub(r"[^A-Z0-9 ]", " ", (name or "").upper())
    s = " ".join(_WORD_ABBREVIATIONS.get(w, w) for w in s.split())
    return re.sub(r"\b(\d+)(ST|ND|RD|TH)\b", r"\1", s)


def names_match(a, b):
    """Loose street-name match: numbers must agree, words may be abbreviated or
    misspelled at the end (ADAM C POWELL ~ ADAM CLAYTON POWELL JR,
    FRED DOUGLAS ~ FREDERICK DOUGLASS)."""
    a, b = norm_street(a), norm_street(b)
    if not a or not b:
        return False
    if a == b or a in b or b in a:
        return True
    ta, tb = a.split(), b.split()
    if [t for t in ta if t.isdigit()] != [t for t in tb if t.isdigit()]:
        return False
    short, long_left = (ta, list(tb)) if len(ta) <= len(tb) else (tb, list(ta))
    for t in short:
        hit = next((u for u in long_left if u == t or u.startswith(t) or t.startswith(u)), None)
        if hit is None:
            return False
        long_left.remove(hit)
    return True


def street_key(name):
    """E 116 ST and W 116 ST are one street crossing an avenue."""
    return re.sub(r"^(E|W|N|S) ", "", norm_street(name))


# --- geometry helpers -----------------------------------------------------------

def _angdiff(a, b):
    d = abs(a - b) % 360
    return min(d, 360 - d)


def _length(xy):
    return sum(math.dist(p, q) for p, q in zip(xy, xy[1:]))


def _bearing_from(xy, node_xy):
    """Bearing (deg, 0 = north, clockwise) leaving node_xy along the segment,
    measured to the first vertex at least 20 ft out for a stable direction."""
    seq = xy if math.dist(xy[0], node_xy) <= math.dist(xy[-1], node_xy) else xy[::-1]
    start, pt = seq[0], seq[-1]
    for p in seq[1:]:
        if math.dist(p, start) >= 20:
            pt = p
            break
    return (math.degrees(math.atan2(pt[0] - start[0], pt[1] - start[1])) + 360) % 360


def _side_of(through_bearing, bearing):
    """+1 if bearing points to the right of the through direction, -1 left."""
    return 1 if 0 < (bearing - through_bearing) % 360 < 180 else -1


def is_vehicular(segment):
    return (segment["feature_type"] in VEHICULAR_FEATURES and segment["rw_type"] in VEHICULAR_RW
            and not any(w in segment["street"] for w in PED_WORDS))


def _shape(vlegs):
    """(class, straight pairs as index tuples, skew_deg) from vehicular legs alone."""
    pairs, used = [], set()
    candidates = sorted(
        (_angdiff(_angdiff(a["bearing"], b["bearing"]), 180), i, j)
        for i, a in enumerate(vlegs) for j, b in enumerate(vlegs) if i < j)
    for deviation, i, j in candidates:
        if deviation <= STRAIGHT_DEG and i not in used and j not in used:
            pairs.append((i, j))
            used |= {i, j}
    if len(vlegs) == 4 and len(pairs) == 2:
        d = _angdiff(vlegs[pairs[0][0]]["bearing"], vlegs[pairs[1][0]]["bearing"])
        return "4-leg", pairs, round(min(d, 180 - d))
    if len(vlegs) == 3 and len(pairs) == 1:
        stub = vlegs[_stub_index(pairs[0])]["bearing"]
        d = _angdiff(stub, vlegs[pairs[0][0]]["bearing"])
        return "T", pairs, round(min(d, 180 - d))
    return "complex", pairs, None


def _stub_index(pair):
    return ({0, 1, 2} - set(pair)).pop()


# --- the network ----------------------------------------------------------------

class Network:
    """LION street segments (dicts with street, feature_type, rb_layer, rw_type,
    node_from, node_to, xy, width_max) indexed for classification."""

    def __init__(self, segments):
        self.segments = list(segments)
        self.node_segs = defaultdict(list)
        self.node_xy = {}
        for s in self.segments:
            if s["rb_layer"] not in GENERIC_LAYERS or not s["xy"]:
                continue
            self.node_segs[s["node_from"]].append(s)
            self.node_segs[s["node_to"]].append(s)
            self.node_xy.setdefault(s["node_from"], tuple(s["xy"][0]))
            self.node_xy.setdefault(s["node_to"], tuple(s["xy"][-1]))
        self._grid = defaultdict(list)
        for nid, (x, y) in self.node_xy.items():
            self._grid[(int(x // _GRID_CELL_FT), int(y // _GRID_CELL_FT))].append(nid)

    def nodes_near(self, x, y, radius):
        """[(distance_ft, node_id)] within radius, nearest first."""
        out = []
        c = _GRID_CELL_FT
        for i in range(int((x - radius) // c), int((x + radius) // c) + 1):
            for j in range(int((y - radius) // c), int((y + radius) // c) + 1):
                for nid in self._grid.get((i, j), ()):
                    d = math.dist(self.node_xy[nid], (x, y))
                    if d <= radius:
                        out.append((d, nid))
        return sorted(out)

    def cluster(self, node_id):
        """(nodes, internal segment ids): node_id plus every node joined to it
        by short vehicular links, i.e. one physical intersection."""
        nodes, stack, internal = {node_id}, [node_id], set()
        while stack:
            n = stack.pop()
            for s in self.node_segs[n]:
                if not is_vehicular(s) or _length(s["xy"]) > MERGE_FT:
                    continue
                internal.add(id(s))
                other = s["node_to"] if s["node_from"] == n else s["node_from"]
                if other not in nodes:
                    nodes.add(other)
                    stack.append(other)
        return nodes, internal

    def legs(self, nodes, internal):
        """Segments leaving the cluster, one per direction (LION keeps duplicate
        parallel records of some segments)."""
        unique = {}
        for n in sorted(nodes):
            for s in self.node_segs[n]:
                if id(s) in internal:
                    continue
                other = s["node_to"] if s["node_from"] == n else s["node_from"]
                bearing = _bearing_from(s["xy"], self.node_xy[n])
                leg = {
                    "street": s["street"], "bearing": round(bearing, 1),
                    "vehicular": is_vehicular(s), "divided": s["rb_layer"] == "G",
                    "rw_type": s["rw_type"], "feature_type": s["feature_type"],
                    "len": round(_length(s["xy"])), "width_max": s.get("width_max"),
                    "from_node": n, "far_node": other,
                }
                unique.setdefault((s["street"], round(bearing / 5), other), leg)
        return list(unique.values())

    def _vehicular_legs_at(self, node_id):
        nodes, internal = self.cluster(node_id)
        return nodes, [l for l in self.legs(nodes, internal) if l["vehicular"]]

    def _find_dogleg(self, nodes, vlegs, pair):
        """The other half of a dog-leg for the T at `nodes`, or None. Walks along
        the through street (both directions, through 2-leg shape/name-change
        nodes) up to DOGLEG_FT; the first T reached counts if its through street
        is ours and its stub is the same street as ours (E/W halves count as one)
        leaving on the opposite side, roughly anti-parallel to our stub. Two
        different streets T-ing in from opposite sides are just two Ts: checked
        on the citywide run, those were most of the name-blind matches."""
        stub = vlegs[_stub_index(pair)]
        through_keys = {street_key(vlegs[i]["street"]) for i in pair}
        through_bearing = vlegs[pair[0]]["bearing"]
        my_side = _side_of(through_bearing, stub["bearing"])
        for start in (vlegs[pair[0]], vlegs[pair[1]]):
            walked, far, previous = start["len"], start["far_node"], nodes
            for _ in range(DOGLEG_MAX_HOPS + 1):
                if walked > DOGLEG_FT:
                    break
                far_nodes, far_legs = self._vehicular_legs_at(far)
                if far_nodes & nodes:
                    break
                cls, far_pairs, _ = _shape(far_legs)
                if cls == "T":
                    far_stub = far_legs[_stub_index(far_pairs[0])]
                    if (street_key(far_legs[far_pairs[0][0]]["street"]) in through_keys
                            and names_match(street_key(far_stub["street"]), street_key(stub["street"]))
                            and _side_of(through_bearing, far_stub["bearing"]) != my_side
                            and _angdiff(far_stub["bearing"], stub["bearing"]) > 120):
                        return {"dogleg_offset_ft": walked, "dogleg_other_nodes": sorted(far_nodes),
                                "dogleg_other_stub": far_stub["street"]}
                    break
                if len(far_legs) != 2:
                    break
                onward = [l for l in far_legs if l["far_node"] not in previous]
                if len(onward) != 1:
                    break
                previous = far_nodes
                walked += onward[0]["len"]
                far = onward[0]["far_node"]
        return None

    def classify_node(self, node_id):
        nodes, internal = self.cluster(node_id)
        legs = self.legs(nodes, internal)
        vlegs = [l for l in legs if l["vehicular"]]
        cls, pairs, skew = _shape(vlegs)
        reasons = []
        streets = {street_key(l["street"]) for l in vlegs}
        if len(vlegs) >= 5:
            reasons.append(f"{len(vlegs)} vehicular legs")
        if len(streets) >= 3:
            reasons.append(f"{len(streets)} streets")
            cls = "complex"
        if cls == "complex" and len(vlegs) == 3 and not pairs:
            reasons.append("3 legs, none straight (Y)")
        if cls == "complex" and len(vlegs) == 4 and len(pairs) < 2:
            reasons.append("4 legs, not two straight pairs")
        if len(vlegs) <= 2:
            reasons.append(f"{len(vlegs)} vehicular legs")
        out = {
            "class": cls, "lion_node_ids": sorted(nodes), "n_vehicular_legs": len(vlegs),
            "skew_deg": skew, "reasons": reasons,
            "divided_streets": sorted({l["street"] for l in vlegs if l["divided"]}),
            "ped_legs": sorted({l["street"] for l in legs if not l["vehicular"]}),
            "legs": legs, "dogleg_offset_ft": None, "dogleg_other_nodes": None,
        }
        if cls == "T":
            dogleg = self._find_dogleg(nodes, vlegs, pairs[0])
            if dogleg:
                out["class"] = "dog-leg"
                out.update(dogleg)
        return out

    def classify_corner(self, on_street, from_street, x, y):
        """Classifies the intersection of a SIMS corner record."""
        match, name_mismatch = None, None
        for d, nid in self.nodes_near(x, y, SEARCH_FT):
            nodes, _ = self.cluster(nid)
            streets = [s["street"] for n in nodes for s in self.node_segs[n]]
            if (any(names_match(on_street, s) for s in streets)
                    and any(names_match(from_street, s) for s in streets)):
                match = (d, nid)
                break
        if match is None:
            for d, nid in self.nodes_near(x, y, MISMATCH_SEARCH_FT):
                nodes, _ = self.cluster(nid)
                streets = [s["street"] for n in nodes for s in self.node_segs[n] if is_vehicular(s)]
                if len({street_key(s) for s in streets}) >= 2 and (
                        any(names_match(from_street, s) for s in streets)
                        or any(names_match(on_street, s) for s in streets)):
                    match, name_mismatch = (d, nid), sorted(set(streets))
                    break
        if match is None:
            near = self.nodes_near(x, y, SEARCH_FT)
            return {"class": "no-match", "lion_node_ids": [], "n_vehicular_legs": None, "skew_deg": None,
                    "reasons": [f"no LION node joining both streets within {SEARCH_FT} ft"],
                    "divided_streets": [], "ped_legs": [], "legs": [], "name_mismatch": None,
                    "dogleg_offset_ft": None, "dogleg_other_nodes": None,
                    "node_distance_ft": round(near[0][0], 1) if near else None}
        out = self.classify_node(match[1])
        out["name_mismatch"] = name_mismatch
        out["node_distance_ft"] = round(match[0], 1)
        return out


def load_network(db_path, bbox=None):
    """Network from lion_network.db; bbox = (min_x, min_y, max_x, max_y) in
    EPSG:2263 feet limits it to segments whose bounding box touches it."""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    sql = ("SELECT street, feature_type, rb_layer, rw_type, node_from, node_to, width_max, xy_json "
           "FROM segments")
    params = ()
    if bbox is not None:
        sql += " WHERE max_x >= ? AND min_x <= ? AND max_y >= ? AND min_y <= ?"
        params = (bbox[0], bbox[2], bbox[1], bbox[3])
    segments = []
    for row in conn.execute(sql, params):
        s = dict(row)
        s["xy"] = [tuple(p) for p in json.loads(s.pop("xy_json"))]
        segments.append(s)
    conn.close()
    return Network(segments)


# --- signs.db ---------------------------------------------------------------------

def _board_corners(signs_db_path, board_label):
    conn = sqlite3.connect(str(signs_db_path))
    rows = conn.execute("SELECT corner_id, on_street, from_street, x_2263, y_2263 FROM sign_corners "
                        "WHERE board_label = ? ORDER BY corner_id", (board_label,)).fetchall()
    conn.close()
    return rows


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def board_bbox(signs_db_path, board_label, margin=BOARD_MARGIN_FT):
    pts = [(_to_float(x), _to_float(y)) for _, _, _, x, y in _board_corners(signs_db_path, board_label)]
    pts = [p for p in pts if None not in p]
    if not pts:
        return None
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return min(xs) - margin, min(ys) - margin, max(xs) + margin, max(ys) + margin


def classify_board(signs_db_path, board_label, network):
    """Classifies every SIMS corner of a board and upserts the rows into
    intersection_classes. Returns the number of corners written."""
    signs_db.init_db(signs_db_path)
    computed_at = time.strftime("%Y-%m-%dT%H:%M:%S")
    rows = []
    for corner_id, on_street, from_street, x, y in _board_corners(signs_db_path, board_label):
        x, y = _to_float(x), _to_float(y)
        if x is None or y is None:
            r = {"class": "no-match", "lion_node_ids": [], "reasons": ["SIMS corner has no x/y"],
                 "divided_streets": [], "legs": []}
        else:
            r = network.classify_corner(on_street, from_street, x, y)
        rows.append({
            "corner_id": corner_id,
            "intersection_key": ",".join(r["lion_node_ids"]) or None,
            "lion_node_ids": json.dumps(r["lion_node_ids"]),
            "class": r["class"],
            "divided": 1 if r.get("divided_streets") else 0,
            "divided_streets": "; ".join(r.get("divided_streets") or []) or None,
            "skew_deg": r.get("skew_deg"),
            "n_vehicular_legs": r.get("n_vehicular_legs"),
            "reasons": "; ".join(r.get("reasons") or []) or None,
            "legs_json": json.dumps({k: r.get(k) for k in ("legs", "ped_legs", "dogleg_offset_ft",
                                                           "dogleg_other_nodes", "dogleg_other_stub")}),
            "name_mismatch": "; ".join(r["name_mismatch"]) if r.get("name_mismatch") else None,
            "node_distance_ft": r.get("node_distance_ft"),
            "classifier_version": CLASSIFIER_VERSION,
            "computed_at": computed_at,
        })
    signs_db.upsert_intersection_classes(signs_db_path, board_label, rows)
    return len(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--board", action="append", help="board label, e.g. cb110 (repeatable)")
    group.add_argument("--all", action="store_true", help="every board in signs.db")
    args = parser.parse_args()

    signs_path, lion_path = paths.signs_db(), paths.lion_network_db()
    if not lion_path.exists():
        raise SystemExit(f"{lion_path} not found; run import_lion_network.py with the sds env first.")
    boards = args.board or sorted(b for b in signs_db.list_boards(signs_path) if re.fullmatch(r"cb\d{3}", b))
    totals = Counter()
    for board in boards:
        bbox = board_bbox(signs_path, board)
        if bbox is None:
            print(f"{board}: no corners with coordinates, skipped")
            continue
        n = classify_board(signs_path, board, load_network(lion_path, bbox))
        conn = sqlite3.connect(str(signs_path))
        counts = dict(conn.execute(
            "SELECT class, count(*) FROM v_intersection_summary WHERE board_label = ? GROUP BY class",
            (board,)).fetchall())
        no_match = conn.execute("SELECT count(*) FROM intersection_classes WHERE board_label = ? "
                                "AND class = 'no-match'", (board,)).fetchone()[0]
        conn.close()
        totals.update(counts)
        totals["no-match corners"] += no_match
        print(f"{board}: {n} corners | intersections {counts} | no-match corners {no_match}")
    print("total:", dict(totals))


if __name__ == "__main__":
    paths.require_data_dir()
    main()
