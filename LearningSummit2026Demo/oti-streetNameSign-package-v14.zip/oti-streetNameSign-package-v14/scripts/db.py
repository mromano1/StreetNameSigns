"""
One way to open this app's SQLite databases (annotations.db, review.db,
signs.db, lion_matches.db), safe for a data folder on a network drive that
several workstations use at the same time.

- journal_mode=DELETE, never WAL: WAL relies on shared memory that does
  not work across machines over SMB, and can corrupt the database there.
- timeout=30 / busy_timeout=30000: when another machine is in the middle
  of a save, this connection waits up to 30 seconds for it instead of
  failing with "database is locked".
- Callers keep each write to one short transaction (they already do:
  every save is a single `with conn:` block).
- A path inside an unreachable custom DATA_DIR raises
  paths.DataDirUnreachable before any folder is created, so a network
  outage never silently produces a new, empty local database.

Usage:
    import db
    conn = db.connect(paths.annotations_db())
"""
import sqlite3
from pathlib import Path

import paths

BUSY_TIMEOUT_SECONDS = 30


def connect(path, create_parent=True) -> sqlite3.Connection:
    path = Path(path)
    if paths.is_custom_data_dir() and paths.is_inside_data_dir(path):
        problem = paths.data_dir_problem()
        if problem:
            raise paths.DataDirUnreachable(problem)
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=BUSY_TIMEOUT_SECONDS)
    conn.execute(f"PRAGMA busy_timeout={BUSY_TIMEOUT_SECONDS * 1000}")
    try:
        conn.execute("PRAGMA journal_mode=DELETE")
    except sqlite3.DatabaseError:
        # Not a database (or damaged): leave the error to the caller's
        # first real query, which every reader already handles.
        pass
    return conn
