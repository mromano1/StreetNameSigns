"""
Trained models on the shared data folder, and which one each workstation
uses.

Layout (under paths.models_dir(), i.e. <DATA_DIR>/models/):

    runs/<run_name>/          weights/best.pt, training charts, info.json
                              info.json = {"type": "spatial"|"physical",
                                           "map50", "date", "trained_by"}
    promoted.json             the recommended ("promoted") run per type,
                              plus a dated history of promotions. A new
                              machine starts on these.
    machines/<COMPUTERNAME>.json
                              this machine's current spatial + physical run
                              and a dated history of events: started_on,
                              switched_to, trained.

Each machine only ever writes its own machine file, always atomically
(temp file, then replace), so several workstations can share the folder
without write conflicts. Training never switches a machine's model by
itself; "Use this model" on the hub's Models page (or
promote_model_run.py) does.

This replaces the repo-wide yolo/PRODUCTION_RUNS.json once the data
folder has a models/ folder (see model_promotion_lib.resolve_promoted_
weights, and migrate_models_to_data_dir.py / seed_models for how one gets
created).
"""
import csv
import json
import os
import re
import shutil
import socket
from datetime import datetime
from pathlib import Path

import paths

MODEL_KINDS = ("physical", "spatial")
HISTORY_CSV = {"physical": "PHYSICAL_RUN_HISTORY.csv", "spatial": "SPATIAL_RUN_HISTORY.csv"}
# What publish_run copies from a local training run: the weights the app
# actually loads, plus the small charts/metrics people look at. Not
# last.pt or the train/val batch mosaics (large, never used after training).
COPY_PATTERNS = ("*.png", "results.csv", "args.yaml")
DATE_IN_NAME = re.compile(r"(\d{4}-\d{2}-\d{2})")


def _models_dir(models_dir):
    return Path(models_dir) if models_dir is not None else paths.models_dir()


def _now_str(now):
    return now() if now is not None else datetime.now().isoformat(timespec="seconds")


def machine_name() -> str:
    return os.environ.get("COMPUTERNAME") or socket.gethostname() or "unknown-machine"


def write_json_atomic(path, data) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _read_json(path, default):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default
    return data if isinstance(data, dict) else default


def registry_exists(models_dir=None) -> bool:
    m = _models_dir(models_dir)
    return (m / "promoted.json").exists() or (m / "runs").is_dir()


def runs_dir(models_dir=None) -> Path:
    return _models_dir(models_dir) / "runs"


def weights_for_run(run_name, models_dir=None) -> Path:
    return runs_dir(models_dir) / run_name / "weights" / "best.pt"


def run_info(run_name, models_dir=None) -> dict:
    return _read_json(runs_dir(models_dir) / run_name / "info.json", {})


# --- promoted defaults -----------------------------------------------------

def read_promoted(models_dir=None) -> dict:
    data = _read_json(_models_dir(models_dir) / "promoted.json", {})
    result = {kind: data.get(kind) if isinstance(data.get(kind), str) else None for kind in MODEL_KINDS}
    result["history"] = data.get("history") if isinstance(data.get("history"), list) else []
    return result


def set_promoted(kind, run_name, models_dir=None, now=None) -> dict:
    if kind not in MODEL_KINDS:
        raise ValueError(f"Unknown model type {kind!r}")
    promoted = read_promoted(models_dir)
    promoted[kind] = run_name
    promoted["history"].append({"date": _now_str(now), "kind": kind, "run": run_name})
    write_json_atomic(_models_dir(models_dir) / "promoted.json", promoted)
    return promoted


# --- machine files -----------------------------------------------------------

def _machine_path(machine, models_dir):
    return _models_dir(models_dir) / "machines" / f"{machine or machine_name()}.json"


def read_machine(machine=None, models_dir=None):
    """This machine's file, or None if it has none yet. Creates nothing."""
    path = _machine_path(machine, models_dir)
    if not path.exists():
        return None
    data = _read_json(path, None)
    if data is None:
        return None
    data.setdefault("history", [])
    return data


def ensure_machine(machine=None, models_dir=None, now=None) -> dict:
    """The machine file, creating it on first use: a new machine starts on
    the promoted run of each type, recorded as started_on events."""
    machine = machine or machine_name()
    existing = read_machine(machine, models_dir)
    if existing is not None:
        return existing
    promoted = read_promoted(models_dir)
    date = _now_str(now)
    data = {"machine": machine, "history": []}
    for kind in MODEL_KINDS:
        data[kind] = promoted[kind]
        if promoted[kind]:
            data["history"].append({"date": date, "event": "started_on", "kind": kind, "run": promoted[kind]})
    write_json_atomic(_machine_path(machine, models_dir), data)
    return data


def current_run(kind, machine=None, models_dir=None):
    return ensure_machine(machine, models_dir).get(kind)


def use_model(kind, run_name, machine=None, models_dir=None, now=None) -> dict:
    if kind not in MODEL_KINDS:
        raise ValueError(f"Unknown model type {kind!r}; must be one of {MODEL_KINDS}")
    if not run_name or not weights_for_run(run_name, models_dir).exists():
        raise ValueError(f"No trained model named {run_name!r} with weights on the shared drive.")
    info_type = run_info(run_name, models_dir).get("type")
    if info_type and info_type != kind:
        raise ValueError(f"{run_name} is a {info_type} model, not a {kind} model.")
    data = ensure_machine(machine, models_dir, now=now)
    data[kind] = run_name
    data["history"].append({"date": _now_str(now), "event": "switched_to", "kind": kind, "run": run_name})
    write_json_atomic(_machine_path(data["machine"], models_dir), data)
    return data


def record_trained(kind, run_name, machine=None, models_dir=None, now=None) -> dict:
    data = ensure_machine(machine, models_dir, now=now)
    data["history"].append({"date": _now_str(now), "event": "trained", "kind": kind, "run": run_name})
    write_json_atomic(_machine_path(data["machine"], models_dir), data)
    return data


# --- listing ---------------------------------------------------------------

def list_runs(models_dir=None) -> list:
    root = runs_dir(models_dir)
    if not root.is_dir():
        return []
    runs = []
    for run in root.iterdir():
        if not run.is_dir():
            continue
        info = _read_json(run / "info.json", {})
        runs.append({
            "name": run.name,
            "type": info.get("type"),
            "map50": info.get("map50"),
            "date": info.get("date"),
            "trained_by": info.get("trained_by"),
            "has_weights": (run / "weights" / "best.pt").exists(),
        })
    runs.sort(key=lambda r: (r["date"] or "", r["name"]), reverse=True)
    return runs


def list_machines(models_dir=None) -> list:
    folder = _models_dir(models_dir) / "machines"
    if not folder.is_dir():
        return []
    machines = []
    for path in sorted(folder.glob("*.json")):
        data = _read_json(path, None)
        if data is None:
            continue
        data.setdefault("machine", path.stem)
        data.setdefault("history", [])
        machines.append(data)
    return machines


def is_older_than_promoted(kind, run_name, models_dir=None) -> bool:
    promoted = read_promoted(models_dir).get(kind)
    if not run_name or not promoted or run_name == promoted:
        return False
    mine = run_info(run_name, models_dir).get("date") or ""
    newest = run_info(promoted, models_dir).get("date") or ""
    return bool(mine and newest and mine < newest)


def machine_warnings(machine: dict, models_dir=None) -> list:
    promoted = read_promoted(models_dir)
    warnings = []
    for kind in MODEL_KINDS:
        run = machine.get(kind)
        if is_older_than_promoted(kind, run, models_dir):
            warnings.append(f"Uses an older {kind} model ({run}) than the promoted one ({promoted[kind]}).")
    return warnings


def _since(machine: dict) -> dict:
    """kind -> date this machine started using its current run of that kind."""
    since = {}
    for kind in MODEL_KINDS:
        for event in reversed(machine.get("history", [])):
            if event.get("kind") == kind and event.get("run") == machine.get(kind) \
                    and event.get("event") in ("started_on", "switched_to"):
                since[kind] = event.get("date")
                break
        else:
            since[kind] = None
    return since


def overview(machine=None, models_dir=None) -> dict:
    """Everything the hub's Models page shows, in one read-only call
    (creates this machine's file on first view, like any first use)."""
    machine = machine or machine_name()
    if not registry_exists(models_dir):
        return {"registry": False, "machine": machine, "models_dir": str(_models_dir(models_dir)),
                "promoted": {k: None for k in MODEL_KINDS}, "runs": [], "this_machine": None, "machines": []}
    this_machine = ensure_machine(machine, models_dir)
    promoted = read_promoted(models_dir)
    runs = list_runs(models_dir)
    for run in runs:
        run["in_use_here"] = run["type"] in MODEL_KINDS and this_machine.get(run["type"]) == run["name"]
        run["promoted"] = run["type"] in MODEL_KINDS and promoted.get(run["type"]) == run["name"]
    machines = []
    for m in list_machines(models_dir):
        machines.append({"machine": m["machine"], **{k: m.get(k) for k in MODEL_KINDS},
                         "since": _since(m), "warnings": machine_warnings(m, models_dir)})
    return {
        "registry": True, "machine": machine, "models_dir": str(_models_dir(models_dir)),
        "promoted": {k: promoted[k] for k in MODEL_KINDS},
        "runs": runs, "this_machine": this_machine, "machines": machines,
    }


# --- adding runs -------------------------------------------------------------

def _unique_run_name(name, machine, models_dir):
    root = runs_dir(models_dir)
    if not (root / name).exists():
        return name
    candidate = f"{name}-{machine}"
    n = 1
    while (root / candidate).exists():
        n += 1
        candidate = f"{name}-{machine}-{n}"
    return candidate


def _copy_run_files(source: Path, dest: Path) -> None:
    (dest / "weights").mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / "weights" / "best.pt", dest / "weights" / "best.pt")
    for pattern in COPY_PATTERNS:
        for f in source.glob(pattern):
            if f.is_file():
                shutil.copy2(f, dest / f.name)


def publish_run(local_run_dir, kind, map50, machine=None, models_dir=None, now=None) -> str:
    """Copies a finished local training run to runs/ on the shared drive
    (never overwriting another machine's run of the same name), writes its
    info.json, and records a "trained" event. Does NOT switch this
    machine's model. Returns the name it was saved under."""
    if kind not in MODEL_KINDS:
        raise ValueError(f"Unknown model type {kind!r}")
    machine = machine or machine_name()
    local_run_dir = Path(local_run_dir)
    name = _unique_run_name(local_run_dir.name, machine, models_dir)
    dest = runs_dir(models_dir) / name
    _copy_run_files(local_run_dir, dest)
    date = _now_str(now)
    write_json_atomic(dest / "info.json", {
        "type": kind, "map50": map50, "date": date, "trained_by": machine})
    record_trained(kind, name, machine, models_dir, now=lambda: date)
    return name


def publish_if_shared(local_run_dir, kind, map50):
    """Called by the training scripts once a run finishes: copies it to the
    shared drive when this install uses a shared models/ folder. Returns
    the shared name, or None when there is no registry or the copy failed
    (training itself already succeeded, so this only warns)."""
    if paths.data_dir_problem() or not registry_exists():
        return None
    try:
        name = publish_run(local_run_dir, kind, map50)
    except Exception as e:  # noqa: BLE001
        print(f"WARNING: the trained model could not be copied to the shared drive ({e}). "
              "It is still in the local runs folder.")
        return None
    print(f"Copied to the shared drive as '{name}'. Use it from the hub's Models page.")
    return name


def _legacy_metrics(legacy_runs_dir: Path, kind: str) -> dict:
    """run_name -> {"map50", "date"} from the legacy history CSV."""
    path = legacy_runs_dir / HISTORY_CSV[kind]
    result = {}
    if not path.exists():
        return result
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                map50 = float(row.get("mAP50") or "nan")
            except ValueError:
                map50 = None
            if map50 != map50:  # NaN
                map50 = None
            result[row.get("run_name")] = {"map50": map50, "date": row.get("date") or None}
    return result


def _legacy_runs(legacy_runs_dir: Path) -> list:
    if not legacy_runs_dir.is_dir():
        return []
    return [d for d in legacy_runs_dir.iterdir() if (d / "weights" / "best.pt").exists()]


def seed_plan(legacy_yolo_dir, pointer_path=None, copy_all=False):
    """(defaults, plan): the default run per type, and the run names
    seed_models would copy per type. Reads only; used for --dry-run."""
    legacy_yolo_dir = Path(legacy_yolo_dir)
    pointer = _read_json(pointer_path, {}) if pointer_path else {}
    defaults, plan = {}, {}
    for kind in MODEL_KINDS:
        available = _legacy_runs(legacy_yolo_dir / f"runs_{kind}")
        names = {d.name for d in available}
        default = pointer.get(kind) if pointer.get(kind) in names else None
        if default is None and kind == "physical" and available:
            default = max(available, key=lambda d: d.stat().st_mtime).name
        defaults[kind] = default
        plan[kind] = sorted(names) if copy_all else ([default] if default else [])
    return defaults, plan


def seed_models(models_dir, legacy_yolo_dir, pointer_path=None, copy_all=False, now=None) -> dict:
    """Builds (or tops up) a models/ folder from a legacy layout
    (<yolo>/runs_physical, <yolo>/runs_spatial, PRODUCTION_RUNS.json).

    Defaults: the promoted run from the pointer file; for physical, when
    nothing was promoted, the newest run by folder time (exactly what the
    hub loaded before this registry existed). Copies only the default runs
    unless copy_all. Never overwrites an existing run folder or an
    existing promoted.json. Returns {"copied": [...], "promoted": {...}}."""
    models_dir = Path(models_dir)
    legacy_yolo_dir = Path(legacy_yolo_dir)
    defaults, plan = seed_plan(legacy_yolo_dir, pointer_path, copy_all)
    copied = []
    for kind in MODEL_KINDS:
        legacy_dir = legacy_yolo_dir / f"runs_{kind}"
        by_name = {d.name: d for d in _legacy_runs(legacy_dir)}
        wanted = plan[kind]
        metrics = _legacy_metrics(legacy_dir, kind)
        for name in wanted:
            dest = models_dir / "runs" / name
            if dest.exists():
                continue
            _copy_run_files(by_name[name], dest)
            m = metrics.get(name, {})
            date = m.get("date")
            if not date:
                match = DATE_IN_NAME.search(name)
                date = match.group(1) if match else datetime.fromtimestamp(by_name[name].stat().st_mtime).date().isoformat()
            write_json_atomic(dest / "info.json", {
                "type": kind, "map50": m.get("map50"), "date": date, "trained_by": "migrated"})
            copied.append(name)
    promoted_path = models_dir / "promoted.json"
    if not promoted_path.exists():
        date = _now_str(now)
        history = [{"date": date, "kind": k, "run": r} for k, r in defaults.items() if r]
        write_json_atomic(promoted_path, {**defaults, "history": history})
    (models_dir / "machines").mkdir(parents=True, exist_ok=True)
    return {"copied": copied, "promoted": {k: read_promoted(models_dir)[k] for k in MODEL_KINDS}}
