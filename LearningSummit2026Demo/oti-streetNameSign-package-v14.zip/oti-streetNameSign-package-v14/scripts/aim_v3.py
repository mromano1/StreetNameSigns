"""
Retrieval v3: intersection-aware photo aiming for a board's capture-cycle pull
(fetch_cyclomedia_panoramas.py --aim v3).

v2 aimed one wide shot per SIMS corner at the intersection point. SIMS has no
pole positions, so on Board 10 80 of 199 of those photos had no sign or only a
tiny one. v3 plans per intersection instead:

1. Class from LION (intersection_classifier.py; the stored v_intersections
   class wins, so a hand override in signs.db steers the fetch).
2. Targets from the SIMS sign_locations of every corner record of that
   intersection (aim_geometry.targets_for_corner): one per occupied corner,
   curb, top of T or median nose. Corner records that share an intersection
   share its targets, so nothing is fetched twice.
3. Minimum two targets at a standard intersection (4-leg, T, dog-leg): when
   SIMS names only one corner, the diagonally opposite corner is added (on
   a T that lands on the far curb). A lone median, curb, mall or island target
   gets no partner: there is no "opposite" for it that SIMS implies.
4. Per target, from a recording 5-12 m away (2-20 m if none):
     wide        120 deg, level: the corner_wide shot, or the corner's
                 `latest` image when it is that corner's first target
     zoom        55 deg, tilted to sign height from the wide render's
                 RecordingLocation-GroundLevelOffset header (geometric targets)
     suggested   up to MAX_SUGGESTED 55 deg-or-tighter zooms on spatial-model
                 detections within SUGGEST_MAX_OFF_DEG of the target (complex
                 intersections, where the curb geometry hit 1/11 in Phase 0).
                 The spatial model is noisy today (about 1 box in 20 was a
                 street-name plate on Phase 0 wides), so these are recorded as
                 suggestions with their confidence, not as confirmed signs.
     mall / island / center-mall targets: wide only.

Every corner record still gets exactly one `latest` image (wide, 120 deg,
level, the v2 filename pattern), so inference, tight crops, review headings
and manifest repair keep working unchanged. Corners v3 can't plan (no LION
match, no usable sign_location) fall back to the v2 latest job.

Render budget: RenderBudget caps renders across the run; when it runs out the
run stops cleanly and the manifest is still written. Re-runs skip targets
whose images are already on disk (by target_id), like v2's skip-if-exists.
"""
import importlib
import json
import re
import shutil
import sqlite3
from collections import Counter, OrderedDict
from datetime import datetime
from pathlib import Path

import aim_geometry as ag
import cyclomedia_client as cc

RETRIEVAL_VERSION = "v3"
ZOOM_HFOV = 55.0
MAX_SUGGESTED = 2
SUGGEST_MAX_OFF_DEG = 40.0
STANDARD_CLASSES = ("4-leg", "T", "dog-leg")
RECORDING_SEARCH_M = 21.0          # bbox half-size for the recordings lookup
PREFERRED_RANGE_M = (5.0, 12.0)    # Phase 0: camera 7-8 m from the corner
FALLBACK_RANGE_M = (2.0, 20.0)
ROADBED_RADIUS_FT = 400.0
BEHIND_CURB_KINDS = ("corner", "curb", "apex", "top_of_t")
EXTRA_KINDS = ("corner_wide", "corner_zoom", "suggested_zoom")


# --- planning (no network calls) ------------------------------------------------

def corner_sign_locations(corner):
    seen = []
    for sign in corner.get("signs") or []:
        loc = " ".join((sign.get("sign_location") or "").split())
        if loc and loc not in seen:
            seen.append(loc)
    return seen


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def load_class_lookup(signs_db_path, corner_ids):
    """corner_id -> class from v_intersections (override applied), {} when the
    database or view isn't there yet."""
    out = {}
    if not signs_db_path or not Path(signs_db_path).exists():
        return out
    ids = [c for c in corner_ids if c]
    try:
        conn = sqlite3.connect(str(signs_db_path))
        for i in range(0, len(ids), 500):
            batch = ids[i:i + 500]
            q = f"SELECT corner_id, class FROM v_intersections WHERE corner_id IN ({','.join('?' * len(batch))})"
            for cid, cls in conn.execute(q, batch):
                if cls:
                    out[cid] = cls
        conn.close()
    except sqlite3.Error:
        return {}
    return out


def _target_tag(t):
    return t["kind"] if not t.get("label") else f"{t['kind']}-{t['label']}"


def _node_xy(network, node_ids):
    pts = [network.node_xy[n] for n in node_ids if n in network.node_xy]
    return sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)


def _roadbeds_near(roadbeds, xy):
    r = ROADBED_RADIUS_FT
    return [s for s in roadbeds
            if s["_bbox"][0] - r <= xy[0] <= s["_bbox"][2] + r and s["_bbox"][1] - r <= xy[1] <= s["_bbox"][3] + r]


def plan_board(corners, network, class_lookup=None):
    """(targets, unplanned_corners). targets are dicts, one per distinct aiming
    target per intersection, in corner order; unplanned_corners get the v2
    latest job."""
    class_lookup = class_lookup or {}
    roadbeds = []
    for s in network.segments:
        if s.get("rb_layer") == "R" and s.get("xy"):
            xs, ys = [p[0] for p in s["xy"]], [p[1] for p in s["xy"]]
            roadbeds.append(dict(s, _bbox=(min(xs), min(ys), max(xs), max(ys))))

    groups = OrderedDict()
    unplanned = []
    for corner in corners:
        x, y = _to_float(corner.get("x_2263")), _to_float(corner.get("y_2263"))
        locs = corner_sign_locations(corner)
        if x is None or y is None or not any(ag.parse_sign_location(l) for l in locs):
            unplanned.append(corner)
            continue
        r = network.classify_corner(corner.get("on_street") or "", corner.get("from_street") or "", x, y)
        if not r["lion_node_ids"]:
            unplanned.append(corner)
            continue
        key = ",".join(r["lion_node_ids"])
        cls = class_lookup.get(corner.get("corner_id")) or r["class"]
        groups.setdefault(key, {"class": cls, "r": r, "corners": []})["corners"].append((corner, locs))

    targets = []
    for key, g in groups.items():
        r = g["r"]
        node_xy = _node_xy(network, r["lion_node_ids"])
        near_rb = _roadbeds_near(roadbeds, node_xy)
        all_locs = []
        for _, locs in g["corners"]:
            all_locs += [l for l in locs if l not in all_locs]
        found = ag.targets_for_corner({"class": g["class"], "legs": r["legs"]}, all_locs, node_xy, near_rb)
        if not found:
            unplanned += [c for c, _ in g["corners"]]
            continue
        if g["class"] in STANDARD_CLASSES and len(found) == 1 and found[0]["kind"] == "corner":
            opp = ag.OPPOSITE[found[0]["label"]]
            found.append({"kind": "corner", "label": opp, "sign_locations": [],
                          "xy": ag.corner_point(r["legs"], node_xy, ag.COMPASS[opp], near_rb),
                          "method": "added: diagonally opposite corner (minimum two per standard intersection)",
                          "zoom": "geometric", "added": True})
        nlat, nlon = ag.xy_to_latlon(*node_xy)
        group_ids = [c.get("corner_id") for c, _ in g["corners"]]
        for t in found:
            covered = [c.get("corner_id") for c, locs in g["corners"] if set(locs) & set(t["sign_locations"])]
            tlat, tlon = ag.xy_to_latlon(*t["xy"])
            targets.append({
                "target_id": f"{key}:{_target_tag(t)}",
                "intersection_key": key,
                "corner_id": (covered or group_ids)[0],
                "corner_ids": covered or group_ids,
                "intersection_class": g["class"],
                "divided_streets": r.get("divided_streets") or [],
                "kind": t["kind"], "label": t.get("label"), "sign_locations": t["sign_locations"],
                "method": t["method"], "zoom": t["zoom"], "added": bool(t.get("added")),
                "xy": t["xy"], "lat": tlat, "lon": tlon, "node_lat": nlat, "node_lon": nlon,
                "corners": {c.get("corner_id"): c for c, _ in g["corners"]},
            })
    _assign_latest(targets)
    return targets, unplanned


def _assign_latest(targets):
    """Each corner's `latest` is the wide of the first target covering its own
    signs (an added target only when nothing else covers it)."""
    have = set()
    for added_pass in (False, True):
        for t in targets:
            t.setdefault("latest_for", [])
            if t["added"] != added_pass:
                continue
            for cid in t["corner_ids"]:
                if cid not in have:
                    have.add(cid)
                    t["latest_for"].append(cid)


def renders_for(target):
    return 1 + {"geometric": 1, "detect": MAX_SUGGESTED}.get(target["zoom"], 0)


def estimate(targets, unplanned):
    """Upper-bound render count (detect targets counted at MAX_SUGGESTED),
    by class, plus recording lookups (one per target or fallback corner)."""
    by_class = Counter()
    for t in targets:
        by_class[t["intersection_class"]] += renders_for(t)
    by_class["v2 fallback"] += len(unplanned)
    return {"renders": sum(by_class.values()), "lookups": len(targets) + len(unplanned),
            "targets": len(targets), "intersections": len({t["intersection_key"] for t in targets}),
            "fallback_corners": len(unplanned), "renders_by_class": dict(by_class),
            "targets_by_kind": dict(Counter(f"{t['kind']}/{t['zoom']}" for t in targets))}


# --- running ----------------------------------------------------------------------

class RenderBudget:
    def __init__(self, max_renders=None):
        self.max = max_renders
        self.used = 0

    def take(self):
        if self.max is not None and self.used >= self.max:
            return False
        self.used += 1
        return True

    @property
    def exhausted(self):
        return self.max is not None and self.used >= self.max


def parse_recording_date(value):
    """Recording-Date header ("2026-03-29T13:45:15.1100000+00:00", 7 fraction
    digits) -> aware datetime, or None."""
    if not value:
        return None
    s = re.sub(r"(\.\d{6})\d+", r"\1", str(value).strip()).replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def extra_filename(kind, corner_id, tag, heading, pitch, recorded_at):
    p = round(pitch or 0)
    pitch_part = f"p{p:02d}" if p >= 0 else f"pm{-p:02d}"
    date_part = f"_{recorded_at:%Y%m%d-%H%M%S}" if recorded_at else ""
    return f"{kind}_{corner_id}_{tag}_h{round(heading) % 360:03d}_{pitch_part}{date_part}.jpg"


def _latest_filename(corner_id, heading, recorded_at):
    if recorded_at is None:
        return "latest.jpg"
    return f"latest_{corner_id}_h{round(heading) % 360:03d}_{recorded_at:%Y%m%d-%H%M%S}.jpg"


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def _link_or_copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        dst.hardlink_to(src)
    except OSError:
        shutil.copy2(src, dst)


def _choose(target, recordings):
    pick = ag.choose_recording((target["lat"], target["lon"]), (target["node_lat"], target["node_lon"]),
                               recordings, *PREFERRED_RANGE_M)
    if pick is None:
        pick = ag.choose_recording((target["lat"], target["lon"]), (target["node_lat"], target["node_lon"]),
                                   recordings, *FALLBACK_RANGE_M)
    return pick


def run_target(target, output_dir, budget, cycle=None, width=3200, height=2400, wide_hfov=120.0,
               list_recordings=None, render=None, detector=None):
    """Fetches one target. Returns (entries, stopped): stopped is True when the
    render budget ran out before the target's first render (nothing written)."""
    list_recordings = list_recordings or cc.list_recordings_in_bbox
    render = render or cc.render_recording_with_headers
    output_dir = Path(output_dir)
    tag = _target_tag(target)
    base = {
        "retrieval_version": RETRIEVAL_VERSION, "target_id": target["target_id"],
        "intersection_key": target["intersection_key"], "intersection_class": target["intersection_class"],
        "corner_id": target["corner_id"], "corner_ids": target["corner_ids"],
        "target": {"kind": target["kind"], "label": target["label"], "lat": target["lat"], "lon": target["lon"],
                   "sign_locations": target["sign_locations"], "method": target["method"],
                   "zoom": target["zoom"], "added": target["added"]},
        "cycle": cycle, "selection": "v3", "width": width, "height": height,
    }
    if budget.exhausted:
        return [], True
    # >>> OTI CORE: per sign spot, one wide shot then one zoom -----------------
    # Recordings within 21 m of the spot -> aim_geometry.choose_recording
    # (5-12 m, else 2-20 m). Wide: 120 degrees, level, facing the spot.
    # Zoom: 55 degrees from the same recording, tilted up to sign height
    # (pitch_deg, using the camera height Cyclomedia sends back with the wide).
    try:
        d = RECORDING_SEARCH_M
        dlat, dlon = cc.meters_to_degrees_lat(d), cc.meters_to_degrees_lon(d, target["lat"])
        recs = list_recordings(target["lat"] - dlat, target["lon"] - dlon, target["lat"] + dlat,
                               target["lon"] + dlon, year=cycle)
    except cc.CyclomediaError as e:
        return [dict(base, image_kind="corner_wide", path=None, status="failed", error=str(e))], False
    pick = _choose(target, recs)
    if pick is None:
        return [dict(base, image_kind="corner_wide", path=None, status="failed",
                     error="No recording 2-20 m from the target.")], False

    heading = pick["heading"]
    if not budget.take():
        return [], True
    try:
        wide_bytes, headers = render(pick["recording_id"], heading, width=width, height=height, fov=wide_hfov)
    except cc.CyclomediaError as e:
        return [dict(base, image_kind="corner_wide", path=None, status="failed", error=str(e))], False
    recorded_at = parse_recording_date(headers.get("Recording-Date")) or pick.get("recorded_at")
    if isinstance(recorded_at, str):
        recorded_at = parse_recording_date(recorded_at)
    glo = _to_float(headers.get("RecordingLocation-GroundLevelOffset"))
    shot = dict(base, recording_id=pick["recording_id"], camera_to_target_m=pick["dist_m"],
                recorded_at=recorded_at.isoformat() if recorded_at else None,
                recording_location={"lat": _to_float(headers.get("RecordingLocation-Latitude")) or pick["lat"],
                                    "lon": _to_float(headers.get("RecordingLocation-Longitude")) or pick["lon"],
                                    "ground_offset_m": glo})

    entries = []
    primary = target["corner_id"]
    first_latest = target["latest_for"][0] if target["latest_for"] else None
    if first_latest is not None:
        rel = Path(first_latest) / _latest_filename(first_latest, heading, recorded_at)
        kind, wide_corner = "latest", first_latest
    else:
        rel = Path(primary) / extra_filename("corner_wide", primary, tag, heading, 0, recorded_at)
        kind, wide_corner = "corner_wide", primary
    _write(output_dir / rel, wide_bytes)
    corner = target["corners"].get(wide_corner) or {}
    wide_entry = dict(shot, image_kind=kind, corner_id=wide_corner, path=str(rel), status="ok",
                      heading=heading, pitch=0.0, hfov=wide_hfov,
                      lat=_to_float(corner.get("latitude")) or target["lat"],
                      lon=_to_float(corner.get("longitude")) or target["lon"])
    entries.append(wide_entry)
    for cid in target["latest_for"][1:]:
        other = Path(cid) / _latest_filename(cid, heading, recorded_at)
        _link_or_copy(output_dir / rel, output_dir / other)
        c = target["corners"].get(cid) or {}
        entries.append(dict(wide_entry, corner_id=cid, path=str(other), same_image_as=str(rel),
                            lat=_to_float(c.get("latitude")) or target["lat"],
                            lon=_to_float(c.get("longitude")) or target["lon"]))

    zooms = []
    if target["zoom"] == "geometric":
        behind = ag.BEHIND_CURB_M if target["kind"] in BEHIND_CURB_KINDS else 0.0
        pitch = ag.pitch_deg(glo if glo is not None else 2.3, pick["dist_m"], behind_curb_m=behind)
        zooms.append(("corner_zoom", heading, pitch, ZOOM_HFOV, None))
    # <<< OTI CORE end (complex intersections zoom on model detections below) --
    elif target["zoom"] == "detect" and detector is not None:
        try:
            suggestions = detector(str(output_dir / rel), yaw=heading, hfov=wide_hfov, width=width, height=height,
                                   target_bearing=heading, max_off_deg=SUGGEST_MAX_OFF_DEG)
        except Exception as e:  # a model problem must not lose the photos already fetched
            suggestions = []
            entries[0]["detect_error"] = str(e)
        for z in suggestions[:MAX_SUGGESTED]:
            zooms.append(("suggested_zoom", z["heading"], z["pitch"], min(z["hfov"], ZOOM_HFOV), z.get("conf")))

    for kind, z_heading, z_pitch, z_hfov, conf in zooms:
        if not budget.take():
            break
        try:
            data, z_headers = render(pick["recording_id"], z_heading, width=width, height=height,
                                     fov=z_hfov, pitch=z_pitch)
        except cc.CyclomediaError as e:
            entries.append(dict(shot, image_kind=kind, path=None, status="failed", error=str(e)))
            continue
        zrel = Path(primary) / extra_filename(kind, primary, tag, z_heading, z_pitch, recorded_at)
        _write(output_dir / zrel, data)
        e = dict(shot, image_kind=kind, path=str(zrel), status="ok", heading=z_heading, pitch=z_pitch,
                 hfov=z_hfov, lat=target["lat"], lon=target["lon"])
        if conf is not None:
            e["confidence"] = round(float(conf), 3)
        entries.append(e)
    return entries, False


def default_detector():
    """detect_zoom.detect_zoom, or None (with a printed note) when the spatial
    model can't load; v3 then fetches complex targets wide-only. Loaded by
    name so a package without the model stack (the OTI summit package ships
    the fetch but not inference) still runs v3."""
    try:
        dz = importlib.import_module("detect_zoom")
        dz.load_model()
    except Exception as e:  # missing weights / ultralytics: degrade, don't fail the pull
        print(f"Spatial model unavailable ({e}); complex intersections get wide shots only.", flush=True)
        return None
    return dz.detect_zoom


def prior_entries(output_dir):
    """target_id -> v3 manifest entries from a previous run whose images are
    all still on disk."""
    path = Path(output_dir) / "fetch_manifest.json"
    if not path.exists():
        return {}
    try:
        jobs = json.loads(path.read_text()).get("jobs", [])
    except (OSError, ValueError):
        return {}
    by_target = {}
    for j in jobs:
        if j.get("retrieval_version") == RETRIEVAL_VERSION and j.get("target_id"):
            by_target.setdefault(j["target_id"], []).append(j)
    keep = {}
    for tid, entries in by_target.items():
        if all(e.get("status") in ("ok", "skipped") and e.get("path") and (Path(output_dir) / e["path"]).exists()
               for e in entries):
            keep[tid] = [dict(e, status="skipped") for e in entries]
    return keep


def prior_fallback_entries(output_dir):
    """A previous v3 run's v2-fallback latest entries whose photo is still on
    disk (status "skipped")."""
    path = Path(output_dir) / "fetch_manifest.json"
    try:
        jobs = json.loads(path.read_text()).get("jobs", []) if path.exists() else []
    except (OSError, ValueError):
        return []
    return [dict(j, status="skipped") for j in jobs
            if j.get("fallback") and j.get("status") in ("ok", "skipped") and j.get("path")
            and (Path(output_dir) / j["path"]).exists()]


def print_plan(targets, unplanned, est, print_fn=print):
    print_fn(f"v3 plan: {est['intersections']} intersections, {est['targets']} targets, "
             f"{est['fallback_corners']} corners on the v2 fallback.")
    print_fn(f"Render estimate (upper bound): {est['renders']} renders + {est['lookups']} recording lookups.")
    for cls, n in sorted(est["renders_by_class"].items()):
        print_fn(f"  {cls:12} {n} renders")
    for kind, n in sorted(est["targets_by_kind"].items()):
        print_fn(f"  target {kind:22} {n}")
