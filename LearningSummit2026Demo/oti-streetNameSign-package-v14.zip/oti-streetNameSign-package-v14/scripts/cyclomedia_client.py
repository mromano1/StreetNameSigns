"""
OTI walkthrough -- Stage 3. Talks to Cyclomedia's two APIs.
  How it works: the Atlas recordings service finds the panorama photos
  nearest a point; the rendering service turns one panorama into a flat
  image looking in a given direction. Both need CYCLOMEDIA_USERNAME and
  CYCLOMEDIA_PASSWORD; rendering also needs CYCLOMEDIA_API_KEY (all in .env).

Shared client for authenticating against and fetching images from
Cyclomedia's Atlas API. Used by verify_cyclomedia_fetch.py and
fetch_damaged_panoramas.py so the endpoint/auth logic lives in one place.

Endpoints and parameters below are taken from Cyclomedia's official Atlas API
reference docs (docs.cyclomedia.com/Atlas/2020/Atlas WFS Recordings
Service.pdf and .../Atlas Panorama Rendering Service.pdf), not guessed. Both
services require HTTP Basic Auth (CYCLOMEDIA_USERNAME/PASSWORD); the
Panorama Rendering Service additionally requires a CYCLOMEDIA_API_KEY query
param. This has not yet been exercised against the live service with real
credentials -- CYCLOMEDIA_PASSWORD is still blank in .env as of 2026-07-22.
"""
import math
import os
import re
from datetime import datetime

import requests

ATLAS_WFS_URL = "https://atlasapi.cyclomedia.com/api/recording/wfs"
ATLAS_RENDER_URL = "https://atlasapi.cyclomedia.com/api/panoramarendering/Render/{recording_id}/"

# Confirmed live 2026-08-25 against a real WFS response (printed a feature's
# full raw `properties` dict): the actual per-recording capture-date field
# is "recordedAt" (e.g. "2026-03-21T14:21:20.3800000-04:00" -- when the
# Cyclomedia car actually took the picture). A prior guess of "expiredAt"
# was wrong -- that's a different, unrelated field -- and meant
# find_nearest_recording_at_date's date filtering was silently broken
# (every non-expired feature has no "expiredAt" value at all, so it was
# skipped by the `if not raw_date` check below instead of being compared).
RECORDING_DATE_FIELD = "recordedAt"

# Compass-quadrant -> approximate camera heading (degrees, 0=North), for
# aiming an unattended fetch with no human to point the camera. Ported from
# the capture extension's compassGuessFromHeading()/COMPASS_8
# (extension/content.js) -- same 8-point mapping, just used in reverse (given
# a corner's compass label, what heading points toward it, rather than given
# a heading, which corner is ahead).
COMPASS_TO_HEADING = {
    "N": 0.0, "NE": 45.0, "E": 90.0, "SE": 135.0,
    "S": 180.0, "SW": 225.0, "W": 270.0, "NW": 315.0,
}


class CyclomediaError(Exception):
    """Raised when the Atlas API returns a non-200 response, or no recording
    is found near the requested point."""


# Geometry helpers for distance/bearing/angle calculations.

def haversine_meters(lat1, lon1, lat2, lon2):
    """Great-circle distance in meters between two WGS84 points. Same
    formula as fetch_damaged_signs_panoramas.haversine_meters -- duplicated
    here rather than imported, since that script already imports this
    module (as cc), so importing the other way would be circular."""
    r = 6371000.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def meters_to_degrees_lat(meters):
    """Same formula as fetch_damaged_signs_panoramas.meters_to_degrees_lat
    -- duplicated for the same circular-import reason as haversine_meters
    above."""
    return meters / 111320.0


def meters_to_degrees_lon(meters, at_lat):
    """Longitude degrees shrink toward the poles -- at NYC's latitude
    (~40.7 deg) one degree of longitude is already ~15% shorter than one
    degree of latitude; ignoring that would under-size a bbox east-west
    and could miss a real in-range recording. Same formula as
    fetch_damaged_signs_panoramas.meters_to_degrees_lon."""
    return meters / (111320.0 * max(math.cos(math.radians(at_lat)), 1e-6))


def bearing_deg(lat1, lon1, lat2, lon2):
    """Compass bearing (0-360, 0=north) from point 1 to point 2 -- the
    real direction a camera at point 1 would need to face to look at
    point 2. Used by find_best_recording (below) to compute each
    candidate recording's actual render heading dynamically, instead of
    relying on a fixed/predetermined heading per corner -- a 360-degree
    Cyclomedia panorama can be rendered facing any direction, so there's
    no reason to guess."""
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dlambda = math.radians(lon2 - lon1)

    y = math.sin(dlambda) * math.cos(phi2)
    x = math.cos(phi1) * math.sin(phi2) - math.sin(phi1) * math.cos(phi2) * math.cos(dlambda)

    bearing = math.degrees(math.atan2(y, x))
    return bearing % 360.0


def angle_off_perpendicular(approach_bearing, street_bearing):
    """0 (parallel to the street -- a raking, foreshortened, down-the-
    block view) to 90 (perpendicular to the street -- a face-on,
    across-the-street view). street_bearing is a LION segment's own
    bearing_deg, which only encodes the street's AXIS, not which of its
    two directions -- 45 and 225 describe the same street. Folding
    through 180 first, then through 90, handles that ambiguity.
    approach_bearing and street_bearing must both be in [0, 360) --
    every real caller in this codebase already guarantees this
    (bearing_deg's own output range), so this is a documented
    precondition, not a runtime-enforced one; a value outside that range
    (e.g. 370) will not wrap correctly and can return a negative result.
    See the real
    validation in docs/superpowers/specs/2026-09-18-cyclomedia-best-
    recording-scoring-design.md for why this angle -- not raw distance --
    turned out to be what actually predicts sign legibility."""
    angle = abs(approach_bearing - street_bearing)
    angle = min(angle, 360 - angle)  # Wrap around 360 degrees
    angle = min(angle, 180 - angle)  # Fold opposite directions into same range
    return angle


def _auth():
    username = os.getenv("CYCLOMEDIA_USERNAME")
    password = os.getenv("CYCLOMEDIA_PASSWORD")
    if not username or not password:
        raise CyclomediaError(
            "CYCLOMEDIA_USERNAME/CYCLOMEDIA_PASSWORD not set -- make sure "
            "ML Project/.env exists and load_dotenv() has been called."
        )
    return (username, password)


def _api_key():
    api_key = os.getenv("CYCLOMEDIA_API_KEY")
    if not api_key:
        raise CyclomediaError(
            "CYCLOMEDIA_API_KEY not set -- make sure ML Project/.env exists "
            "and load_dotenv() has been called."
        )
    return api_key


# OTI: Stage 3 calls this first: fails once, clearly, if any key is missing.
def check_credentials():
    """Validates CYCLOMEDIA_USERNAME/PASSWORD/API_KEY are all set, raising
    CyclomediaError immediately with a clear message if not. Meant to be
    called once, upfront, before starting a real fetch run -- _auth()/
    _api_key() already raise this same error, but only lazily, on each
    job's own first real API call. Without an upfront check, a missing
    credential doesn't fail once cleanly; it fails identically on every
    job in the batch (fetch_cyclomedia_panoramas.py's run_job() catches
    CyclomediaError per-job so one bad corner doesn't lose the rest of a
    real run), burning through hundreds of jobs to report the same root
    cause hundreds of times instead of once, upfront."""
    _auth()
    _api_key()


def _feature_coords(feature):
    """Returns (lon, lat) from a GeoJSON feature's geometry, or None if
    absent (some fixtures/features carry no geometry)."""
    coords = (feature.get("geometry") or {}).get("coordinates")
    if not coords:
        return None
    return coords[0], coords[1]


def _feature_distance_sq(feature, lat, lon):
    coords = _feature_coords(feature)
    if coords is None:
        return float("inf")
    flon, flat = coords
    return (flat - lat) ** 2 + (flon - lon) ** 2


def _feature_image_id(feature):
    return feature["properties"].get("imageId") or feature.get("id")


def _parse_recorded_at(feature):
    """Returns the feature's capture-time (RECORDING_DATE_FIELD, "recordedAt")
    as a datetime, or None if the field is absent -- e.g. an older cached
    fixture, or a WFS response shape that omits it. Not expected to raise on
    a well-formed Cyclomedia timestamp (confirmed live: Python's
    datetime.fromisoformat handles Cyclomedia's own format, including its
    7-digit fractional seconds, directly)."""
    raw = feature.get("properties", {}).get(RECORDING_DATE_FIELD)
    if not raw:
        return None
    return datetime.fromisoformat(raw.replace("Z", "+00:00"))


def _year_bounds_filter(year):
    """OGC filter keeping recordings captured within `year` (a capture
    cycle). Shared by list_recordings_in_bbox and _nearest_feature."""
    return (
        f"<PropertyIsBetween><PropertyName>{RECORDING_DATE_FIELD}</PropertyName>"
        f"<LowerBoundary><Literal>{year}-01-01</Literal></LowerBoundary>"
        f"<UpperBoundary><Literal>{year}-12-31T23:59:59</Literal></UpperBoundary></PropertyIsBetween>"
    )


def _nearest_feature(lat, lon, radius_deg=0.001, timeout=30, year=None):
    """Shared lookup behind find_nearest_recording/find_nearest_recording_
    with_metadata -- queries the Atlas Recordings WFS (version 1.1.0) for
    the recording nearest (lat, lon), via an OGC Filter BBOX in EPSG:4326,
    excluding expired recordings. Returns the nearest feature dict, or None
    if nothing is within radius_deg. Picks the closest feature by geometry,
    not just whatever the API lists first -- the WFS response order is not
    documented as distance-sorted.

    With `year`, only recordings captured that year count, expired or not
    (a capture-cycle pull wants that cycle's photo even if a newer one has
    since superseded it -- same rule as list_recordings_in_bbox)."""
    # >>> OTI CORE: which panorama (the default pick: nearest current one) -------
    # Ask Cyclomedia's Atlas for every recording in a small box around the
    # point (radius_deg 0.001 = about 110 m north-south, 85 m east-west) that
    # hasn't expired (a newer drive replaces an expired one), or with `year`,
    # recorded that year. Then take the closest by straight-line distance.
    date_filter = (
        _year_bounds_filter(year) if year is not None
        else "<PropertyIsNull><PropertyName>expiredAt</PropertyName></PropertyIsNull>"
    )
    bbox_filter = (
        "<Filter><And>"
        "<BBOX><gml:Envelope srsName='EPSG:4326'>"
        f"<gml:lowerCorner>{lon - radius_deg} {lat - radius_deg}</gml:lowerCorner>"
        f"<gml:upperCorner>{lon + radius_deg} {lat + radius_deg}</gml:upperCorner>"
        "</gml:Envelope></BBOX>"
        f"{date_filter}"
        "</And></Filter>"
    )
    params = {
        "service": "WFS",
        "version": "1.1.0",
        "request": "GetFeature",
        "typeName": "atlas:Recording",
        "srsName": "EPSG:4326",
        "filter": bbox_filter,
        "outputFormat": "application/json",
    }
    resp = requests.get(ATLAS_WFS_URL, params=params, auth=_auth(), timeout=timeout)
    if resp.status_code != 200:
        raise CyclomediaError(f"WFS lookup failed: {resp.status_code} {resp.text[:300]}")

    features = resp.json().get("features", [])
    if not features:
        return None
    return min(features, key=lambda f: _feature_distance_sq(f, lat, lon))
    # <<< OTI CORE end ---------------------------------------------------------


def first_recording_in_bbox(min_lat, min_lon, max_lat, max_lon, recorded_after=None, year=None, timeout=30):
    """Asks for ONE recording in the area -- an existence check, not a
    listing, so it sidesteps the large-bbox paging problems documented in
    fetch_corner_coverage.py. recorded_after ("YYYY-MM-DDTHH:MM:SS"): only
    recordings captured after it. year: only that capture year. Neither:
    any current (non-expired) recording. Confirmed live 2026-10-04 against
    cb306: answers in one request and carries datasetName, Cyclomedia's
    release id (e.g. "US-NYCS-260405"). Returns {"recording_id",
    "recorded_at", "dataset_name"} or None."""
    if recorded_after is not None:
        date_filter = (
            f"<PropertyIsGreaterThan><PropertyName>{RECORDING_DATE_FIELD}</PropertyName>"
            f"<Literal>{recorded_after}</Literal></PropertyIsGreaterThan>"
        )
    elif year is not None:
        date_filter = _year_bounds_filter(year)
    else:
        date_filter = "<PropertyIsNull><PropertyName>expiredAt</PropertyName></PropertyIsNull>"
    params = {
        "service": "WFS",
        "version": "1.1.0",
        "request": "GetFeature",
        "typeName": "atlas:Recording",
        "srsName": "EPSG:4326",
        "maxFeatures": 1,
        "outputFormat": "application/json",
        "filter": (
            "<Filter><And>"
            "<BBOX><gml:Envelope srsName='EPSG:4326'>"
            f"<gml:lowerCorner>{min_lon} {min_lat}</gml:lowerCorner>"
            f"<gml:upperCorner>{max_lon} {max_lat}</gml:upperCorner>"
            "</gml:Envelope></BBOX>"
            f"{date_filter}"
            "</And></Filter>"
        ),
    }
    resp = requests.get(ATLAS_WFS_URL, params=params, auth=_auth(), timeout=timeout)
    if resp.status_code != 200:
        raise CyclomediaError(f"WFS lookup failed: {resp.status_code} {resp.text[:300]}")
    features = resp.json().get("features", [])
    if not features:
        return None
    feature = features[0]
    return {
        "recording_id": _feature_image_id(feature),
        "recorded_at": _parse_recorded_at(feature),
        "dataset_name": feature.get("properties", {}).get("datasetName"),
    }


def find_nearest_recording(lat, lon, radius_deg=0.001, timeout=30, year=None):
    """Returns the nearest recording's imageId (str), or None if nothing is
    within radius_deg. See _nearest_feature for the underlying lookup."""
    feature = _nearest_feature(lat, lon, radius_deg, timeout, year=year)
    if feature is None:
        return None
    return _feature_image_id(feature)


def find_nearest_recording_with_metadata(lat, lon, radius_deg=0.001, timeout=30, year=None):
    """Like find_nearest_recording, but also returns when the Cyclomedia car
    actually took the picture. Returns (recording_id, recorded_at) -- both
    None if nothing is within radius_deg; recorded_at alone is None if the
    feature has no RECORDING_DATE_FIELD value (shouldn't happen for a real
    live response, but degrade rather than raise). Reuses the exact same
    closest-feature lookup as find_nearest_recording, not a second,
    possibly-diverging implementation."""
    feature = _nearest_feature(lat, lon, radius_deg, timeout, year=year)
    if feature is None:
        return None, None
    return _feature_image_id(feature), _parse_recorded_at(feature)


def find_recording_metadata_by_id(image_id, timeout=30):
    """Looks up a SPECIFIC, already-known recording_id's metadata directly
    (an exact WFS PropertyIsEqualTo match on imageId), not a lat/lon
    proximity search -- for backfilling recorded_at onto an existing
    manifest entry that already has a cached recording_id, where a fresh
    proximity search could return a different (e.g. newer) recording than
    the one actually used originally. Returns (recording_id, recorded_at),
    both None if no feature matches image_id. Confirmed live 2026-08-25."""
    id_filter = (
        "<Filter><PropertyIsEqualTo>"
        "<PropertyName>imageId</PropertyName>"
        f"<Literal>{image_id}</Literal>"
        "</PropertyIsEqualTo></Filter>"
    )
    params = {
        "service": "WFS",
        "version": "1.1.0",
        "request": "GetFeature",
        "typeName": "atlas:Recording",
        "srsName": "EPSG:4326",
        "filter": id_filter,
        "outputFormat": "application/json",
    }
    resp = requests.get(ATLAS_WFS_URL, params=params, auth=_auth(), timeout=timeout)
    if resp.status_code != 200:
        raise CyclomediaError(f"WFS lookup failed: {resp.status_code} {resp.text[:300]}")

    features = resp.json().get("features", [])
    if not features:
        return None, None
    feature = features[0]
    return _feature_image_id(feature), _parse_recorded_at(feature)


def find_recording_coords_by_id(image_id, timeout=30):
    """Looks up a SPECIFIC, already-known recording_id's own real
    coordinates (an exact WFS PropertyIsEqualTo match on imageId, same
    query shape as find_recording_metadata_by_id -- mirrors it exactly,
    just returns coordinates instead of recorded_at). Returns (lat, lon),
    both None if no feature matches image_id or the feature has no
    geometry. Used to compute a real camera-to-sign bearing (see
    bearing_deg in tight_crop_lib.py) -- the recording's own position is
    needed, not the search point used to find it, since Cyclomedia
    recordings can sit a real distance from wherever they were searched
    from."""
    id_filter = (
        "<Filter><PropertyIsEqualTo>"
        "<PropertyName>imageId</PropertyName>"
        f"<Literal>{image_id}</Literal>"
        "</PropertyIsEqualTo></Filter>"
    )
    params = {
        "service": "WFS",
        "version": "1.1.0",
        "request": "GetFeature",
        "typeName": "atlas:Recording",
        "srsName": "EPSG:4326",
        "filter": id_filter,
        "outputFormat": "application/json",
    }
    resp = requests.get(ATLAS_WFS_URL, params=params, auth=_auth(), timeout=timeout)
    if resp.status_code != 200:
        raise CyclomediaError(f"WFS lookup failed: {resp.status_code} {resp.text[:300]}")

    features = resp.json().get("features", [])
    if not features:
        return None, None
    coords = _feature_coords(features[0])
    if coords is None:
        return None, None
    lon, lat = coords
    return lat, lon


def find_nearest_recording_at_date(lat, lon, before_date, radius_deg=0.001, timeout=30):
    """Like find_nearest_recording, but for a historical recording dated on
    or before `before_date` (a datetime.date) -- deliberately does NOT
    exclude expired recordings, since that's the whole point. Among
    recordings dated on/before the cutoff, picks the latest date (closest to
    the cutoff), breaking ties by distance. Returns None if the WFS returns
    no feature with a usable, sufficiently-old date.

    RECORDING_DATE_FIELD is unverified (see module-level comment) -- this
    function is not safe to trust at scale until a live spike confirms it."""
    bbox_filter = (
        "<Filter>"
        "<BBOX><gml:Envelope srsName='EPSG:4326'>"
        f"<gml:lowerCorner>{lon - radius_deg} {lat - radius_deg}</gml:lowerCorner>"
        f"<gml:upperCorner>{lon + radius_deg} {lat + radius_deg}</gml:upperCorner>"
        "</gml:Envelope></BBOX>"
        "</Filter>"
    )
    params = {
        "service": "WFS",
        "version": "1.1.0",
        "request": "GetFeature",
        "typeName": "atlas:Recording",
        "srsName": "EPSG:4326",
        "filter": bbox_filter,
        "outputFormat": "application/json",
    }
    resp = requests.get(ATLAS_WFS_URL, params=params, auth=_auth(), timeout=timeout)
    if resp.status_code != 200:
        raise CyclomediaError(f"WFS lookup failed: {resp.status_code} {resp.text[:300]}")

    candidates = []
    for feature in resp.json().get("features", []):
        raw_date = feature.get("properties", {}).get(RECORDING_DATE_FIELD)
        if not raw_date:
            continue
        recorded = datetime.fromisoformat(raw_date.replace("Z", "+00:00")).date()
        if recorded <= before_date:
            candidates.append((recorded, feature))

    if not candidates:
        return None

    _, best_feature = max(
        candidates, key=lambda pair: (pair[0], -_feature_distance_sq(pair[1], lat, lon))
    )
    return _feature_image_id(best_feature)


# Safety cap on paginated WFS requests: a real community-board bbox is
# expected to return far fewer than this many pages. If the server ever
# ignores startIndex/count (a real risk -- those are WFS 2.0.0 paging
# params, but this function requests version 1.1.0, whose real paging
# param is maxFeatures) and keeps returning the same page, this raises
# rather than silently returning a truncated result or looping forever
# against a metered API.
MAX_COVERAGE_PAGES = 50


def list_recordings_in_bbox(min_lat, min_lon, max_lat, max_lon, year=None, page_size=1000, timeout=30):
    """Returns every Cyclomedia recording in the given bbox (EPSG:4326),
    optionally restricted to recordings whose RECORDING_DATE_FIELD falls
    within `year`. Non-expired recordings only when `year` is None (the
    "current coverage" case); when `year` IS given, expired recordings are
    NOT excluded -- a historical-year query should still be able to find a
    recording from that year even if it has since been superseded by a
    newer capture. Unlike _nearest_feature's tiny point-radius bbox, this
    is meant for a real caller-supplied area -- paginates via WFS's own
    startIndex/count params (the real per-request feature cap isn't
    confirmed, so this requests page_size at a time and keeps going until
    a page comes back short), up to MAX_COVERAGE_PAGES pages -- past that,
    or if a page repeats already-seen recordings (the server may be
    ignoring startIndex/count), raises rather than looping indefinitely or
    silently truncating. Returns a list of {"recording_id", "lat",
    "lon", "recorded_at"} dicts, reusing _feature_image_id/_feature_coords/
    _parse_recorded_at so a feature's shape is interpreted identically
    everywhere in this module. Raises CyclomediaError on a non-200
    response, same convention as every other function in this module."""
    year_filter = _year_bounds_filter(year) if year is not None else ""
    # A year-filtered (historical) query must NOT exclude expired/
    # superseded recordings -- a historical-year query is exactly the
    # case where the recording you want has since been superseded (same
    # rationale as find_nearest_recording_at_date, which drops this
    # exclusion entirely for date-based historical lookups). Only the
    # "give me current coverage" case (year=None) requires a still-valid
    # recording.
    expired_filter = (
        "" if year is not None
        else "<PropertyIsNull><PropertyName>expiredAt</PropertyName></PropertyIsNull>"
    )
    bbox_filter = (
        "<Filter><And>"
        "<BBOX><gml:Envelope srsName='EPSG:4326'>"
        f"<gml:lowerCorner>{min_lon} {min_lat}</gml:lowerCorner>"
        f"<gml:upperCorner>{max_lon} {max_lat}</gml:upperCorner>"
        "</gml:Envelope></BBOX>"
        f"{expired_filter}"
        f"{year_filter}"
        "</And></Filter>"
    )

    recordings = []
    seen_ids = set()
    start_index = 0
    for _ in range(MAX_COVERAGE_PAGES):
        params = {
            "service": "WFS",
            "version": "1.1.0",
            "request": "GetFeature",
            "typeName": "atlas:Recording",
            "srsName": "EPSG:4326",
            "filter": bbox_filter,
            "outputFormat": "application/json",
            "startIndex": start_index,
            "count": page_size,
        }
        resp = requests.get(ATLAS_WFS_URL, params=params, auth=_auth(), timeout=timeout)
        if resp.status_code != 200:
            raise CyclomediaError(f"WFS lookup failed: {resp.status_code} {resp.text[:300]}")

        features = resp.json().get("features", [])
        page_ids = {_feature_image_id(f) for f in features}
        if features and page_ids <= seen_ids:
            raise CyclomediaError(
                "list_recordings_in_bbox: WFS server returned an already-seen page -- "
                "it may be ignoring the startIndex/count pagination params. Aborting "
                "rather than risking a silently truncated result across pages."
            )

        for feature in features:
            rid = _feature_image_id(feature)
            if rid in seen_ids:
                # WFS 1.1.0 gives no guaranteed stable ordering across
                # paged requests without an explicit sortBy -- a server
                # could return partially (not fully) overlapping pages,
                # which the above already-seen-page check wouldn't catch.
                # Skip rather than duplicate; seen_ids is already tracked
                # for the page-level check, so this is free.
                continue
            seen_ids.add(rid)
            coords = _feature_coords(feature)
            recordings.append({
                "recording_id": rid,
                "lat": coords[1] if coords else None,
                "lon": coords[0] if coords else None,
                "recorded_at": _parse_recorded_at(feature),
            })

        if len(features) < page_size:
            break
        start_index += page_size
    else:
        raise CyclomediaError(
            f"list_recordings_in_bbox: exceeded {MAX_COVERAGE_PAGES} pages without the "
            "server signaling completion -- aborting rather than looping indefinitely "
            "against a metered API."
        )

    return recordings


def find_best_recording(lat, lon, street_bearing_deg, max_meters=15.0, angle_tolerance_deg=20.0, year=None, list_recordings_fn=None, timeout=30):
    """Picks the best Cyclomedia recording for a sign/corner at (lat, lon)
    whose street runs along street_bearing_deg (a real LION segment
    bearing -- see lion_bearing_lookup.nearest_street_bearing). "Best"
    is NOT "closest": distance only ever breaks ties among candidates
    that are already within angle_tolerance_deg of a perpendicular
    (face-on) approach to the street. A closer-but-oblique candidate
    never wins over a farther-but-head-on one -- Karim's explicit call,
    made after live validation this session showed distance alone barely
    predicts legibility (five sample corners at effectively their
    closest possible recording split roughly 50/50 legible vs. not), while
    approach angle relative to the street does. Returns None if nothing
    within max_meters passes the angle filter, rather than falling back
    to a worse shot -- same "fail loudly, don't ship a bad guess"
    convention fetch_damaged_signs_panoramas.closest_recording_within
    already uses.

    The winning candidate's own "heading" key is computed dynamically
    (bearing_deg from ITS position to the target) rather than any fixed/
    predetermined heading -- a 360-degree Cyclomedia panorama can render
    any direction, so there's no reason to guess. This alone fixed the
    real motivating case for this function (cb211_117, Amethyst St &
    Sagamore St): the same 1.4m-away recording that was illegible at a
    fixed 225-degree heading reads "SAGAMORE ST" clearly once rendered
    facing the real computed bearing. See docs/superpowers/specs/
    2026-09-18-cyclomedia-best-recording-scoring-design.md.

    year defaults to None, meaning "current, non-expired recordings
    only" -- list_recordings_in_bbox's own existing default. Passing a
    real year is reserved for a future historical-matching use case, not
    exercised by anything in this codebase yet."""
    # >>> OTI CORE: which panorama (capture-cycle pick: head-on beats close) ----
    # 1. Every recording within max_meters (15 m) of the corner.
    # 2. Keep only those looking at the street within 20 degrees of straight on
    #    (a sign read at a slant is often illegible, even from close up).
    # 3. Of those, the closest wins. Its heading is computed from its own
    #    position to the corner, not guessed.
    list_recordings_fn = list_recordings_fn or list_recordings_in_bbox
    dlat = meters_to_degrees_lat(max_meters)
    dlon = meters_to_degrees_lon(max_meters, lat)
    candidates = list_recordings_fn(lat - dlat, lon - dlon, lat + dlat, lon + dlon, year=year, timeout=timeout)

    in_range = []
    for r in candidates:
        if r.get("lat") is None or r.get("lon") is None:
            continue
        distance_m = haversine_meters(lat, lon, r["lat"], r["lon"])
        if distance_m <= max_meters:
            in_range.append((distance_m, r))
    if not in_range:
        return None

    qualifying = []
    for distance_m, r in in_range:
        heading = bearing_deg(r["lat"], r["lon"], lat, lon)
        angle = angle_off_perpendicular(heading, street_bearing_deg)
        if angle >= (90 - angle_tolerance_deg):
            qualifying.append((distance_m, r, heading, angle))
    if not qualifying:
        return None

    qualifying.sort(key=lambda item: item[0])
    distance_m, r, heading, angle = qualifying[0]
    return {
        "recording_id": r["recording_id"],
        "lat": r["lat"],
        "lon": r["lon"],
        "recorded_at": r.get("recorded_at"),
        "heading": heading,
        "distance_m": distance_m,
        "angle_off_perpendicular_deg": angle,
    }
    # <<< OTI CORE end ---------------------------------------------------------


def _render(recording_id, heading, width, height, fov, pitch, timeout):
    # >>> OTI CORE: turning a 360-degree panorama into a flat photo -----------
    # Atlas Render cuts a normal (rectilinear) photo out of the panorama:
    # yaw = compass direction to look (0 = north), hfov = how wide (degrees),
    # pitch = tilt up/down, width/height = output pixels.
    url = ATLAS_RENDER_URL.format(recording_id=recording_id)
    params = {
        "width": width,
        "height": height,
        "srsName": "EPSG:4326",
        "yaw": heading,
        "hfov": fov,
        "apiKey": _api_key(),
    }
    if pitch is not None:
        params["pitch"] = pitch
    # <<< OTI CORE end ---------------------------------------------------------
    resp = requests.get(url, params=params, auth=_auth(), timeout=timeout)
    if resp.status_code != 200:
        raise CyclomediaError(
            f"Image fetch failed for recording {recording_id}: {resp.status_code} {resp.text[:300]}"
        )
    return resp


def render_recording(recording_id, heading, width=1600, height=1200, fov=75, timeout=30, pitch=None):
    """Renders a rectilinear (non-panoramic) image from a known Cyclomedia
    `recording_id`, looking in the given compass `heading` (degrees, 0=North,
    via the Render operation's `yaw` + `srsName=EPSG:4326`). `pitch` tilts the
    view (degrees, positive = up; confirmed live 2026-10-05, the response's
    Render-Pitch header echoes it); left out of the request when None, so
    the render stays level as before. Raises CyclomediaError on any failure,
    with the raw response body included so a 401/404 can be diagnosed.
    Returns raw JPEG bytes on success."""
    return _render(recording_id, heading, width, height, fov, pitch, timeout).content


# Response headers worth keeping from a render: capture date, the render's
# actual yaw/pitch/fov/focal length, and the camera position including
# RecordingLocation-GroundLevelOffset (camera height above ground, metres
# when srsName is EPSG:4326), which aim_geometry.pitch_deg needs.
RENDER_HEADER_PREFIXES = ("Recording-", "Render-", "RecordingLocation-")


def render_recording_with_headers(recording_id, heading, width=1600, height=1200, fov=75, timeout=30,
                                  pitch=None):
    """Same request as render_recording(), but returns (jpeg_bytes, headers)
    where headers keeps only the RENDER_HEADER_PREFIXES keys. Recording-Date
    here is the capture time even for renders whose recording didn't come
    from a WFS lookup carrying recordedAt."""
    resp = _render(recording_id, heading, width, height, fov, pitch, timeout)
    headers = {k: v for k, v in dict(resp.headers or {}).items() if k.startswith(RENDER_HEADER_PREFIXES)}
    return resp.content, headers


def fetch_cyclomedia_image(lat, lon, heading, width=1600, height=1200, fov=75, timeout=30):
    """Fetches a rectilinear image from the Cyclomedia recording nearest
    (lat, lon). Thin convenience wrapper combining find_nearest_recording +
    render_recording for callers that don't need to reuse one recording
    lookup across multiple renders."""
    recording_id = find_nearest_recording(lat, lon, timeout=timeout)
    if recording_id is None:
        raise CyclomediaError(f"No Cyclomedia recording found near ({lat}, {lon}).")
    return render_recording(recording_id, heading, width, height, fov, timeout)


def compass_from_sign_location(sign_location):
    """Ports extension/content.js's compassFromSignLocation(): classifies a
    SIMS sign_location string into one of the 8 compass corners, or None if
    it's a median/mall/apex/offset placement rather than a real corner. See
    the JS version's comment for the NYC DOT sign_location vocabulary this
    is based on."""
    s = (sign_location or "").strip().upper()
    m = re.match(r"^([NS])/([EW])\s*C(URB)?\b", s)
    if m:
        return m.group(1) + m.group(2)
    m = re.match(r"^([NSEW])\s*C(URB)?\b", s)
    if m:
        return m.group(1)
    return None


def heading_candidates_for_corner(sign_location):
    """Approximate camera heading (degrees) to point toward a sign given its
    SIMS sign_location, for an unattended fetch with no human aiming the
    camera. This is a known accuracy limitation (a quadrant-level guess, not
    a computed bearing) -- pair with a wide hfov in render_recording/
    fetch_cyclomedia_image to absorb the imprecision. Returns None when
    sign_location isn't a classifiable corner (see compass_from_sign_location)."""
    # >>> OTI CORE: which way the camera looks (default pick) -----------------
    # SIMS's sign_location ("N/E C" = northeast corner) becomes a compass
    # direction (NE = 45 degrees). A quadrant guess, so renders use a wide
    # 120-degree view to make sure the corner is in frame.
    compass = compass_from_sign_location(sign_location)
    if compass is None:
        return None
    return COMPASS_TO_HEADING[compass]
    # <<< OTI CORE end ---------------------------------------------------------
