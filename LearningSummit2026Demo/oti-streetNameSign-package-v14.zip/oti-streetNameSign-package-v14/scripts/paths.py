"""
The single source of every data location this app uses.

Where data lives is a per-machine setting: DATA_DIR in the app's .env
(written by the setup wizard). It can be a local folder (D:\\signs-data)
or a shared network folder (\\\\server\\share\\signs-data) that several
workstations use at the same time. When DATA_DIR is unset or blank, data
lives in <app>/data, which is exactly where every script kept it before
this setting existed, so the dev repo works unchanged.

Every function reads the environment when called (not at import time),
so a test can point DATA_DIR somewhere else with monkeypatch.setenv.
Scripts that keep module-level constants (e.g. ANNOTATIONS_DB_PATH =
paths.annotations_db()) still evaluate once at import, same as before.

An unreachable custom data folder is never papered over: nothing falls
back to, or creates, an empty local folder. The hub shows
data_dir_problem() as a banner; command-line scripts call
require_data_dir() and exit with the same message.

Usage:
    import paths
    paths.annotations_db()
    paths.require_data_dir()   # at the top of a CLI script's main block
"""
import os
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
APP_ROOT = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))
import pipeline_config  # noqa: E402,F401  (loads <app>/.env into the environment)

UNREACHABLE_TEMPLATE = "Can't reach data folder {path}. Check the network or change it in Settings."


class DataDirUnreachable(RuntimeError):
    """Raised when something tries to open a file inside a custom DATA_DIR
    that can't be reached (network down, share renamed, drive missing)."""


def _configured_value():
    raw = os.environ.get("DATA_DIR") or ""
    return raw.strip().strip('"').strip("'").strip()


def is_custom_data_dir() -> bool:
    return bool(_configured_value())


def data_dir() -> Path:
    value = _configured_value()
    return Path(value) if value else APP_ROOT / "data"


def data_dir_problem(path=None):
    """None when the data folder is usable, else the user-facing message.
    Only a custom DATA_DIR can be "unreachable": the default <app>/data is
    created on demand by the scripts that write there, as it always was."""
    if path is None:
        if not is_custom_data_dir():
            return None
        path = data_dir()
    path = Path(path)
    try:
        ok = path.is_dir()
    except OSError:
        ok = False
    if ok:
        return None
    return UNREACHABLE_TEMPLATE.format(path=path)


def require_data_dir() -> Path:
    """For command-line scripts: returns the data folder, or prints the
    unreachable message to stderr and exits with code 2."""
    problem = data_dir_problem()
    if problem:
        print(problem, file=sys.stderr)
        raise SystemExit(2)
    return data_dir()


def is_inside_data_dir(path) -> bool:
    try:
        Path(os.path.abspath(path)).relative_to(Path(os.path.abspath(data_dir())))
        return True
    except ValueError:
        return False


def data_path(*parts) -> Path:
    return data_dir().joinpath(*parts)


def annotations_db() -> Path:
    return data_path("annotations.db")


def reports_dir() -> Path:
    return data_path("reports")


def review_db() -> Path:
    return reports_dir() / "review.db"


def signs_db() -> Path:
    return data_path("signs.db")


def panoramas_root() -> Path:
    return data_path("cyclomedia_panoramas")


def models_dir() -> Path:
    return data_path("models")


def backups_dir() -> Path:
    return data_path("backups")


def lion_corners() -> Path:
    return data_path("lion_corners.json")


def lion_network_db() -> Path:
    return data_path("lion_network.db")


def lion_matches_db() -> Path:
    return data_path("lion_matches.db")


def coverage_dir() -> Path:
    return data_path("cyclomedia_coverage")


def community_districts_geojson() -> Path:
    return data_path("community_districts.geojson")


def raw_images_dir() -> Path:
    return data_path("raw_images")


def processed_dir() -> Path:
    return data_path("processed")


def dataset_dir(name: str) -> Path:
    """A YOLO dataset folder, e.g. dataset_dir("yolo_dataset_spatial")."""
    return data_path(name)


# Local to this app install (never on the shared drive): regenerated on
# every training run, so two machines never fight over one file.
RUNTIME_YAML_DIR = APP_ROOT / "yolo" / "_runtime"


def runtime_dataset_yaml(shipped_yaml, dataset_name: str) -> Path:
    """The shipped yolo/*.yaml files keep whatever `path:` they ship with
    (a relative ../data/... in the package, an absolute path in the dev
    repo) and are never edited at runtime. Training instead gets a copy,
    written to RUNTIME_YAML_DIR, whose `path:` line is this machine's real
    dataset folder under DATA_DIR. Every other line is kept as-is."""
    shipped_yaml = Path(shipped_yaml)
    new_path = dataset_dir(dataset_name).as_posix()
    lines = shipped_yaml.read_text(encoding="utf-8").splitlines(keepends=True)
    out_lines = []
    for line in lines:
        if line.startswith("path:"):
            newline = "\n" if line.endswith("\n") else ""
            out_lines.append(f"path: {new_path}{newline}")
        else:
            out_lines.append(line)
    RUNTIME_YAML_DIR.mkdir(parents=True, exist_ok=True)
    out = RUNTIME_YAML_DIR / shipped_yaml.name
    out.write_text("".join(out_lines), encoding="utf-8")
    return out
