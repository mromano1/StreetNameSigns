"""Pure geometry + lookup logic for turning an annotation-tool box into the
inputs needed for a tighter Cyclomedia re-render. Kept separate from
serve_tight_crop.py so it's testable without FastAPI or a real Cyclomedia
call -- same split as physical_predict_lib.py vs serve_physical_model.py.
See docs/superpowers/specs/2026-08-12-annotation-tool-ml-assist-design.md.
"""
import io
import json
import math
from datetime import datetime
from pathlib import Path

from PIL import Image


def bearing_deg(from_lat, from_lon, to_lat, to_lon):
    """Standard initial bearing (forward azimuth) from (from_lat, from_lon)
    to (to_lat, to_lon), in degrees, always 0-360 (0=North, 90=East). Used
    to compute a REAL camera-to-sign heading from two real coordinates --
    replaces the old 8-way compass-quadrant guess
    (cyclomedia_client.heading_candidates_for_corner) for the tight-crop
    re-render, which was confirmed live 2026-09-09 to be off by 2.5-3.4
    degrees for a box needing extreme zoom (see
    docs/superpowers/specs/2026-09-09-tight-crop-real-bearing-design.md)."""
    lat1 = math.radians(from_lat)
    lat2 = math.radians(to_lat)
    dlon = math.radians(to_lon - from_lon)
    x = math.sin(dlon) * math.cos(lat2)
    y = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
    return (math.degrees(math.atan2(x, y)) + 360) % 360


def box_to_heading_fov(box, image_width, image_height, original_heading, original_hfov, padding_factor=2.5, min_fov=5.0):
    """box: {"x", "y", "w", "h"} in the native pixel space of the original
    render (image_width x image_height pixels, hfov=original_hfov degrees,
    centered on original_heading degrees). Returns a dict:
      {"heading", "hfov", "height", "top_angle", "bottom_angle"}
    "heading"/"hfov" are what to request horizontally. "height" is the
    OUTPUT height to request at RENDER_WIDTH (fixed) and "hfov", so the
    resulting image's implied vertical FOV is wide enough to still include
    the box -- deliberately oversized, not tight, since there's no way to
    aim vertically (see below). "top_angle"/"bottom_angle" are the box's
    own RAW, unpadded vertical bounds (degrees from the render's pitch=0
    center) -- pass these to vertical_crop_pixels() once the real image
    comes back, to crop the oversized render down to just the box.

    Horizontal: uses the rectilinear (pinhole-camera) projection formula --
    angle = atan(x_frac * tan(hfov/2)) -- not a linear pixel-to-degree scale,
    since a wide-hfov rectilinear render compresses angle differently near
    the edges than the center. Confirmed correct against real off-center
    boxes on both sides (2026-08-14: a box on the image's left edge and one
    on the right edge each correctly returned the real content at that
    position, not a mirrored/wrong result).

    Vertical: there is no pitch parameter in the Cyclomedia render API --
    confirmed empirically (2026-08-14) that a box near the top of a wide
    capture came back showing ground-level content instead, because the
    render is always centered on the same level pitch as the original
    capture no matter where the box is vertically. Since we can't aim
    vertically at the box, this instead requests a tall enough output that
    the box's vertical extent -- however far above/below center -- still
    falls within a pitch-unchanged, symmetric-about-center view. This is
    about size, not direction: unlike heading, there's no "wrong sign" risk
    for this half of the calculation."""
    # >>> OTI CORE: how a box on a wide photo becomes a tight crop ------------
    # 1. Convert the box's pixel edges to angles (camera geometry, not a
    #    straight pixel-to-degree scale).
    # 2. Re-render from the same panorama, turned to face the box's centre,
    #    with a field of view 2.5x the box's width (zoomed in, more pixels on
    #    the sign) and tall enough to include it (the API can't tilt here).
    # 3. Once that render comes back, horizontal_crop_pixels and
    #    vertical_crop_pixels trim it to the box plus 50% padding.
    half_hfov_rad = math.radians(original_hfov / 2)
    half_width = image_width / 2

    def angle_at(px):
        x_frac = (px - half_width) / half_width
        return math.degrees(math.atan(x_frac * math.tan(half_hfov_rad)))

    center_angle = angle_at(box["x"] + box["w"] / 2)
    left_angle = angle_at(box["x"])
    right_angle = angle_at(box["x"] + box["w"])

    new_heading = (original_heading + center_angle) % 360
    box_angular_width = abs(right_angle - left_angle)
    new_hfov = max(box_angular_width * padding_factor, min_fov)
    # <<< OTI CORE end (the vertical sizing below follows the same idea) -------

    # Vertical FOV implied by the original capture's own hfov + aspect
    # ratio (standard rectilinear relationship: vfov grows/shrinks with hfov
    # at a fixed width:height).
    original_vfov = 2 * math.degrees(math.atan(math.tan(half_hfov_rad) * image_height / image_width))
    half_vfov_rad = math.radians(original_vfov / 2)
    half_height = image_height / 2

    def vertical_angle_at(py):
        y_frac = (py - half_height) / half_height
        return math.degrees(math.atan(y_frac * math.tan(half_vfov_rad)))

    top_angle = vertical_angle_at(box["y"])
    bottom_angle = vertical_angle_at(box["y"] + box["h"])
    # Symmetric about the (unmovable) pitch=0 center -- governed by
    # whichever edge is angularly farther out, not the box's own height.
    max_vertical_offset = max(abs(top_angle), abs(bottom_angle))
    new_vfov = max(max_vertical_offset * padding_factor, min_fov)

    # Back out the output height (at fixed RENDER_WIDTH == image_width and
    # the new_hfov already computed) that delivers this vfov.
    new_height = image_width * math.tan(math.radians(new_vfov / 2)) / math.tan(math.radians(new_hfov / 2))

    # Raw, unpadded horizontal bounds, already relative to new_heading (the
    # render's own re-aimed center) -- since heading is set to the box's
    # own center_angle, the box always sits symmetrically about zero here
    # regardless of how far off-center it was in the ORIGINAL wide capture.
    # Mirrors top_angle/bottom_angle: used by horizontal_crop_pixels() to
    # crop the delivered render back down to just the box, the same way
    # vertical_crop_pixels() already does for the vertical axis.
    half_box_angular_width = box_angular_width / 2
    left_angle = -half_box_angular_width
    right_angle = half_box_angular_width

    return {
        "heading": new_heading,
        "hfov": new_hfov,
        "height": new_height,
        "top_angle": top_angle,
        "bottom_angle": bottom_angle,
        "left_angle": left_angle,
        "right_angle": right_angle,
    }


def apply_max_height_cap(framing, max_height, max_hfov):
    """framing: a dict from box_to_heading_fov (heading/hfov/height/
    top_angle/bottom_angle). If framing["height"] already fits within
    max_height, returns it unchanged (degraded=False).

    Otherwise widens hfov -- trading horizontal tightness for the box
    staying reachable within the Atlas Render API's real height ceiling
    (confirmed live: a request above 8192px gets rejected). There's no
    pitch parameter in the render API (see box_to_heading_fov), so
    height/hfov are the only two levers; the original bug clamped height
    down without ever widening hfov to compensate, so the delivered
    render's real vertical reach fell short of the box.

    Uses the invariant K = image_width * tan(radians(new_vfov)/2), which
    the already-computed framing["height"]/framing["hfov"] let us recover
    as height * tan(radians(hfov)/2) -- without needing image_width
    directly, since K is fixed by the box's vertical extent (new_vfov)
    before this function ever runs, independent of which hfov it
    ultimately picks. height(hfov) = K / tan(radians(hfov)/2) is strictly
    decreasing in hfov, so solving height(hfov) == max_height for hfov
    gives exactly the minimum hfov that brings height down to the cap.

    max_hfov is a sanity ceiling (pass the original wide capture's own
    hfov) -- widening past it just re-derives the wide capture with no
    zoom benefit. If even max_hfov isn't enough to bring height under
    max_height, hfov is clamped to max_hfov, height is clamped to
    max_height, and degraded=True is returned -- the crop may not fully
    reach the box; callers should log this rather than silently
    pretending success."""
    precap_hfov = framing["hfov"]
    precap_height = framing["height"]
    if precap_height <= max_height:
        return {**framing, "degraded": False}

    k = precap_height * math.tan(math.radians(precap_hfov) / 2)
    min_hfov_needed = 2 * math.degrees(math.atan(k / max_height))
    candidate_hfov = max(precap_hfov, min_hfov_needed)
    degraded = candidate_hfov > max_hfov
    final_hfov = min(candidate_hfov, max_hfov)
    final_height = min(k / math.tan(math.radians(final_hfov) / 2), max_height)

    return {**framing, "hfov": final_hfov, "height": final_height, "degraded": degraded}


def vertical_crop_pixels(top_angle, bottom_angle, rendered_width, rendered_height, rendered_hfov, padding_factor=1.5, min_fov=5.0):
    """Given a box's raw vertical bounds (top_angle/bottom_angle, from
    box_to_heading_fov -- degrees from center) and the dimensions/hfov of
    an ALREADY-RENDERED image, returns (crop_top_px, crop_bottom_px): the
    pixel row range to crop that image down to, so the saved/displayed
    result is tight around the box instead of the full, deliberately
    oversized render.

    The rendered image's own vertical center is the same pitch=0 reference
    top_angle/bottom_angle were computed against -- the render never moves
    pitch, only its height/hfov change, so that reference carries over
    unchanged. Pass the ACTUAL rendered_height (after any clamping, e.g.
    to the Atlas Render API's real size limit) and rendered_hfov -- not
    the pre-clamp ideal values -- since this depends on what was really
    delivered, not what was originally requested."""
    rendered_vfov = 2 * math.degrees(math.atan(
        math.tan(math.radians(rendered_hfov / 2)) * rendered_height / rendered_width
    ))
    half_vfov_rad = math.radians(rendered_vfov / 2)
    half_height = rendered_height / 2

    def px_at(angle):
        return half_height + half_height * (math.tan(math.radians(angle)) / math.tan(half_vfov_rad))

    box_angular_height = abs(bottom_angle - top_angle)
    center_angle = (top_angle + bottom_angle) / 2
    half_crop_vfov = max(box_angular_height / 2 * padding_factor, min_fov / 2)

    crop_top_px = px_at(center_angle - half_crop_vfov)
    crop_bottom_px = px_at(center_angle + half_crop_vfov)
    crop_top_px = max(0, min(rendered_height, crop_top_px))
    crop_bottom_px = max(0, min(rendered_height, crop_bottom_px))
    return round(crop_top_px), round(crop_bottom_px)


def horizontal_crop_pixels(left_angle, right_angle, rendered_width, rendered_hfov, padding_factor=1.5, min_fov=5.0):
    """Given a box's raw horizontal bounds (left_angle/right_angle, from
    box_to_heading_fov -- degrees from the render's own heading center,
    already re-aimed at the box's center) and an ALREADY-RENDERED image's
    width/hfov, returns (crop_left_px, crop_right_px): the pixel column
    range to crop that image down to, so the saved/displayed result is
    tight around the box instead of the full, possibly-widened render.

    Mirrors vertical_crop_pixels, but simpler: rendered_hfov already IS
    the horizontal field of view directly, with no aspect-ratio derivation
    needed the way vertical_crop_pixels has to derive vfov from hfov.

    This is the fix for a real bug found live 2026-09-09: apply_max_height_
    cap widens hfov to keep a box vertically reachable within the render
    API's height ceiling, but nothing previously cropped the resulting
    wider horizontal frame back down -- the delivered "tight crop" could
    show content up to 2x wider than the actual box, unrelated to what was
    drawn. Pass the ACTUAL rendered_hfov (after any such widening), not the
    pre-cap ideal value, same convention as vertical_crop_pixels."""
    half_width = rendered_width / 2
    half_hfov_rad = math.radians(rendered_hfov / 2)

    def px_at(angle):
        return half_width + half_width * (math.tan(math.radians(angle)) / math.tan(half_hfov_rad))

    box_angular_width = abs(right_angle - left_angle)
    center_angle = (left_angle + right_angle) / 2
    half_crop_hfov = max(box_angular_width / 2 * padding_factor, min_fov / 2)

    crop_left_px = px_at(center_angle - half_crop_hfov)
    crop_right_px = px_at(center_angle + half_crop_hfov)
    crop_left_px = max(0, min(rendered_width, crop_left_px))
    crop_right_px = max(0, min(rendered_width, crop_right_px))
    return round(crop_left_px), round(crop_right_px)


def crop_image_horizontally(image_bytes, left_px, right_px):
    """Crops a JPEG's columns [left_px, right_px), keeping full height, and
    re-encodes as JPEG. Mirrors crop_image_vertically exactly, for the
    horizontal axis -- see horizontal_crop_pixels for why this exists.

    left_px/right_px are computed against an EXPECTED image size (the
    width actually requested from the render API). Same defensive
    degrade-to-unchanged behavior as crop_image_vertically if the real
    delivered image doesn't match, rather than producing a zero-width crop
    Pillow can't encode."""
    image = Image.open(io.BytesIO(image_bytes))
    width, height = image.size
    left_px = max(0, min(width, left_px))
    right_px = max(left_px, min(width, right_px))
    if right_px <= left_px:
        return image_bytes
    cropped = image.crop((left_px, 0, right_px, height))
    buf = io.BytesIO()
    cropped.save(buf, format="JPEG", quality=92)
    return buf.getvalue()


def crop_box_from_source_image(image_path, box):
    """Direct, un-rendered PIL crop of box {"x","y","w","h"} (native pixel
    space) from the wide panorama image already on disk at image_path --
    no Cyclomedia re-render call. Lower detail than a re-render, but always
    correctly positioned (it's a literal crop of the box's own drawn
    coordinates, no coordinate transform to get wrong). The fallback when
    no accurate bearing can be computed (see
    docs/superpowers/specs/2026-09-09-tight-crop-real-bearing-design.md,
    section 5) -- deliberately preferred over the old compass-guess
    re-render fallback, which could confidently show a different, wrong
    location (confirmed live 2026-09-09, corner cb211_022's "BLONDELL AV"
    box).

    Raises ValueError for a degenerate/inverted box (w<=0 or h<=0) instead
    of crashing inside PIL's crop()/save() -- reachable from the real UI:
    resizing a box's handle onto the opposite edge can produce w===0, and
    the tool fires a tight-crop request unconditionally on that move. This
    is a malformed-input case (caller's job to turn it into a 400), unlike
    crop_image_horizontally/crop_image_vertically's degrade-to-unchanged
    behavior for a mismatched EXPECTED-vs-delivered render size."""
    # >>> OTI CORE: the fallback crop -- cut the box straight out of the photo -
    # Used when the camera-to-sign direction is unknown, so a re-render could
    # point at the wrong spot. Fewer pixels, but always the right place.
    image = Image.open(image_path)
    left, top = int(box["x"]), int(box["y"])
    right, bottom = left + int(box["w"]), top + int(box["h"])
    if right <= left or bottom <= top:
        raise ValueError(f"degenerate box, cannot crop: {box}")
    cropped = image.crop((left, top, right, bottom)).convert("RGB")
    # <<< OTI CORE end ---------------------------------------------------------
    buf = io.BytesIO()
    cropped.save(buf, format="JPEG", quality=92)
    return buf.getvalue()


def crop_image_vertically(image_bytes, top_px, bottom_px):
    """Crops a JPEG's rows [top_px, bottom_px), keeping full width, and
    re-encodes as JPEG. Turns the API's deliberately oversized render
    (padded to guarantee vertical inclusion, given no pitch parameter --
    see box_to_heading_fov) into a genuinely tight result.

    top_px/bottom_px are computed against an EXPECTED image size (the
    height actually requested from the render API). If the real delivered
    image doesn't match -- a test double, or the API returning something
    unexpected -- clamping both to the same boundary would otherwise
    produce a zero-height crop, which Pillow can't encode at all. Degrade
    to returning the image unchanged rather than failing the whole
    request over a framing nicety."""
    image = Image.open(io.BytesIO(image_bytes))
    width, height = image.size
    top_px = max(0, min(height, top_px))
    bottom_px = max(top_px, min(height, bottom_px))
    if bottom_px <= top_px:
        return image_bytes
    cropped = image.crop((0, top_px, width, bottom_px))
    buf = io.BytesIO()
    cropped.save(buf, format="JPEG", quality=92)
    return buf.getvalue()


def _same_path(a, b):
    return str(a or "").replace("\\", "/").strip("/").lower() == str(b or "").replace("\\", "/").strip("/").lower()


def find_job(manifest, corner_id, image_kind, path=None):
    """manifest: parsed fetch_manifest.json dict. Returns the matching job
    dict, or None if no job with that corner_id/image_kind has a real file
    on disk. "ok" (fetched this run) and "skipped" (fetch_cyclomedia_
    panoramas.py found the file already there from an earlier run and
    didn't re-fetch it) both mean that -- only "failed" (no recording
    found / API error, no file exists) is excluded. A "skipped" job has no
    recording_id cached (that's only ever set on the fresh-fetch path);
    the caller has to re-resolve one -- see serve_tight_crop.py.

    path: the photo's own manifest path. A retrieval v3 corner can have
    several photos of one kind (a corner_zoom per aiming target), so when
    given, only the job for that exact file matches."""
    for job in manifest.get("jobs", []):
        if (
            job.get("corner_id") == corner_id
            and job.get("image_kind") == image_kind
            and job.get("status") in ("ok", "skipped")
            and (path is None or _same_path(job.get("path"), path))
        ):
            return job
    return None


def parse_recorded_at(raw):
    """Parses a manifest job's recorded_at field (an ISO8601 string, or
    None/missing for a job fetched before this was captured, or not yet
    backfilled -- see backfill_recording_metadata.py) back into a
    datetime, for use in tight_crop_relative_path's descriptive filename.
    Returns None for anything falsy or unparseable, rather than raising --
    a malformed/missing manifest value should degrade to the old filename
    scheme, not break a real crop request."""
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw)
    except ValueError:
        return None


def tight_crop_relative_path(corner_id, image_kind, box_index, heading=None, recorded_at=None, source_image=None):
    """Relative path (folder always == corner_id, unchanged) for a saved
    tight crop. When heading/recorded_at are both available (the source
    "latest" job's own heading, and when the Cyclomedia car took the
    picture -- NOT any per-box re-render heading serve_tight_crop.py
    computes, so every crop from the same job shares one stable value),
    uses a descriptive filename so the crop stays identifiable even
    outside its per-corner folder (Karim's real complaint: hundreds of
    one-image folders made crops painful to browse by search/regex).
    Falls back to the old "tight_<image_kind>_<box_index>.jpg" scheme when
    either is missing -- e.g. a job fetched before recorded_at capture
    existed and not yet backfilled.

    A retrieval v3 shot other than "latest" (corner_wide / corner_zoom /
    suggested_zoom, several per corner) is named after its source photo,
    whose name already carries kind, target, heading and tilt, so crops
    from two zooms of one corner can't overwrite each other."""
    if image_kind != "latest" and source_image:
        stem = Path(str(source_image).replace("\\", "/")).stem
        return f"{corner_id}/crop_{stem}_box{box_index}.jpg"
    if heading is None or recorded_at is None:
        return f"{corner_id}/tight_{image_kind}_{box_index}.jpg"
    return f"{corner_id}/crop_{corner_id}_h{round(heading):03d}_{recorded_at:%Y%m%d-%H%M%S}_box{box_index}.jpg"


def discover_manifest_paths(panoramas_dir):
    """Root fetch_manifest.json (the original/default collection, if
    present) plus one level of subfolder fetch_manifest.json files (each
    a separate --output-dir pull, e.g. demo_cb301/) -- the same discovery
    pattern list_panorama_datasets.py uses for the dropdown, so every
    dataset the annotation tool can select from is also searchable here."""
    panoramas_dir = Path(panoramas_dir)
    paths = []
    root = panoramas_dir / "fetch_manifest.json"
    if root.exists():
        paths.append(root)
    paths.extend(sorted(panoramas_dir.glob("*/fetch_manifest.json")))
    return paths


def find_job_and_output_dir(manifest_paths, corner_id, image_kind, path=None):
    """Searches each manifest in turn for a matching successful job.
    Returns (job, output_dir) for the first match -- output_dir is that
    manifest's own parent directory, so the resulting tight crop gets
    written co-located with its source image, not into some other
    dataset's folder. Returns (None, None) if no manifest has a match."""
    for manifest_path in manifest_paths:
        manifest = json.loads(Path(manifest_path).read_text())
        job = find_job(manifest, corner_id, image_kind, path=path)
        if job is not None:
            return job, Path(manifest_path).parent
    return None, None
