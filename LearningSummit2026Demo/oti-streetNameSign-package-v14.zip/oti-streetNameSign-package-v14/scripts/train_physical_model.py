"""
OTI walkthrough -- Stage 8 (and round 2 in Stage 10). Trains the damage model.
  How it works: main() hands the dataset to YOLO, starting from existing
  weights (fine-tuning), then appends the run's scores to
  PHYSICAL_RUN_HISTORY.csv. Same data + same starting weights give the same
  scores, because YOLO trains with a fixed random seed.

Trains the Physical Condition model and records its accuracy -- both
aggregate and per-damage-category. Extracted from "Section 2: Training" of
notebooks/06_yolo_physical_pipeline.ipynb so its stdout inherits the
parent process's terminal when run as a subprocess (nbconvert captures
cell output rather than streaming it live -- see
docs/superpowers/specs/2026-08-01-retrain-visibility-design.md). Running
this script directly does exactly what the notebook's Section 2 used to do
inline.

Usage:
    python train_physical_model.py
"""
import os
os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'TRUE')

import sys
from datetime import datetime
from pathlib import Path

import torch
import ultralytics
import yaml
from ultralytics import YOLO

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
import paths  # noqa: E402
import physical_report_lib as lib  # noqa: E402
import models_registry  # noqa: E402

DATA_YAML = SCRIPT_DIR.parent / "yolo" / "data_physical.yaml"
CAPTURE_EXT_TRAIN_LABELS = paths.dataset_dir("yolo_dataset_physical") / "labels" / "train"
CAPTURE_EXT_VAL_LABELS = paths.dataset_dir("yolo_dataset_physical") / "labels" / "val"
CAPTURE_EXT_IMAGES_DIR = paths.dataset_dir("yolo_dataset_physical") / "images"

# The annotation tool's tight-crop source (prepare_physical_dataset_from_
# annotations.py) -- see docs/superpowers/specs/2026-09-13-train-from-
# annotations-and-spatial-button-design.md. Same class taxonomy as
# DATA_YAML (confirmed: both yaml files list the same 5 names in the same
# order), so a "both" run can combine them at training time with no class
# remapping.
DATA_YAML_FROM_ANNOTATIONS = SCRIPT_DIR.parent / "yolo" / "data_physical_from_annotations.yaml"
ANNOTATIONS_TRAIN_LABELS = paths.dataset_dir("yolo_dataset_physical_from_annotations") / "labels" / "train"
ANNOTATIONS_VAL_LABELS = paths.dataset_dir("yolo_dataset_physical_from_annotations") / "labels" / "val"
ANNOTATIONS_IMAGES_DIR = paths.dataset_dir("yolo_dataset_physical_from_annotations") / "images"

# Regenerated fresh every "both" run -- lists both sources' image dirs as
# absolute paths per split (Ultralytics supports a list of dirs for
# train:/val:), so YOLO trains on both without either dataset being
# copied or merged on disk.
COMBINED_DATA_YAML = SCRIPT_DIR.parent / "yolo" / "data_physical_combined.yaml"

VALID_SOURCES = ("capture_extension", "annotation_tool", "both")

RUNS_DIR = SCRIPT_DIR.parent / "yolo" / "runs_physical"
HISTORY_PATH = RUNS_DIR / "PHYSICAL_RUN_HISTORY.csv"
CLASS_METRICS_PATH = RUNS_DIR / "PHYSICAL_CLASS_METRICS_HISTORY.csv"
PRETRAINED_WEIGHTS = SCRIPT_DIR.parent / "yolo26n.pt"
PHYSICAL_CLASS_NAMES = ["old_design", "faded", "bent_damaged", "hanging", "vandalized"]


def _has_any_labels(labels_dir):
    return labels_dir.is_dir() and any(labels_dir.glob("*.txt"))


def _labeled_data_exists(source):
    """Whether source has enough on-disk labeled data for main()'s guard
    clause to let training proceed. "both" is an OR, not an AND: each
    source's own dataset-prep step (prepare_yolo_dataset_physical.py /
    prepare_physical_dataset_from_annotations.py) already refuses to
    produce zero rows on its own, so by the time this runs via the
    retrain subprocess chain at least one non-empty source is guaranteed
    -- a bare CLI call that skips those prep steps is this guard's only
    real audience, and there's no reason to block it just because ONE of
    the two sources happens to be empty."""
    if source == "capture_extension":
        return _has_any_labels(CAPTURE_EXT_TRAIN_LABELS)
    if source == "annotation_tool":
        return _has_any_labels(ANNOTATIONS_TRAIN_LABELS)
    if source == "both":
        return _has_any_labels(CAPTURE_EXT_TRAIN_LABELS) or _has_any_labels(ANNOTATIONS_TRAIN_LABELS)
    raise ValueError(f"Unknown source {source!r}; must be one of {VALID_SOURCES}")


def _data_yaml_for(source):
    # Runtime copies whose path: is this machine's DATA_DIR dataset folder
    # (paths.runtime_dataset_yaml); the shipped yamls are never edited.
    if source == "capture_extension":
        return paths.runtime_dataset_yaml(DATA_YAML, "yolo_dataset_physical")
    if source == "annotation_tool":
        return paths.runtime_dataset_yaml(DATA_YAML_FROM_ANNOTATIONS, "yolo_dataset_physical_from_annotations")
    if source == "both":
        return _write_combined_data_yaml()
    raise ValueError(f"Unknown source {source!r}; must be one of {VALID_SOURCES}")


def _write_combined_data_yaml():
    data = {
        "train": [
            str(CAPTURE_EXT_IMAGES_DIR / "train").replace("\\", "/"),
            str(ANNOTATIONS_IMAGES_DIR / "train").replace("\\", "/"),
        ],
        "val": [
            str(CAPTURE_EXT_IMAGES_DIR / "val").replace("\\", "/"),
            str(ANNOTATIONS_IMAGES_DIR / "val").replace("\\", "/"),
        ],
        "names": dict(enumerate(PHYSICAL_CLASS_NAMES)),
    }
    COMBINED_DATA_YAML.parent.mkdir(parents=True, exist_ok=True)
    with open(COMBINED_DATA_YAML, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False)
    return COMBINED_DATA_YAML


_NO_DATA_GUARD_MESSAGES = {
    "capture_extension": "No labeled training data yet -- run prepare_yolo_dataset_physical.py first.",
    "annotation_tool": "No labeled training data yet -- run prepare_physical_dataset_from_annotations.py first.",
    "both": "No labeled training data yet for either source -- run prepare_yolo_dataset_physical.py and/or prepare_physical_dataset_from_annotations.py first.",
}


# OTI: Stage 8/10: starting_weights decides where training starts (weak model or round 1).
def main(source="capture_extension", data_yaml=None, epochs=50, batch=16,
         imgsz=640, starting_weights=None, run_name=None, publish=True,
         train_overrides=None):
    """`data_yaml`/`starting_weights`/`run_name`, when given, bypass the
    source-based dataset resolution and the capture_extension/
    annotation_tool dataset-composition reporting entirely -- the OTI
    hands-on notebook's training cell (docs/superpowers/specs/2026-10-09-
    oti-handson-notebook-design.md) is this parameter set's real audience:
    it trains on its own small bundled pool, starting from a deliberately
    weak checkpoint, with demo-sized epochs/batch/imgsz, and must never
    publish that run to the shared model registry (publish=False). Every
    default matches today's unparameterized behavior exactly, so a bare
    `python train_physical_model.py` is unaffected. `train_overrides` adds
    extra model.train() settings (the notebook's live retrains pass a lower
    lr0, freeze and val=False to stay short and not forget)."""
    using_custom_data = data_yaml is not None
    print('torch:', torch.__version__)
    print('cuda available:', torch.cuda.is_available())
    if torch.cuda.is_available():
        print('device:', torch.cuda.get_device_name(0))
    print('ultralytics:', ultralytics.__version__)
    print(f'training data: {data_yaml}' if using_custom_data else f'training source: {source}')

    if not using_custom_data:
        data_yaml = _data_yaml_for(source)
    with open(data_yaml) as f:
        data_cfg = yaml.safe_load(f)
    print(f"Classes ({len(data_cfg['names'])}):")
    for idx, name in data_cfg['names'].items():
        print(f'  {idx}: {name}')

    if not using_custom_data:
        # Per-split image/label counts, for whichever source(s) this run
        # actually uses -- "both" prints each contributing source's own
        # counts separately rather than a combined figure, so it's clear
        # how much each side contributed.
        _dirs_to_report = []
        if source in ("capture_extension", "both"):
            _dirs_to_report += [
                ("capture_extension/train", CAPTURE_EXT_IMAGES_DIR / "train", CAPTURE_EXT_TRAIN_LABELS),
                ("capture_extension/val", CAPTURE_EXT_IMAGES_DIR / "val", CAPTURE_EXT_VAL_LABELS),
            ]
        if source in ("annotation_tool", "both"):
            _dirs_to_report += [
                ("annotation_tool/train", ANNOTATIONS_IMAGES_DIR / "train", ANNOTATIONS_TRAIN_LABELS),
                ("annotation_tool/val", ANNOTATIONS_IMAGES_DIR / "val", ANNOTATIONS_VAL_LABELS),
            ]
        for label, images_dir, labels_dir in _dirs_to_report:
            n_img = len(list(images_dir.glob('*.jpg'))) if images_dir.is_dir() else 0
            n_lbl = len(list(labels_dir.glob('*.txt'))) if labels_dir.is_dir() else 0
            print(f'{label}: {n_img} images, {n_lbl} labels')

        if not _labeled_data_exists(source):
            raise SystemExit(_NO_DATA_GUARD_MESSAGES[source])

    run_name = run_name or f"street_sign_physical_{datetime.now().strftime('%Y-%m-%d')}"
    # >>> OTI CORE: the training call ------------------------------------------
    # Start from existing weights (the notebook: the previous model; production:
    # yolo26n's generic pretrained weights), then Ultralytics trains on
    # data_yaml's train images for `epochs` passes, AdamW optimizer, on the CPU
    # or GPU it finds. Afterwards it is scored on data_yaml's val images.
    weights_path = starting_weights or PRETRAINED_WEIGHTS
    model = YOLO(str(weights_path))
    model.train(
        data=str(data_yaml),
        epochs=epochs,
        batch=batch,
        optimizer='AdamW',
        imgsz=imgsz,
        project=str(RUNS_DIR),
        name=run_name,
        workers=0,
        **(train_overrides or {}),
    )
    # Ultralytics silently auto-suffixes the save dir (-2, -3, ...) when
    # `name` already exists on disk from a prior attempt, without updating
    # our `run_name` variable -- re-sync it to the actual dir so the
    # history CSV rows and report_physical.py's later run both point at
    # the run that was really trained.
    run_name = model.trainer.save_dir.name

    val_metrics = model.val(data=str(data_yaml))
    precision = float(val_metrics.box.mp)
    recall = float(val_metrics.box.mr)
    map50 = float(val_metrics.box.map50)
    map50_95 = float(val_metrics.box.map)
    # <<< OTI CORE end ---------------------------------------------------------

    if using_custom_data:
        # A custom data_yaml has its own train/val image dirs, not the
        # capture_extension/annotation_tool ones -- derive the matching
        # label dirs the same way write_split() laid them out (an
        # "images" dir and a same-shaped "labels" dir next to it).
        def _labels_dir_for(images_subpath):
            return Path(data_cfg["path"]) / images_subpath.replace("images", "labels", 1)

        class_counts = lib.count_classes_in_dataset(
            _labels_dir_for(data_cfg["train"]), _labels_dir_for(data_cfg["val"]), PHYSICAL_CLASS_NAMES,
        )
    else:
        # Each contributing source's own label dirs feed the dataset-
        # composition counts -- "both" sums both sources' counts since
        # count_classes_in_dataset takes exactly one train/val dir pair.
        capture_counts = lib.count_classes_in_dataset(CAPTURE_EXT_TRAIN_LABELS, CAPTURE_EXT_VAL_LABELS, PHYSICAL_CLASS_NAMES) \
            if source in ("capture_extension", "both") else {}
        annotations_counts = lib.count_classes_in_dataset(ANNOTATIONS_TRAIN_LABELS, ANNOTATIONS_VAL_LABELS, PHYSICAL_CLASS_NAMES) \
            if source in ("annotation_tool", "both") else {}
        class_counts = {
            cls: capture_counts.get(cls, 0) + annotations_counts.get(cls, 0)
            for cls in set(capture_counts) | set(annotations_counts)
        }

    history_row = lib.build_run_history_row(
        run_name=run_name,
        date_str=datetime.now().strftime('%Y-%m-%d'),
        class_counts=class_counts,
        precision=precision, recall=recall, map50=map50, map50_95=map50_95,
        source=source if not using_custom_data else "oti_streetNameSign_demo",
    )
    lib.append_run_history(history_row, HISTORY_PATH)
    print(f"Run '{run_name}' appended to PHYSICAL_RUN_HISTORY.csv")
    print(history_row)

    class_metrics_rows = lib.build_class_metrics_rows(
        run_name=run_name,
        date_str=datetime.now().strftime('%Y-%m-%d'),
        summary=val_metrics.summary(),
    )
    lib.append_class_metrics(class_metrics_rows, CLASS_METRICS_PATH)
    print(f"Per-class metrics for '{run_name}' appended to PHYSICAL_CLASS_METRICS_HISTORY.csv ({len(class_metrics_rows)} classes)")
    if publish:
        # Shared data folder: copy the finished run to <DATA_DIR>/models/
        # runs/ so every workstation can pick it (never switches
        # automatically). A demo run must never reach the shared
        # registry -- the notebook calls this with publish=False.
        models_registry.publish_if_shared(RUNS_DIR / run_name, "physical", map50)

    return run_name


if __name__ == "__main__":
    paths.require_data_dir()
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=VALID_SOURCES, default="capture_extension")
    args = parser.parse_args()
    main(source=args.source)
