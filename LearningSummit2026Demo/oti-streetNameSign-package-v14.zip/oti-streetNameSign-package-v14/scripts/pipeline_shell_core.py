"""
Pure, no-I/O logic for pipeline_shell.py -- path derivation, subprocess
command construction, validation, and the "section missing" banner.
Everything here is a plain function with no subprocess/file/network
calls, so it's fully unit-testable; pipeline_shell.py is the thin
input()-driven glue that actually runs commands and talks to the
terminal, same untested-glue split as annotate.js/annotate-core.js and
serve_tight_crop.py/tight_crop_lib.py elsewhere in this codebase --
except the one documented exception, `launch_servers()`, which genuinely
needs real I/O (spawning 2 local server processes) to start local servers.
"""

import json
import re
import subprocess
import sys
from pathlib import Path

import paths
import tight_crop_lib as tcl

# The root of every pulled collection -- inside the data folder (see
# paths.py; absolute, so it no longer depends on running from scripts/). Not board-specific (unlike
# dataset_dir()): used wherever a caller needs to search across every
# fetched dataset rather than assume one specific board's own subfolder,
# e.g. build_prepare_spatial_command's images_dir (see prepare_yolo_
# dataset_spatial.resolve_source_image's own docstring for why a specific
# board's subfolder isn't safe to assume there -- the annotation tool's
# own dataset dropdown lets the operator annotate any previously-fetched
# dataset, not necessarily whichever board was most recently fetched).
PANORAMAS_ROOT = paths.panoramas_root().as_posix()

# The annotation tool's saves now go straight here (see serve_tight_crop.
# py's /save-records endpoint) instead of accumulating in the browser for
# a manual "Export CSV" download -- every session's annotations merge
# automatically in one place. export_annotations_csv() generates a fresh
# CSV from the CURRENT full DB state on demand, replacing the old prompt
# for a path to a browser-downloaded file.
DEFAULT_ANNOTATION_DB_PATH = paths.annotations_db().as_posix()
DEFAULT_ANNOTATION_EXPORT_CSV = paths.data_path("annotations_export.csv").as_posix()

# signs_db.py's unified store, replacing the scattered signs_data.json
# files (extension/signs_data.json plus one per-board copy under each
# data/cyclomedia_panoramas/<board>/) -- see signs_db.py's module
# docstring and migrate_signs_data_to_db.py.
DEFAULT_SIGNS_DB_PATH = paths.signs_db().as_posix()


def export_annotations_csv(db_path=None, out_csv_path=None):
    """Generates a fresh CSV from annotations.db's current full state --
    NOT scoped to any one board: the whole point of the DB migration is
    that every annotation session merges automatically, so training gets
    the benefit of everything ever annotated, not just the most recent
    session. (report_shell_run.py's own board-scoped geo join is what
    keeps its report scoped to one Community Board's signs -- rows from
    other boards just won't have matching geo there, not filtered out
    here.) Returns (out_csv_path, row_count)."""
    import annotation_db as adb
    db_path = Path(db_path) if db_path else Path(DEFAULT_ANNOTATION_DB_PATH)
    out_csv_path = Path(out_csv_path) if out_csv_path else Path(DEFAULT_ANNOTATION_EXPORT_CSV)
    count = adb.export_to_csv(db_path, out_csv_path)
    return out_csv_path, count


def board_label(boro_cd: str) -> str:
    """Matches 01_query_sims_by_community_board.py's own
    board_output_label() -- the "cb"-prefixed label used everywhere
    downstream (CSV filename, corner_id prefix, dataset folder name) so a
    Community Board pull can never be confused with a ZIP-based one."""
    return f"cb{boro_cd}"


def cycle_label(boro_cd: str, year: int, aim: str | None = None) -> str:
    """One photo set per Cyclomedia capture year: "cb306_2026". The SIMS
    board label (signs_db partition, corner_id prefix) stays board_label();
    only the photo folder carries the year. A retrieval v3 pull (aim="v3",
    fetch_cyclomedia_panoramas.py --aim v3) gets its own "cb306_2026_v3"
    folder, so it sits next to that year's v2 set instead of mixing into it."""
    return f"{board_label(boro_cd)}_{year}" + (f"_{aim}" if aim else "")


_PHOTO_SET_LABEL = re.compile(r"(cb\d{3})_(\d{4})(?:_(v3))?")


def parse_photo_set_label(label: str):
    """("cb306", 2026, "v3" or None) for a cycle folder name, None for a
    legacy cbNNN folder or a demo set."""
    match = _PHOTO_SET_LABEL.fullmatch(str(label))
    return (match.group(1), int(match.group(2)), match.group(3)) if match else None


def parse_cycle_label(label: str):
    """("cb306", 2026) for a cycle folder name (v2 or v3), None for a legacy
    cbNNN folder (photos pulled before cycle folders existed) or a demo set."""
    parsed = parse_photo_set_label(label)
    return parsed[:2] if parsed else None


def dataset_dir(boro_cd: str, cycle: int | None = None, aim: str | None = None) -> str:
    """Where this board's panoramas, fetch_manifest.json, and
    signs_data.json all live together -- relative to scripts/, matching
    every other path in this pipeline. With `cycle`, that capture year's
    own folder (see cycle_label)."""
    label = cycle_label(boro_cd, cycle, aim) if cycle else board_label(boro_cd)
    return f"{paths.panoramas_root().as_posix()}/{label}"


def newest_photo_set_dir(boro_cd: str, panoramas_root=None) -> str:
    """The folder Run/Annotate should use for a board: its newest capture
    cycle (cbNNN_YYYY) when one exists, else the legacy cbNNN folder."""
    root = Path(panoramas_root) if panoramas_root is not None else paths.panoramas_root()
    board = board_label(boro_cd)
    found = []
    if root.is_dir():
        for folder in root.iterdir():
            parsed = parse_photo_set_label(folder.name) if folder.is_dir() else None
            if parsed and parsed[0] == board:
                found.append((parsed[1], parsed[2] is not None, folder.name))
    # Newest year first; within a year the v3 re-pull beats the v2 set.
    label = max(found)[2] if found else board
    return (root / label).as_posix()


def signs_csv_filename(boro_cd: str) -> str:
    """The CSV 01_query_sims_by_community_board.py writes (to the current
    directory) -- must match that script's own naming exactly, since it
    decides the real filename, not this function."""
    return f"signs_zip_{board_label(boro_cd)}.csv"


def signs_data_path(boro_cd: str, cycle: int | None = None, aim: str | None = None) -> str:
    """Co-located inside dataset_dir(), not a sibling file at the
    panoramas root -- list_panorama_datasets.py's signs-file discovery
    only looks inside each dataset's own subfolder."""
    return f"{dataset_dir(boro_cd, cycle, aim)}/signs_data.json"


def list_available_datasets(panoramas_dir=PANORAMAS_ROOT) -> list[dict]:
    """What's already been fetched, read fresh from disk every call --
    doesn't trust datasets.json (list_panorama_datasets.py's own output),
    which can go stale since it's only regenerated when that script is
    re-run by hand. Reuses tight_crop_lib.discover_manifest_paths (the
    same root + subfolder scan the tight-crop server already relies on)
    rather than re-deriving discovery logic a third time.

    Returns [{"label": ..., "image_count": ...}, ...], sorted with the
    root/original collection first, then subfolders alphabetically --
    same ordering convention as list_panorama_datasets.build_dataset_list.
    image_count counts "ok" (fetched this run) and "skipped" (file already
    existed from an earlier run -- still a real file on disk) jobs; only
    "failed" (no file exists) is excluded. Getting this wrong is a real bug
    that shipped once already (2026-08-14): re-fetching an already-complete
    dataset flips every job from "ok" to "skipped" (main() rewrites the
    whole manifest from each run's own results), and an "ok"-only count
    then reports "0 image(s)" for a folder that actually has hundreds of
    real files in it."""
    panoramas_dir = Path(panoramas_dir)
    datasets = []
    for manifest_path in tcl.discover_manifest_paths(panoramas_dir):
        manifest = json.loads(manifest_path.read_text())
        image_count = sum(1 for j in manifest.get("jobs", []) if j.get("status") in ("ok", "skipped"))
        label = "original" if manifest_path.parent == panoramas_dir else manifest_path.parent.name
        datasets.append({"label": label, "image_count": image_count})
    datasets.sort(key=lambda d: (d["label"] != "original", d["label"]))
    return datasets


def section_missing(name: str, why: str, what_exists: list[str]) -> str:
    """Formats (doesn't print -- pipeline_shell.py does that) the banner
    for a pipeline stage that genuinely doesn't exist yet. Never called
    for something merely untested or unverified -- only for real gaps,
    named plainly, with what already exists to build on."""
    lines = [
        "=" * 60,
        f"  SECTION MISSING: {name}",
        "=" * 60,
        why,
        "",
        "What already exists to build on:",
    ]
    lines.extend(f"  - {item}" for item in what_exists)
    lines.append("=" * 60)
    return "\n".join(lines)


def build_query_command(boro_cd: str) -> list[str]:
    return [sys.executable, "01_query_sims_by_community_board.py", boro_cd]


def build_generate_signs_data_command(boro_cd: str, cycle: int | None = None, aim: str | None = None) -> list[str]:
    return [
        sys.executable, "02_generate_signs_data.py", board_label(boro_cd),
        "--csv", signs_csv_filename(boro_cd),
        "--out", signs_data_path(boro_cd, cycle, aim),
    ]


def build_fetch_panoramas_command(
    boro_cd: str, limit: int | None = None, multi_angle: bool = False, cycle: int | None = None,
    aim: str | None = None, max_renders: int | None = None,
) -> list[str]:
    """limit: caps the fetch to the first N corners, for a cheap/quick
    demo pull instead of a full board (which can be hundreds of real
    Cyclomedia API calls) -- see fetch_cyclomedia_panoramas.py's own
    --limit docstring for what "first N" means (corner order in
    signs_data.json, not a random or representative sample).
    multi_angle: also fetch one "center" and one "side"-per-adjacent-pair
    shot per intersection, on top of the existing one-per-corner fetch --
    see fetch_cyclomedia_panoramas.py's own --multi-angle docstring.
    Roughly doubles API calls/runtime for a typical 4-way intersection.
    cycle: write into that capture year's folder and only use recordings
    from that year (fetch_cyclomedia_panoramas.py --cycle).
    aim="v3": intersection-aware aiming into the cycle's _v3 folder; it plans
    its own shots, so multi_angle is not passed. max_renders caps a v3 run's
    renders (fetch_cyclomedia_panoramas.py --max-renders)."""
    command = [
        sys.executable, "fetch_cyclomedia_panoramas.py", signs_data_path(boro_cd, cycle, aim),
        "--output-dir", dataset_dir(boro_cd, cycle, aim),
    ]
    if limit is not None:
        command += ["--limit", str(limit)]
    if multi_angle and not aim:
        command += ["--multi-angle"]
    if cycle:
        command += ["--cycle", str(cycle)]
    if aim:
        command += ["--aim", aim]
        if max_renders is not None:
            command += ["--max-renders", str(max_renders)]
    return command


def build_list_datasets_command() -> list[str]:
    return [sys.executable, "list_panorama_datasets.py"]


def build_backfill_command(csv_path: str) -> list[str]:
    return [sys.executable, "backfill_tight_crops.py", csv_path]


def build_prepare_physical_command(csv_paths: list[str]) -> list[str]:
    return [sys.executable, "prepare_physical_dataset_from_annotations.py", *csv_paths]


def build_prepare_spatial_command(csv_path: str, panoramas_dir: str = PANORAMAS_ROOT) -> list[str]:
    """prepare_yolo_dataset_spatial.py's own CLI takes exactly one CSV path
    plus the panoramas root it searches for each row's source_image under
    -- unlike build_prepare_physical_command, not a list of CSVs
    (confirmed against that script's own `if len(sys.argv) != 3` guard).

    panoramas_dir defaults to PANORAMAS_ROOT (the root of every pulled
    collection), NOT dataset_dir(boro_cd) (one specific board's own
    subfolder) -- the operator annotating right now isn't guaranteed to
    be annotating the board this shell run most recently fetched (the
    annotation tool's own dataset dropdown lets them pick any previously-
    fetched dataset), and prepare_yolo_dataset_spatial.resolve_source_image
    already searches every subfolder collection under whatever root it's
    given, so passing the true root here is what makes that search actually
    cover every possibility instead of just one board's own folder."""
    return [sys.executable, "prepare_yolo_dataset_spatial.py", csv_path, panoramas_dir]


EXPECTED_ANNOTATION_CSV_HEADER = (
    "source_image,image_kind,corner_id,box_index,bbox_x,bbox_y,bbox_w,bbox_h,"
    "image_width,image_height,order_number,sign_code,sign_location,damage_category,"
    "notes,tight_crop_path,flagged,annotated_at,matched_sign_json"
)


def validate_annotation_csv(path: str) -> tuple[bool, str]:
    """Checks a pasted CSV path before handing it to backfill_tight_crops.py
    -- catches a typo'd path or the wrong file immediately, with a clear
    message, instead of a cryptic failure several steps later."""
    p = Path(path)
    if not p.exists():
        return False, f"File not found: {path}"
    if not p.is_file():
        return False, f"Path is not a file (it's a directory): {path}"
    first_line = p.read_text(encoding="utf-8").splitlines()[0] if p.stat().st_size else ""
    if first_line.strip() != EXPECTED_ANNOTATION_CSV_HEADER:
        return False, (
            "This doesn't look like an annotation tool export -- header doesn't match "
            "RECORD_COLUMNS from annotation_tool/annotate-core.js."
        )
    return True, ""


def validate_val_set_not_empty(val_images_dir) -> tuple[bool, str]:
    """Checks before handing a dataset to model.train() -- Ultralytics
    crashes deep in its own data loader (a confusing FileNotFoundError
    stack trace, not a clear message) if the val split has zero images.
    This happens for real when a damage class has fewer than
    prepare_yolo_dataset_physical.MIN_FOR_VAL_SPLIT total annotated
    examples: everything goes to train, val ends up empty but still gets
    created (write_split always makes the directory). Real bug hit live
    2026-08-19 by a collaborator with only 2 annotated images."""
    val_images_dir = Path(val_images_dir)
    if not val_images_dir.is_dir() or not any(val_images_dir.iterdir()):
        return False, (
            f"Not enough annotated images yet to train -- the validation set "
            f"is empty ({val_images_dir}). This happens when a damage class "
            f"has too few annotated examples, which puts everything into the "
            f"training set and leaves nothing to validate against -- "
            f"Ultralytics requires at least one validation image to train at "
            f"all. Annotate more corners and run the shell again."
        )
    return True, ""


def training_run_name(board_label_str: str, now) -> str:
    """now: a datetime -- injected rather than read internally (via
    datetime.now()) so this stays deterministic and testable."""
    return f"shell_{board_label_str}_{now.strftime('%Y%m%d_%H%M%S')}"


def backfilled_csv_path(csv_path: str) -> str:
    """Matches backfill_tight_crops.py's own output-naming convention
    exactly (out_path = csv_path.with_name(csv_path.stem + "_with_tight_crops.csv"))
    -- kept here, tested, rather than reimplemented inline in
    pipeline_shell.py's untested glue layer."""
    return str(Path(csv_path).with_name(Path(csv_path).stem + "_with_tight_crops.csv"))


def training_kwargs(data_yaml_path: str, runs_dir: str, run_name: str) -> dict:
    """Kwargs for YOLO(...).train(**kwargs) -- same hyperparameters as the
    physical/spatial sanity-check training runs this session (epochs=50,
    batch=8, AdamW, imgsz=640), pointed at a shell-scoped project/name so
    this run can never collide with or overwrite yolo/runs_physical/."""
    return {
        "data": data_yaml_path,
        "epochs": 50,
        "batch": 8,
        "optimizer": "AdamW",
        "imgsz": 640,
        "project": runs_dir,
        "name": run_name,
        "exist_ok": True,
    }


def launch_servers(script_dir) -> list:
    """Starts the two local servers the annotation tool needs, each in
    its own visible console window (so the operator can see their logs
    and stop them by closing the window, same as double-clicking the
    launcher files by hand). The hub's launcher opens the hub page in the
    default browser -- the annotation tool itself is one click away from
    there (see docs/superpowers/specs/2026-08-31-hub-server-design.md;
    this used to launch annotation_tool/start_annotation_server.bat
    directly before that server was retired in favor of the hub). The
    hub also now serves tight-crop re-render and manual-photo-import
    directly (see docs/superpowers/specs/2026-09-10-fold-local-servers-
    into-hub-design.md), so start_tight_crop_server.bat/.sh is no longer
    launched here either -- launching a second copy on its own port would
    be redundant, not just unnecessary.
    script_dir: the caller's own SCRIPT_DIR (both pipeline_shell.py and
    tui_app.py have one) -- parameterized rather than read from a
    module-level global here, so this stays callable from either
    front-end.

    Windows launches the .bat files directly with CREATE_NEW_CONSOLE (a
    subprocess flag that only exists on Windows -- never evaluated on
    other platforms since that happens inside the win32-only branch).
    macOS/Linux has no CREATE_NEW_CONSOLE equivalent in subprocess, so
    each .sh launcher is opened in its own new Terminal.app window via
    `open -a Terminal <script>` -- the closest real mirror of "own
    visible console the operator can see logs in / close to stop".

    Returns the Popen handles (unused today, but keeps the door open for
    the caller to check .poll() later without re-deriving them)."""
    script_dir = Path(script_dir)
    if sys.platform == "win32":
        bat_files = [
            script_dir.parent / "start_hub.bat",
            script_dir.parent / "start_model_server.bat",
        ]
        return [
            subprocess.Popen([str(bat)], creationflags=subprocess.CREATE_NEW_CONSOLE)
            for bat in bat_files
        ]

    sh_files = [
        script_dir.parent / "start_hub.sh",
        script_dir.parent / "start_model_server.sh",
    ]
    return [
        subprocess.Popen(["open", "-a", "Terminal", str(sh)])
        for sh in sh_files
    ]
