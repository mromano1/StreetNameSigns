"""
Explicit "promote this run to production" mechanism, shared by both the
physical (damage) and spatial (sign-detection) models. Deliberately NOT
automatic (no training script here ever writes here itself) -- so a model
trained under time pressure can't silently start appearing in a demo
before someone has actually decided it's good enough.

A single pointer file (yolo/PRODUCTION_RUNS.json) tracks the currently
promoted run per model kind; a history CSV records every promotion for an
audit trail. When nothing's been promoted for a model kind, callers fall
back to their own pre-existing behavior -- see report_physical.
resolve_production_physical_weights() and run_automatic_inference.
resolve_production_spatial_weights().

Shared data folder (2026-09-26): once <DATA_DIR>/models/ exists (see
models_registry.py), the model a workstation uses comes from its own
machine file there instead of the pointer file, and promote() also sets
the shared "promoted" default and switches this machine to it. The
pointer file keeps working exactly as before when there is no models/
folder (the dev repo until migrate_models_to_data_dir.py is run), and
whenever a caller passes pointer_path explicitly (the package builders).

Usage:
    import model_promotion_lib as mpl
    mpl.promote("physical", "street_sign_physical_2026-08-17", runs_dir)
    weights, run_name = mpl.resolve_promoted_weights("physical", runs_dir)
"""
import csv
import json
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

import models_registry  # noqa: E402

MODEL_KINDS = ("physical", "spatial")
DEFAULT_POINTER_PATH = SCRIPT_DIR.parent / "yolo" / "PRODUCTION_RUNS.json"
DEFAULT_PROMOTION_HISTORY_PATH = SCRIPT_DIR.parent / "yolo" / "PROMOTION_HISTORY.csv"
PROMOTION_HISTORY_FIELDS = ["date", "model_kind", "run_name", "previous_run_name"]


def read_production_runs(path=None):
    """Returns {"physical": run_name_or_None, "spatial": run_name_or_None}.
    Missing file, malformed JSON, or missing keys all degrade to all-None
    rather than raising -- a corrupt pointer file must never take down
    real inference."""
    path = Path(path) if path is not None else DEFAULT_POINTER_PATH
    result = {kind: None for kind in MODEL_KINDS}
    if not path.exists():
        return result
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return result
    if not isinstance(data, dict):
        return result
    for kind in MODEL_KINDS:
        value = data.get(kind)
        result[kind] = value if isinstance(value, str) and value else None
    return result


def write_production_runs(data, path=None):
    """Writes data (a {"physical": ..., "spatial": ...}-shaped dict) to the
    pointer file. write-to-tmp then .replace() -- atomic, never a
    half-written pointer (same pattern promote_reviewed_record.py already
    uses for the same reason)."""
    path = Path(path) if path is not None else DEFAULT_POINTER_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp_path.replace(path)


def weights_path_for(runs_dir, run_name):
    return Path(runs_dir) / run_name / "weights" / "best.pt"


def promote(model_kind, run_name, runs_dir, pointer_path=None, history_path=None, now=None):
    """Validates weights_path_for(runs_dir, run_name).exists(); raises
    ValueError if not, or if model_kind is unknown. Updates the pointer
    file and appends a promotion-history row (with previous_run_name for
    an audit trail). Returns the updated pointer dict.

    now: optional zero-arg callable returning today's date string --
    injectable so tests don't depend on wall-clock time."""
    if model_kind not in MODEL_KINDS:
        raise ValueError(f"Unknown model_kind {model_kind!r}; must be one of {MODEL_KINDS}")
    use_registry = pointer_path is None and models_registry.registry_exists()
    weights_path = weights_path_for(runs_dir, run_name)
    in_registry = use_registry and models_registry.weights_for_run(run_name).exists()
    if not weights_path.exists() and not in_registry:
        raise ValueError(f"No weights found at {weights_path} -- refusing to promote a run that doesn't exist.")
    if use_registry:
        if not in_registry:
            raise ValueError(
                f"{run_name} is not on the shared drive yet ({models_registry.runs_dir()}). "
                "Run migrate_models_to_data_dir.py --all to copy local runs there first."
            )
        models_registry.set_promoted(model_kind, run_name, now=now)
        models_registry.use_model(model_kind, run_name, now=now)

    pointer_path = Path(pointer_path) if pointer_path is not None else DEFAULT_POINTER_PATH
    history_path = Path(history_path) if history_path is not None else DEFAULT_PROMOTION_HISTORY_PATH
    date_str = now()[:10] if now is not None else datetime.now().strftime("%Y-%m-%d")

    current = read_production_runs(pointer_path)
    previous_run_name = current.get(model_kind) or ""
    current[model_kind] = run_name
    write_production_runs(current, pointer_path)

    history_path.parent.mkdir(parents=True, exist_ok=True)
    file_exists = history_path.exists()
    with open(history_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=PROMOTION_HISTORY_FIELDS)
        if not file_exists:
            writer.writeheader()
        writer.writerow({
            "date": date_str, "model_kind": model_kind,
            "run_name": run_name, "previous_run_name": previous_run_name,
        })

    return current


def resolve_promoted_weights(model_kind, runs_dir, pointer_path=None):
    """(weights_path, run_name) for the currently-promoted run of this
    model kind, or (None, None) if nothing's been promoted OR the
    promoted run's weights file is gone from disk. Callers MUST have
    their own fallback for the (None, None) case -- promotion is never
    assumed to guarantee a usable result.

    With a shared models/ folder (and no explicit pointer_path), the run is
    this machine's current choice from its machine file; its weights are
    looked up on the shared drive first, then under runs_dir."""
    if pointer_path is None and models_registry.registry_exists():
        run_name = models_registry.current_run(model_kind)
        if not run_name:
            return None, None
        for candidate in (models_registry.weights_for_run(run_name), weights_path_for(runs_dir, run_name)):
            if candidate.exists():
                return candidate, run_name
        return None, None
    current = read_production_runs(pointer_path)
    run_name = current.get(model_kind)
    if run_name is None:
        return None, None
    weights_path = weights_path_for(runs_dir, run_name)
    if not weights_path.exists():
        return None, None
    return weights_path, run_name
