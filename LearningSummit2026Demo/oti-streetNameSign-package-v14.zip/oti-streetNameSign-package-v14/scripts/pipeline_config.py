"""
Single source of truth for this pipeline's tunable levers -- SIMS sign-type
filters, confidence thresholds, damage-class definitions, dataset-split
ratios, Cyclomedia render defaults, server ports, and similar. Every value
below has a hardcoded default matching this project's original behavior;
setting the matching .env variable overrides it -- see .env.example for the
full documented list of what each one does and where it's used.

Every script that previously hardcoded one of these values now imports it
from here instead, so there's exactly one place to change it (not counting
the Chrome extension -- see generate_extension_config.py for how the
damage-class values reach the extension, since a Chrome extension can't
read a .env file directly).

Deliberately excludes constants that AREN'T really tunable levers even
though they're also hardcoded elsewhere in this project:
run_automatic_inference.SPATIAL_MAP50 (a measured historical benchmark
result, not a policy you can set your way to a different real accuracy) and
community_board_lookup.MAX_REAL_CD (a real NYC administrative fact about how
many Community Districts each borough has, not a project preference).

Usage:
    import pipeline_config as cfg
    cfg.CONF_THRESHOLD
"""
import os
from pathlib import Path

from dotenv import load_dotenv

SCRIPT_DIR = Path(__file__).resolve().parent
load_dotenv(SCRIPT_DIR.parent / ".env")


def _get_str(name, default):
    return os.getenv(name) or default


def _get_float(name, default):
    raw = os.getenv(name)
    return float(raw) if raw not in (None, "") else default


def _get_int(name, default):
    raw = os.getenv(name)
    return int(raw) if raw not in (None, "") else default


def _get_list(name, default):
    """Comma-separated -- "SN-,SI-" -> ["SN-", "SI-"]. Whitespace around
    each item is stripped, empty items dropped. Falls back to `default`
    (already a list, order preserved) if the variable is unset or blank."""
    raw = os.getenv(name)
    if not raw:
        return list(default)
    return [item.strip() for item in raw.split(",") if item.strip()]


def _get_mapping(name, default):
    """Comma-separated key:value pairs -- "bent:bent_damaged,faded:faded"
    -> {"bent": "bent_damaged", "faded": "faded"}. Falls back to `default`
    (already a dict) if the variable is unset or blank. A pair with no ":"
    is skipped rather than raising, so one malformed entry in a hand-edited
    .env doesn't take the whole mapping down."""
    raw = os.getenv(name)
    if not raw:
        return dict(default)
    mapping = {}
    for pair in raw.split(","):
        pair = pair.strip()
        if not pair or ":" not in pair:
            continue
        key, _, value = pair.partition(":")
        key, value = key.strip(), value.strip()
        if key and value:
            mapping[key] = value
    return mapping


# --- SIMS query: which signs get pulled (scripts/01_query_sims_by_zip.py's
# build_where_parts(), shared by the Community Board query variant too) ---
SIMS_SIGN_CODE_PREFIXES = _get_list("SIMS_SIGN_CODE_PREFIXES", ["SN-", "SI-"])
SIMS_ORDER_NUMBER_PREFIX = _get_str("SIMS_ORDER_NUMBER_PREFIX", "ST")
SIMS_SIGN_SIZE_FILTER = _get_str("SIMS_SIGN_SIZE_FILTER", "009")
SIMS_QUERY_RADIUS_FEET = _get_float("SIMS_QUERY_RADIUS_FEET", 5280.0)

# --- Physical (damage) model ---
CONF_THRESHOLD = _get_float("PHYSICAL_CONF_THRESHOLD", 0.25)
# Order matters: the ONNX fallback model's output is positional (index N ->
# this list's Nth name), so reordering this changes what the extension's
# offline fallback reports even if nothing else about the model changes.
PHYSICAL_DAMAGE_CLASSES = _get_list(
    "PHYSICAL_DAMAGE_CLASSES",
    ["old_design", "faded", "bent_damaged", "hanging", "vandalized"],
)
PHYSICAL_BUTTON_TO_CLASS = _get_mapping(
    "PHYSICAL_BUTTON_TO_CLASS",
    {
        "bent": "bent_damaged",
        "white-border": "old_design",
        "all-caps": "old_design",
        "faded": "faded",
        "hanging": "hanging",
        "vandalized": "vandalized",
    },
)
# First = most urgent. DAMAGE_PRIORITY is derived (name -> 1-based rank), the
# shape physical_report_lib.py's actionable-report sort already expects.
DAMAGE_PRIORITY_ORDER = _get_list(
    "DAMAGE_PRIORITY_ORDER",
    ["vandalized", "bent_damaged", "hanging", "faded", "old_design"],
)
DAMAGE_PRIORITY = {name: rank + 1 for rank, name in enumerate(DAMAGE_PRIORITY_ORDER)}

# --- Training dataset split (prepare_yolo_dataset_physical.py and siblings) ---
VAL_FRACTION = _get_float("VAL_FRACTION", 0.2)
MIN_FOR_VAL_SPLIT = _get_int("MIN_FOR_VAL_SPLIT", 5)
DATASET_SPLIT_SEED = _get_int("DATASET_SPLIT_SEED", 42)

# --- Cyclomedia fetch ---
# 3200x2400 (2x cyclomedia_client.render_recording()'s own lower-level
# 1600x1200 default) is what fetch_cyclomedia_panoramas.py's real pipeline
# actually requests -- confirmed live 2026-08-12 that this size serves real
# additional legible detail, not just an upscale. WIDE_HFOV=120 (wider than
# render_recording's own 75-deg default) absorbs heading-guess imprecision.
CYCLOMEDIA_RENDER_WIDTH = _get_int("CYCLOMEDIA_RENDER_WIDTH", 3200)
CYCLOMEDIA_RENDER_HEIGHT = _get_int("CYCLOMEDIA_RENDER_HEIGHT", 2400)
CYCLOMEDIA_RENDER_FOV = _get_float("CYCLOMEDIA_RENDER_FOV", 120.0)
CYCLOMEDIA_DEFAULT_HEADING = _get_float("CYCLOMEDIA_DEFAULT_HEADING", 0.0)  # fallback when no sign at a corner has a classifiable sign_location
INTERSECTION_CLUSTER_DISTANCE_FT = _get_float("INTERSECTION_CLUSTER_DISTANCE_FT", 250.0)
# Empirically measured real per-board max cluster sizes (2026-08-14) --
# above this, single-linkage chaining stops representing a real
# intersection (neighborhood-scale over-clustering instead); oversized
# clusters are dropped from multi-angle capture entirely, not sub-split.
MAX_INTERSECTION_CLUSTER_SIZE = _get_int("MAX_INTERSECTION_CLUSTER_SIZE", 10)

# --- Tight-crop re-render (annotation tool's serve_tight_crop.py) ---
TIGHT_CROP_RENDER_PADDING_FACTOR = _get_float("TIGHT_CROP_RENDER_PADDING_FACTOR", 2.5)
TIGHT_CROP_CROP_PADDING_FACTOR = _get_float("TIGHT_CROP_CROP_PADDING_FACTOR", 1.5)
TIGHT_CROP_MIN_FOV = _get_float("TIGHT_CROP_MIN_FOV", 5.0)

# --- Capture extension: how close a capture must be to count as "at" a
# known SIMS corner (content.js's nearestCorner/nearestCornerLocal) ---
CAPTURE_MATCH_DISTANCE_DEG = _get_float("CAPTURE_MATCH_DISTANCE_DEG", 0.0011)
CAPTURE_MATCH_DISTANCE_FT = _get_float("CAPTURE_MATCH_DISTANCE_FT", 400.0)

# --- Local servers ---
PHYSICAL_MODEL_SERVER_PORT = _get_int("PHYSICAL_MODEL_SERVER_PORT", 8765)
TIGHT_CROP_SERVER_PORT = _get_int("TIGHT_CROP_SERVER_PORT", 8766)
ANNOTATION_TOOL_SERVER_PORT = _get_int("ANNOTATION_TOOL_SERVER_PORT", 8000)
REVIEW_API_SERVER_PORT = _get_int("REVIEW_API_SERVER_PORT", 8767)
REVIEW_VIEWER_SERVER_PORT = _get_int("REVIEW_VIEWER_SERVER_PORT", 8001)
MANUAL_IMPORT_SERVER_PORT = _get_int("MANUAL_IMPORT_SERVER_PORT", 8768)
HUB_SERVER_PORT = _get_int("HUB_SERVER_PORT", 8002)
RETRAIN_TIMEOUT_SECONDS = _get_int("RETRAIN_TIMEOUT_SECONDS", 7200)

# How many corners the hub's "Pull Imagery" button fetches (see hub_server.
# py's /api/pull-imagery) -- a deliberately small cap so a button click
# stays fast instead of making the hundreds of real Cyclomedia API calls a
# full board fetch would. Same --limit mechanism as pipeline_shell.py's own
# prompt_limit(), just pre-set instead of asked interactively.
PULL_IMAGERY_LIMIT = _get_int("PULL_IMAGERY_LIMIT", 5)
