"""
SQLite-backed store for SIMS/LION corner+sign data -- replaces the
scattered signs_data.json files (a canonical copy at extension/
signs_data.json plus one per-board copy under each
data/cyclomedia_panoramas/<board>/), which ~20 production scripts were
each reading directly via json.load(). One unified DB, one access module,
same reason annotation_db.py replaced the CSV-export era: a single source
of truth instead of N files that can silently drift out of sync with each
other.

Mirrors annotation_db.py's style (same _connect/init_db shape, plain
functions, no ORM). Two tables: sign_corners (one row per intersection
corner, plus the zip list its source pull covered) and signs (one row per
sign at that corner, FK'd by corner_id) -- the corners:signs relationship
in the original JSON (each corner object has a nested "signs" list) is
just a join here, reassembled back into the same nested shape by
get_corner()/list_corners() so callers migrating off json.load() see an
unchanged data shape.

board_label is the partition key a re-import (upsert_dataset) replaces --
it's whatever key the source pull was scoped to: a Community Board code
("cb301") for the per-board files, or the joined zip list itself for the
one dataset that predates the board-labeled convention
(extension/signs_data.json). corner_id is NOT assumed unique across
boards on its own (two different pulls could theoretically produce the
same id), so the corners/signs tables are keyed on (board_label,
corner_id) together -- callers that don't care which board a corner came
from (the common case) can still call list_corners()/get_corner() without
a board_label and get the first match.

Usage:
    import signs_db
    signs_db.init_db(db_path)
    signs_db.upsert_dataset(db_path, board_label="cb301", zips=[...], corners=[...])
    signs_db.list_corners(db_path, board_label="cb301")
    signs_db.get_corner(db_path, corner_id)
"""
import json
import sqlite3
from pathlib import Path

import db

CORNER_COLUMNS = ["corner_id", "on_street", "from_street", "latitude", "longitude", "x_2263", "y_2263"]
SIGN_COLUMNS = ["order_number", "sign_code", "sign_description", "sign_location", "support"]

# Everything 02_generate_signs_data.py's build_sign_dict() puts on a sign
# beyond the 5 named SIGN_COLUMNS (every real SIMS column, per the
# 2026-08-25 stakeholder request) is stored as one JSON blob rather than
# named columns -- the SIMS column set isn't fixed, so this avoids a schema
# migration every time NYC Open Data adds or renames a field.
EXTRA_SIGN_COLUMNS_FIELD = "extra_json"

# Conservative relative to SQLite's variable limit (the oldest builds
# default to 999; see _fetch_signs_for_corners), with headroom for the
# board_label param alongside the corner_id batch.
_SIGN_LOOKUP_BATCH_SIZE = 500


def _connect(db_path) -> sqlite3.Connection:
    db_path = Path(db_path)
    conn = db.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(db_path) -> None:
    """Idempotent -- safe to call at the start of every script/server that
    touches this DB."""
    conn = _connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS boards (
            board_label TEXT PRIMARY KEY,
            zips_json TEXT NOT NULL
        )
    """)
    corner_columns_sql = ", ".join(f'"{col}" TEXT' for col in CORNER_COLUMNS if col != "corner_id")
    conn.execute(f"""
        CREATE TABLE IF NOT EXISTS sign_corners (
            board_label TEXT NOT NULL,
            corner_id TEXT NOT NULL,
            {corner_columns_sql},
            PRIMARY KEY (board_label, corner_id)
        )
    """)
    sign_columns_sql = ", ".join(f'"{col}" TEXT' for col in SIGN_COLUMNS)
    conn.execute(f"""
        CREATE TABLE IF NOT EXISTS signs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            board_label TEXT NOT NULL,
            corner_id TEXT NOT NULL,
            {sign_columns_sql},
            "{EXTRA_SIGN_COLUMNS_FIELD}" TEXT,
            FOREIGN KEY (board_label, corner_id) REFERENCES sign_corners(board_label, corner_id)
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_signs_corner ON signs (board_label, corner_id)")

    # Migration for a signs table created before EXTRA_SIGN_COLUMNS_FIELD
    # existed (CREATE TABLE IF NOT EXISTS above is a no-op against it) --
    # add the column so old DBs keep working without a fresh re-import.
    existing_columns = {row["name"] for row in conn.execute("PRAGMA table_info(signs)")}
    if EXTRA_SIGN_COLUMNS_FIELD not in existing_columns:
        conn.execute(f'ALTER TABLE signs ADD COLUMN "{EXTRA_SIGN_COLUMNS_FIELD}" TEXT')

    _init_intersection_classes(conn)
    conn.commit()
    conn.close()


# Intersection type per SIMS corner, computed from LION by
# intersection_classifier.py (the class needs graph topology, so it can't be
# a pure SQL view; the classifier writes this table and the views below join
# it to SIMS). intersection_key is the sorted LION node ids, so the several
# SIMS corner records of one intersection share it. override_class /
# override_note are hand fixes: the classifier's upsert never touches them,
# and v_intersections reports COALESCE(override_class, class) as the class.
INTERSECTION_CLASS_COLUMNS = [
    "intersection_key", "lion_node_ids", "class", "divided", "divided_streets", "skew_deg",
    "n_vehicular_legs", "reasons", "legs_json", "name_mismatch", "node_distance_ft",
    "classifier_version", "computed_at",
]


def _init_intersection_classes(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS intersection_classes (
            board_label TEXT NOT NULL,
            corner_id TEXT NOT NULL,
            intersection_key TEXT,
            lion_node_ids TEXT,
            class TEXT NOT NULL,
            divided INTEGER NOT NULL DEFAULT 0,
            divided_streets TEXT,
            skew_deg INTEGER,
            n_vehicular_legs INTEGER,
            reasons TEXT,
            legs_json TEXT,
            name_mismatch TEXT,
            node_distance_ft REAL,
            classifier_version TEXT,
            computed_at TEXT,
            override_class TEXT,
            override_note TEXT,
            PRIMARY KEY (board_label, corner_id)
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_intersection_classes_key "
                 "ON intersection_classes (board_label, intersection_key)")
    # Dropped and recreated every time so a changed definition reaches old DBs.
    conn.execute("DROP VIEW IF EXISTS v_intersections")
    conn.execute("""
        CREATE VIEW v_intersections AS
        SELECT c.board_label, c.corner_id, c.on_street, c.from_street,
               c.latitude, c.longitude, c.x_2263, c.y_2263,
               COALESCE(ic.override_class, ic.class) AS class,
               ic.class AS computed_class,
               ic.divided, ic.divided_streets, ic.skew_deg, ic.n_vehicular_legs,
               ic.intersection_key, ic.lion_node_ids, ic.reasons, ic.name_mismatch,
               ic.node_distance_ft, ic.override_note, ic.classifier_version, ic.computed_at,
               (SELECT group_concat(loc) FROM (
                    SELECT DISTINCT s.sign_location AS loc FROM signs s
                    WHERE s.board_label = c.board_label AND s.corner_id = c.corner_id
                      AND s.sign_location IS NOT NULL
                    ORDER BY loc)) AS sign_locations
        FROM sign_corners c
        LEFT JOIN intersection_classes ic
               ON ic.board_label = c.board_label AND ic.corner_id = c.corner_id
    """)
    conn.execute("DROP VIEW IF EXISTS v_intersection_summary")
    conn.execute("""
        CREATE VIEW v_intersection_summary AS
        SELECT ic.board_label, ic.intersection_key,
               max(COALESCE(ic.override_class, ic.class)) AS class,
               max(ic.divided) AS divided,
               max(ic.divided_streets) AS divided_streets,
               count(*) AS corner_count,
               COALESCE(sum(sc.n), 0) AS sign_count,
               min(ic.corner_id) AS first_corner_id
        FROM intersection_classes ic
        LEFT JOIN (SELECT board_label, corner_id, count(*) AS n FROM signs
                   GROUP BY board_label, corner_id) sc
               ON sc.board_label = ic.board_label AND sc.corner_id = ic.corner_id
        WHERE ic.intersection_key IS NOT NULL
        GROUP BY ic.board_label, ic.intersection_key
    """)


def upsert_intersection_classes(db_path, board_label, rows) -> None:
    """Writes classifier rows (dicts with corner_id + INTERSECTION_CLASS_COLUMNS)
    for one board. Re-running replaces the computed columns and leaves any
    override_class / override_note in place."""
    cols = ["corner_id"] + INTERSECTION_CLASS_COLUMNS
    updates = ", ".join(f"{c} = excluded.{c}" for c in INTERSECTION_CLASS_COLUMNS)
    conn = _connect(db_path)
    with conn:
        conn.executemany(
            f"INSERT INTO intersection_classes (board_label, {', '.join(cols)}) "
            f"VALUES (:board_label, {', '.join(':' + c for c in cols)}) "
            f"ON CONFLICT(board_label, corner_id) DO UPDATE SET {updates}",
            [{**{c: row.get(c) for c in cols}, "board_label": board_label} for row in rows],
        )
    conn.close()


def upsert_dataset(db_path, board_label, zips, corners) -> None:
    """Replaces everything currently stored for board_label with `corners`
    (a list of the original signs_data.json corner-object shape, each with
    a nested "signs" list) and `zips` -- a full re-import, not a merge, so
    a corner present in the DB from a previous pull but absent from this
    one (e.g. a sign was removed from SIMS) doesn't linger as stale data.
    Safe to call with an empty corners list (a board that legitimately has
    none this run)."""
    conn = _connect(db_path)
    conn.execute(
        "INSERT INTO boards (board_label, zips_json) VALUES (?, ?) "
        "ON CONFLICT(board_label) DO UPDATE SET zips_json = excluded.zips_json",
        (board_label, json.dumps(list(zips))),
    )
    conn.execute("DELETE FROM signs WHERE board_label = ?", (board_label,))
    conn.execute("DELETE FROM sign_corners WHERE board_label = ?", (board_label,))

    corner_col_names = ", ".join(f'"{col}"' for col in CORNER_COLUMNS)
    corner_placeholders = ", ".join(f":{col}" for col in CORNER_COLUMNS)
    sign_col_names = ", ".join(f'"{col}"' for col in SIGN_COLUMNS)
    sign_placeholders = ", ".join(f":{col}" for col in SIGN_COLUMNS)

    for corner in corners:
        conn.execute(
            f'INSERT INTO sign_corners (board_label, {corner_col_names}) '
            f'VALUES (:board_label, {corner_placeholders})',
            {**{col: corner.get(col) for col in CORNER_COLUMNS}, "board_label": board_label},
        )
        signs = corner.get("signs") or []
        if signs:
            conn.executemany(
                f'INSERT INTO signs (board_label, corner_id, {sign_col_names}, "{EXTRA_SIGN_COLUMNS_FIELD}") '
                f'VALUES (:board_label, :corner_id, {sign_placeholders}, :{EXTRA_SIGN_COLUMNS_FIELD})',
                [
                    {
                        **{col: sign.get(col) for col in SIGN_COLUMNS},
                        "board_label": board_label,
                        "corner_id": corner["corner_id"],
                        EXTRA_SIGN_COLUMNS_FIELD: json.dumps(
                            {k: v for k, v in sign.items() if k not in SIGN_COLUMNS}
                        ),
                    }
                    for sign in signs
                ],
            )
    conn.commit()
    conn.close()


def _row_to_corner(row, signs_by_corner) -> dict:
    corner = {col: row[col] for col in CORNER_COLUMNS}
    corner["latitude"] = float(corner["latitude"]) if corner["latitude"] is not None else None
    corner["longitude"] = float(corner["longitude"]) if corner["longitude"] is not None else None
    corner["x_2263"] = float(corner["x_2263"]) if corner["x_2263"] is not None else None
    corner["y_2263"] = float(corner["y_2263"]) if corner["y_2263"] is not None else None
    corner["signs"] = signs_by_corner.get(row["corner_id"], [])
    return corner


def _fetch_signs_for_corners(conn, board_label, corner_ids) -> dict:
    """Returns {corner_id: [sign_dict, ...]} for the given corner_ids,
    preserving each sign's insertion order (its original position in the
    source JSON's "signs" list, via the autoincrement id). Queries in
    batches of _SIGN_LOOKUP_BATCH_SIZE corner_ids at a time -- one `?`
    placeholder per corner_id in a single query hit "too many SQL
    variables" against the citywide "all_nyc_cb" board (39,814 corners,
    2026-10-03); every board before that had stayed small enough for this
    to never surface."""
    if not corner_ids:
        return {}
    sign_col_names = ", ".join(f'"{col}"' for col in SIGN_COLUMNS)
    board_clause = "board_label = ? AND " if board_label else ""
    by_corner: dict = {}
    for i in range(0, len(corner_ids), _SIGN_LOOKUP_BATCH_SIZE):
        batch = corner_ids[i:i + _SIGN_LOOKUP_BATCH_SIZE]
        placeholders = ", ".join("?" for _ in batch)
        params = [board_label, *batch] if board_label else list(batch)
        rows = conn.execute(
            f'SELECT corner_id, {sign_col_names}, "{EXTRA_SIGN_COLUMNS_FIELD}" FROM signs '
            f'WHERE {board_clause}corner_id IN ({placeholders}) ORDER BY id',
            params,
        ).fetchall()
        for row in rows:
            sign = {col: row[col] for col in SIGN_COLUMNS}
            extra = row[EXTRA_SIGN_COLUMNS_FIELD]
            if extra:
                sign.update(json.loads(extra))
            by_corner.setdefault(row["corner_id"], []).append(sign)
    return by_corner


def count_by_board(db_path) -> dict:
    """{board_label: (corner_count, sign_count)} for every imported board,
    from two GROUP BY queries. For callers that only need the numbers: the
    homepage overview used list_corners() per board just to count, which
    loaded all 39,814 citywide corners and their signs (~3s per page load)."""
    conn = _connect(db_path)
    corners = dict(conn.execute("SELECT board_label, COUNT(*) FROM sign_corners GROUP BY board_label").fetchall())
    signs = dict(conn.execute("SELECT board_label, COUNT(*) FROM signs GROUP BY board_label").fetchall())
    boards = [row["board_label"] for row in conn.execute("SELECT board_label FROM boards")]
    conn.close()
    return {board: (corners.get(board, 0), signs.get(board, 0)) for board in boards}


def list_corners(db_path, board_label=None) -> list:
    """Returns every stored corner (optionally scoped to one board_label)
    in the same nested shape signs_data.json's "corners" list used --
    each dict has a "signs" list of that corner's sign dicts."""
    conn = _connect(db_path)
    if board_label:
        rows = conn.execute(
            "SELECT * FROM sign_corners WHERE board_label = ?", (board_label,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM sign_corners").fetchall()
    signs_by_corner = _fetch_signs_for_corners(conn, board_label, [row["corner_id"] for row in rows])
    conn.close()
    return [_row_to_corner(row, signs_by_corner) for row in rows]


def get_corner(db_path, corner_id, board_label=None):
    """Returns one corner dict (same nested shape as list_corners()), or
    None if corner_id isn't found. If board_label is omitted and the same
    corner_id exists under more than one board, returns the first match
    (in practice this hasn't happened -- corner_id already embeds its
    source zip/board key)."""
    conn = _connect(db_path)
    if board_label:
        row = conn.execute(
            "SELECT * FROM sign_corners WHERE board_label = ? AND corner_id = ?",
            (board_label, corner_id),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM sign_corners WHERE corner_id = ?", (corner_id,)
        ).fetchone()
    if row is None:
        conn.close()
        return None
    signs_by_corner = _fetch_signs_for_corners(conn, row["board_label"], [corner_id])
    conn.close()
    return _row_to_corner(row, signs_by_corner)


NEARBY_CORNER_RADIUS_FT = 5.0


def _sign_key(sign) -> tuple:
    return tuple(sign.get(col) for col in ("order_number", "sign_code", "sign_description", "sign_location"))


def add_nearby_signs(db_path, corners, radius_ft=NEARBY_CORNER_RADIUS_FT) -> list:
    """Returns corners with each one's "signs" list extended by the signs
    of any other stored corner (any board) on the same street pair within
    radius_ft. 02_generate_signs_data.py groups signs into corners by
    exact lat/lon, so two signs on one pole whose SIMS coordinates differ
    by a foot become two corners, sometimes in two different boards when
    the street is a board line (real case, 2026-10-15: cb406_008 had
    WOODHAVEN BOULEVARD, its 79 AV sign was cb405_341). About 14% of the
    citywide corners are half of such a split. Merging at read time keeps
    every corner_id (and the photos/reviews keyed on it) unchanged.

    Added signs carry "nearby_corner_id". A sign already on the corner
    (same order number, code, description and location, e.g. the
    all_nyc_cb copy) is not added twice. A missing DB returns corners
    unchanged."""
    if not Path(db_path).exists():
        return corners
    conn = _connect(db_path)
    by_pair: dict = {}
    for row in conn.execute("SELECT board_label, corner_id, on_street, from_street, x_2263, y_2263 FROM sign_corners"):
        if row["x_2263"] is None or row["y_2263"] is None:
            continue
        pair = frozenset((row["on_street"], row["from_street"]))
        by_pair.setdefault(pair, []).append(
            (row["board_label"], row["corner_id"], float(row["x_2263"]), float(row["y_2263"]))
        )

    neighbors_by_corner: dict = {}
    wanted_by_board: dict = {}
    for corner in corners:
        if corner.get("x_2263") is None or corner.get("y_2263") is None:
            continue
        x, y = float(corner["x_2263"]), float(corner["y_2263"])
        pair = frozenset((corner.get("on_street"), corner.get("from_street")))
        for board, corner_id, nx, ny in by_pair.get(pair, []):
            if corner_id == corner["corner_id"]:
                continue
            if (nx - x) ** 2 + (ny - y) ** 2 <= radius_ft ** 2:
                neighbors_by_corner.setdefault(corner["corner_id"], []).append((board, corner_id))
                wanted_by_board.setdefault(board, set()).add(corner_id)

    signs_by_board = {
        board: _fetch_signs_for_corners(conn, board, sorted(ids)) for board, ids in wanted_by_board.items()
    }
    conn.close()

    merged = []
    for corner in corners:
        neighbors = neighbors_by_corner.get(corner["corner_id"])
        if not neighbors:
            merged.append(corner)
            continue
        signs = list(corner.get("signs", []))
        seen = {_sign_key(s) for s in signs}
        for board, corner_id in neighbors:
            for sign in signs_by_board[board].get(corner_id, []):
                if _sign_key(sign) in seen:
                    continue
                seen.add(_sign_key(sign))
                signs.append(dict(sign, nearby_corner_id=corner_id))
        merged.append(dict(corner, signs=signs))
    return merged


def get_zips(db_path, board_label) -> list:
    """Returns the zip list stored for board_label, or [] if that board
    has no data yet."""
    conn = _connect(db_path)
    row = conn.execute("SELECT zips_json FROM boards WHERE board_label = ?", (board_label,)).fetchone()
    conn.close()
    return json.loads(row["zips_json"]) if row else []


def list_boards(db_path) -> list:
    """Returns every board_label that has been imported."""
    conn = _connect(db_path)
    rows = conn.execute("SELECT board_label FROM boards").fetchall()
    conn.close()
    return [row["board_label"] for row in rows]


def get_corners_for_board(db_path, board_label, fallback_json_path=None) -> list:
    """Prefer-DB-fall-back-to-file reader for the many call sites that
    used to do `json.loads((dataset_dir / "signs_data.json").read_text())`
    for one specific board's dataset_dir (== board_label -- see
    pipeline_shell_core.dataset_dir()). Tries signs_db first; if
    board_label hasn't been imported there yet (DB not populated for
    this board, or db_path itself doesn't exist -- both real states for
    an in-progress migration or an isolated test's own tmp_path
    fixture), falls back to reading fallback_json_path directly, matching
    every caller's original json.load()-based behavior exactly. Checks
    board membership via list_boards(), not corner-list truthiness -- a
    board imported with zero corners (a legitimate state, see
    test_upsert_dataset_does_not_touch_other_boards) returns that
    authoritative empty result rather than silently falling through to a
    stale file. Returns [] (never raises) if neither source has data,
    matching those callers' existing "missing signs_data.json -> treat
    as no data" handling."""
    db_path = Path(db_path)
    if db_path.exists() and board_label in list_boards(db_path):
        return list_corners(db_path, board_label=board_label)

    if fallback_json_path is None:
        return []
    fallback_json_path = Path(fallback_json_path)
    if not fallback_json_path.exists():
        return []
    try:
        with open(fallback_json_path, encoding="utf-8") as f:
            return json.load(f).get("corners", [])
    except (OSError, json.JSONDecodeError):
        # Degrades gracefully rather than raising -- matches the
        # "_load_json"-style try/except convention several callers
        # (hub_overview.py, data_map.py) already use for their own
        # direct signs_data.json reads.
        return []
