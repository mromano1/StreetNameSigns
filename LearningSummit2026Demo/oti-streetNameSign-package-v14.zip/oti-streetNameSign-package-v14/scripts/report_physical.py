"""
OTI walkthrough -- Stages 5, 9 and 11. Runs a trained model on images.
  How it works: predict_image() returns (class, confidence) for each box
  the model draws; no box means no damage found. annotated_image_b64()
  draws those boxes on the photo for the report.

Test + report + shapefile generation for the Physical Condition model.
Run against the latest (or a specified) trained run under
yolo/runs_physical/. See
docs/superpowers/specs/2026-07-29-physical-condition-model-flow-design.md.

Usage:
    python report_physical.py [run_name]
"""
import csv
import sys
from datetime import datetime
from pathlib import Path

import cv2
from ultralytics import YOLO

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
import paths  # noqa: E402
import physical_report_lib as lib  # noqa: E402
import community_board_lookup as cbl  # noqa: E402
import pipeline_config as cfg  # noqa: E402
import model_promotion_lib as mpl  # noqa: E402

RUNS_DIR = SCRIPT_DIR.parent / "yolo" / "runs_physical"
HISTORY_PATH = RUNS_DIR / "PHYSICAL_RUN_HISTORY.csv"
CLASS_METRICS_PATH = RUNS_DIR / "PHYSICAL_CLASS_METRICS_HISTORY.csv"
REPORTS_DIR = paths.reports_dir()
COMMUNITY_BOARD_CACHE_PATH = paths.community_districts_geojson()
TRAIN_DIR = paths.dataset_dir("yolo_dataset_physical") / "images" / "train"
VAL_DIR = paths.dataset_dir("yolo_dataset_physical") / "images" / "val"
TRAIN_LABELS_DIR = paths.dataset_dir("yolo_dataset_physical") / "labels" / "train"
VAL_LABELS_DIR = paths.dataset_dir("yolo_dataset_physical") / "labels" / "val"
CONF_THRESHOLD = cfg.CONF_THRESHOLD  # default 0.25 -- see .env's PHYSICAL_CONF_THRESHOLD
N_SAMPLES = 6


def latest_run_name():
    runs = sorted(
        (d for d in RUNS_DIR.iterdir() if (d / "weights" / "best.pt").exists()),
        key=lambda d: d.stat().st_mtime,
    ) if RUNS_DIR.exists() else []
    if not runs:
        raise SystemExit(f"No trained run found under {RUNS_DIR}. Run the Training section first.")
    return runs[-1].name


def resolve_production_physical_weights():
    """(weights_path, run_name) for real physical inference -- the
    explicitly promoted run (see model_promotion_lib.promote /
    promote_model_run.py) if one exists and its weights are still on
    disk, else the existing mtime-latest scan under RUNS_DIR (unchanged
    behavior for anyone who's never promoted a run)."""
    weights, run_name = mpl.resolve_promoted_weights("physical", RUNS_DIR)
    if weights is not None:
        return weights, run_name
    run_name = latest_run_name()
    return RUNS_DIR / run_name / "weights" / "best.pt", run_name


# OTI: Stages 5, 9, 11: the model's verdict on one image.
def predict_image(model, image_path):
    """Returns list of (class_name, confidence) for one image."""
    # >>> OTI CORE: the model's verdict on one sign -----------------------------
    # Every box the model draws at 25% confidence or more (Ultralytics'
    # default), most confident first. The notebook reads it as: no boxes =
    # no damage; otherwise the top box's class is the damage type.
    result = model(str(image_path), verbose=False)[0]
    return [
        (result.names[int(c)], float(conf))
        for c, conf in zip(result.boxes.cls.tolist(), result.boxes.conf.tolist())
    ]
    # <<< OTI CORE end ---------------------------------------------------------


def annotated_image_b64(model, image_path):
    result = model(str(image_path), verbose=False)[0]
    annotated = result.plot()
    ok, buf = cv2.imencode(".jpg", annotated)
    return lib.encode_image_base64(buf.tobytes())


def load_run_metrics(run_name):
    if not HISTORY_PATH.exists():
        return None
    with open(HISTORY_PATH, newline="", encoding="utf-8") as f:
        matches = [r for r in csv.DictReader(f) if r["run_name"] == run_name]
    return matches[-1] if matches else None


def build_records(model, image_paths, rows_by_filename, cb_index=None):
    records = []
    for image_path in image_paths:
        row = rows_by_filename.get(Path(image_path).name)
        if row is None:
            continue
        predictions = predict_image(model, image_path)
        record = lib.build_shapefile_record(row, predictions, threshold=CONF_THRESHOLD, cb_index=cb_index)
        if record is not None:
            records.append(record)
    return records


def build_samples(model, image_paths, rows_by_filename):
    """Builds the report's sample-detection entries: one dict per image
    with keys annotated_b64, predicted, human, filename. Consumed by
    physical_report_lib.render_report_html's `samples` context key."""
    samples = []
    for image_path in image_paths:
        row = rows_by_filename.get(image_path.name, {})
        predictions = predict_image(model, image_path)
        pred_str = ", ".join(f"{n}:{c:.2f}" for n, c in predictions) or "(no detections)"
        samples.append({
            "annotated_b64": annotated_image_b64(model, image_path),
            "predicted": pred_str,
            "human": row.get("damage_category", ""),
            "filename": image_path.name,
        })
    return samples


def dir_search_thumbnail_fn(model, image_dirs):
    """Default thumbnail_fn for build_interactive_map_html: searches
    image_dirs (in order) for a file matching the record's filename, then
    re-runs model on it and returns an annotated-detection JPEG (boxes
    drawn) as base64 -- the original behavior, factored out so a caller
    with a different source of thumbnails (e.g. run_automatic_inference.py,
    which already has each detection's own tight-crop file on disk, keyed
    by (corner_id, box_index) rather than a directory-searchable filename)
    can pass its own thumbnail_fn instead without duplicating the rest of
    this map-building function."""
    def thumbnail_fn(record):
        for d in image_dirs:
            candidate = Path(d) / record["filename"]
            if candidate.exists():
                return annotated_image_b64(model, candidate)
        return None
    return thumbnail_fn


def build_interactive_map_html(records, thumbnail_fn):
    """Thin wrapper over lib.build_default_map."""
    return lib.build_default_map(
        records, thumbnail_fn, lib.PHYSICAL_CLASS_COLORS,
        community_board_geojson_path=COMMUNITY_BOARD_CACHE_PATH,
    )


def main(run_name=None):
    run_name = run_name or resolve_production_physical_weights()[1]
    model_path = RUNS_DIR / run_name / "weights" / "best.pt"
    if not model_path.exists():
        raise SystemExit(f"No trained model at {model_path}.")

    print(f"Loading model from {model_path}")
    model = YOLO(str(model_path))

    rows_by_filename = lib.load_manifest_rows_by_filename()

    print(f"Loading Community Board boundaries (cache: {COMMUNITY_BOARD_CACHE_PATH})...")
    cb_index = cbl.load_community_board_index(COMMUNITY_BOARD_CACHE_PATH)
    if not cb_index:
        print(f"WARNING: Community Board index is empty; comm_board will be blank for every record. Check {COMMUNITY_BOARD_CACHE_PATH}.")

    val_images = sorted(VAL_DIR.glob("*.jpg"))
    train_images = sorted(TRAIN_DIR.glob("*.jpg"))
    all_images = train_images + val_images

    print(f"Running inference on {len(val_images)} val image(s)...")
    val_records = build_records(model, val_images, rows_by_filename, cb_index=cb_index)
    print(f"Running inference on {len(all_images)} total image(s)...")
    all_records = build_records(model, all_images, rows_by_filename, cb_index=cb_index)

    print("Building interactive map...")
    map_doc_html = build_interactive_map_html(all_records, dir_search_thumbnail_fn(model, [TRAIN_DIR, VAL_DIR]))

    metrics = load_run_metrics(run_name) or {}
    class_counts_by_split = lib.count_classes_by_split(TRAIN_LABELS_DIR, VAL_LABELS_DIR, lib.PHYSICAL_CLASS_NAMES)
    class_metrics = lib.load_class_metrics_last_two_runs(CLASS_METRICS_PATH)

    sample_paths = lib.select_diverse_sample_paths(val_images, rows_by_filename, N_SAMPLES)
    samples = build_samples(model, sample_paths, rows_by_filename)

    history_rows = []
    if HISTORY_PATH.exists():
        with open(HISTORY_PATH, newline="", encoding="utf-8") as f:
            history_rows = list(csv.DictReader(f))

    context = {
        "run_name": run_name,
        "run_date": metrics.get("date", datetime.now().strftime("%Y-%m-%d")),
        "metrics": metrics,
        "class_counts_by_split": class_counts_by_split,
        "class_metrics": class_metrics,
        "map_doc_html": map_doc_html,
        "history_chart_b64": lib.render_history_chart_base64(history_rows) if history_rows else "",
        "samples": samples,
        "flagged_count_val": len(val_records),
        "flagged_count_all": len(all_records),
    }

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    html_path = REPORTS_DIR / f"physical_condition_{run_name}.html"
    html_path.write_text(lib.render_report_html(context), encoding="utf-8")
    print(f"Report written to {html_path}")

    lib.write_shapefile(val_records, REPORTS_DIR / f"physical_condition_val_{run_name}.shp")
    lib.write_shapefile(all_records, REPORTS_DIR / f"physical_condition_all_{run_name}.shp")
    print(f"Shapefiles written to {REPORTS_DIR}")

    print("Building actionable report...")
    actionable_html = lib.build_actionable_report_html(all_records, map_doc_html, run_name)
    actionable_path = REPORTS_DIR / f"actionable_report_{run_name}.html"
    actionable_path.write_text(actionable_html, encoding="utf-8")
    print(f"Actionable report written to {actionable_path}")


if __name__ == "__main__":
    paths.require_data_dir()
    main(sys.argv[1] if len(sys.argv) > 1 else None)
