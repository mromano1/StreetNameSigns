Running the hands-on notebook on a Mac
======================================

What you need
-------------
  - A Mac with Apple Silicon (M1 or newer, 2020 onward). Intel Macs can't
    install the versions of PyTorch and OpenCV this package uses.
  - Python 3.11 or newer. If you don't have it, install Python 3.13 from
    https://www.python.org/downloads/macos/ (the default options are fine).
  - Internet for the one-time setup (it downloads about 1 GB), and about
    3 GB of free disk space.

Steps
-----
1. Unzip the package if you haven't (double-click the .zip in Finder).
2. In the package's mac folder, double-click setup.command (one time).
   A Terminal window opens and installs everything into a private .venv
   folder inside the package. Nothing else on your Mac is changed.
3. Optional: add your Cyclomedia keys to .env (see below). Blank keys are
   fine; the notebook uses the bundled image pools instead.
4. Double-click start_notebook.command. Jupyter's file browser opens in your
   browser; click oti-streetNameSign-walkthrough.ipynb and run the cells top
   to bottom (Shift+Return). Keep the Terminal window open while you work.

If macOS won't open the .command files
--------------------------------------
Macs block scripts downloaded from the internet that aren't from an
identified developer. Either:
  - Right-click (or Control-click) the file, choose Open, then Open again.
    On macOS 15 or newer, if that isn't offered: try to open it once, then
    go to System Settings > Privacy & Security and click "Open Anyway".
  - Or open Terminal (Applications > Utilities), type  bash  and a space,
    drag the .command file into the Terminal window, and press Return.
    This always works.

Editing .env
------------
Files whose names start with a dot are hidden in Finder. In the package
folder, press Command+Shift+. (period) to show them, then right-click .env >
Open With > TextEdit. Press Command+Shift+. again to hide them.

The notebook's instructions mention setup.bat, Notepad and backslash paths
like data\demo_output\. Those are the Windows names; on a Mac use the files
in this folder, TextEdit, and forward slashes (data/demo_output/).
