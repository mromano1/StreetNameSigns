# Sets PY to the first Python 3.11+ it finds, newest first. Sourced by
# setup.command, which builds the package's own .venv from it. Plain
# "python3" is tried last: on a Mac without developer tools it's Apple's old
# 3.9 (or a stub that pops up an install dialog).
# 3.11 is the oldest Python the pinned packages in requirements.txt install on.
export PATH="/opt/homebrew/bin:/usr/local/bin:/Library/Frameworks/Python.framework/Versions/Current/bin:$PATH"
PY=""
for candidate in python3.14 python3.13 python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1 &&
        "$candidate" -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >/dev/null 2>&1; then
        PY="$candidate"
        break
    fi
done
