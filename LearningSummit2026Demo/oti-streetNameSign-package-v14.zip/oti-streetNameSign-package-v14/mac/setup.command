#!/bin/bash
# One-time setup for the hands-on notebook on a Mac (the Mac version of setup.bat):
#   1. makes a private Python environment in the package folder (.venv), so
#      nothing is installed into, or changed in, the Python already on this Mac
#   2. installs the pinned packages in requirements.txt into .venv
#   3. creates .env from .env.example (only if .env doesn't exist yet)
# Safe to run again; it reuses .venv and never overwrites an existing .env.
# To start completely fresh, delete the .venv folder and run this again.

finish() {
    echo
    read -r -p "Press Return to close this window. "
    exit "$1"
}

cd "$(dirname "$0")/.." || finish 1
VENV_PY=".venv/bin/python"

if [ ! -x "$VENV_PY" ]; then
    source mac/find_python.sh
    if [ -z "$PY" ]; then
        echo "No Python 3.11 or newer was found. Install Python 3.13 from"
        echo "https://www.python.org/downloads/macos/ and run this file again."
        finish 1
    fi
    echo "Making a private Python environment in .venv using:"
    "$PY" --version
    "$PY" -m venv .venv || { echo "Couldn't create .venv. Scroll up for the error."; finish 1; }
fi

if ! "$VENV_PY" -c "import sys" >/dev/null 2>&1; then
    echo "The .venv folder is broken, probably because the Python it was made from"
    echo "was removed or updated. Delete the .venv folder, then run setup again."
    finish 1
fi

echo "Installing Python packages into .venv (this can take several minutes the first time)..."
"$VENV_PY" -m pip install --upgrade pip
if ! "$VENV_PY" -m pip install -r requirements.txt; then
    echo
    echo "pip install failed. Scroll up for the error, fix it, and run setup again."
    finish 1
fi

if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env from .env.example. To add Cyclomedia keys, see mac/README_MAC.txt."
else
    echo ".env already exists, left as is."
fi

echo
echo "Setup done. Double-click start_notebook.command (in the mac folder) to open the notebook."
finish 0
