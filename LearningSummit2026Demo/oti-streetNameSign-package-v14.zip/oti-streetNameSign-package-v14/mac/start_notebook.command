#!/bin/bash
# Opens Jupyter's file browser on the package folder (the Mac version of
# start_notebook.bat). Run setup.command once first.
# Keep this Terminal window open while you work; closing it stops the notebook.

cd "$(dirname "$0")/.." || exit 1
VENV_PY=".venv/bin/python"

if [ ! -x "$VENV_PY" ]; then
    echo "The notebook isn't set up yet. Double-click setup.command first."
    read -r -p "Press Return to close this window. "
    exit 1
fi

# Use .venv's own Python kernel even if this Mac has another kernel named
# python3 registered for the user.
export JUPYTER_PREFER_ENV_PATH=1
if ! "$VENV_PY" -m notebook; then
    echo
    echo "Jupyter didn't start. Run setup.command again, then try again."
    read -r -p "Press Return to close this window. "
fi
