Street Sign Damage Detection -- hands-on notebook
==================================================

On a Mac? Open the mac folder and follow README_MAC.txt instead.

What you need
-------------
  - Windows 10 or 11. No graphics card needed; training runs on the CPU.
  - Python 3.11 or newer. If you don't have it, install Python 3.13 from
    https://www.python.org/downloads/ and tick "Add python.exe to PATH".
  - Internet for the one-time setup (it downloads about 1 GB), and about
    3 GB of free disk space.
  - The package unzipped to a normal folder (not opened inside the zip).
    If setup says the folder path is too long, move the folder somewhere
    shorter, like C:\oti-streetNameSign.

Steps
-----
1. Double-click setup.bat (one time). It makes a private Python environment
   in a .venv folder inside this package, installs the packages there, and
   creates .env. Nothing is installed into the Python already on your computer.
2. Optional: open .env in Notepad and add your Cyclomedia keys. Blank keys
   are fine; the notebook uses the bundled image pools instead.
3. Double-click start_notebook.bat. Jupyter's file browser opens in your browser;
   click oti-streetNameSign-walkthrough.ipynb to start (the scripts folder has the code).
   Run the cells top to bottom (Shift+Enter).

While the notebook runs, Stage 1 (the sign catalogue) and the maps' street
background need internet. Without it, Stage 1 says so and the rest still runs.

What's in this folder
---------------------
  oti-streetNameSign-walkthrough.ipynb  the notebook
  .env / .env.example            settings: keys, community board, damage types, training size
  MAKE_IT_YOUR_OWN.html          how to reuse this notebook for your own YOLO project
  tag_folders\                   stand-alone kit: folders of images -> label CSV -> YOLO dataset
  .venv\                         the private Python environment setup.bat makes
  mac\                           setup and start files for Macs
  reports\                       every report the notebook writes lands here
                                 (model report HTML + broken-signs CSV)
  scripts\                       the real pipeline scripts the notebook calls
                                 (search a script for OTI CORE to jump to its key parts)
  data\pretagged_pool\           22 labeled sign images (training starts here)
  data\untagged_pool\            14 unlabeled sign images (you label these in Stage 6)
  data\earlier_training\         40 images the starting model already learned from
  data\teammate_batches\         60 images a teammate labeled (30 per training round)
  data\control_set\              33 test images every model is scored on
  data\demo_output\              scratch files the notebook writes
  yolo\                          the starting model + your training runs
