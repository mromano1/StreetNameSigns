@echo off
rem Sets PY to the first Python 3.11+ it finds, trying "python" first, then the
rem py launcher's newest 3.x versions. Called by setup.bat, which builds the
rem package's own .venv from it. (The py launcher's plain "py -3" can pick an
rem old install, so it's not used.) 3.11 is the oldest Python the pinned
rem packages in requirements.txt install on.
set "PY="
for %%C in ("python" "py -3.14" "py -3.13" "py -3.12" "py -3.11") do (
    if not defined PY (
        %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul && set "PY=%%~C"
    )
)
