@echo off
rem One-time setup for the hands-on notebook:
rem   1. makes a private Python environment in this folder (.venv), so nothing
rem      is installed into, or changed in, the Python already on this computer
rem   2. installs the pinned packages in requirements.txt into .venv
rem   3. creates .env from .env.example (only if .env doesn't exist yet)
rem Safe to run again; it reuses .venv and never overwrites an existing .env.
rem To start completely fresh, delete the .venv folder and run this again.
setlocal
cd /d "%~dp0"
set "VENV_PY=%~dp0.venv\Scripts\python.exe"

if not exist "%VENV_PY%" (
    call "%~dp0find_python.bat"
    if not defined PY (
        echo No Python 3.11 or newer was found. Install Python 3.13 from https://www.python.org/downloads/
        echo and tick "Add python.exe to PATH" during install, then run this file again.
        pause
        exit /b 1
    )
)

if not exist "%VENV_PY%" (
    rem Some installed files are long; Windows refuses paths over 260 characters
    rem unless long paths are turned on, and pip's error for that is cryptic.
    %PY% -c "import os, sys, winreg; k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\FileSystem'); on = winreg.QueryValueEx(k, 'LongPathsEnabled')[0] == 1; sys.exit(0 if on or len(os.getcwd()) <= 90 else 1)" >nul 2>nul
    if errorlevel 1 (
        echo This folder's path is too long for Windows to install into:
        echo   %CD%
        echo Move the whole folder somewhere shorter, for example C:\oti-streetNameSign,
        echo then run setup.bat again from there.
        pause
        exit /b 1
    )
    echo Making a private Python environment in .venv using:
    %PY% --version
    %PY% -m venv .venv
    if not exist "%VENV_PY%" (
        echo.
        echo Couldn't create .venv. Scroll up for the error.
        pause
        exit /b 1
    )
)

"%VENV_PY%" -c "import sys" >nul 2>nul
if errorlevel 1 (
    echo The .venv folder is broken, probably because the Python it was made from
    echo was removed or updated. Delete the .venv folder, then run setup.bat again.
    pause
    exit /b 1
)

echo Installing Python packages into .venv (this can take several minutes the first time)...
"%VENV_PY%" -m pip install --upgrade pip
"%VENV_PY%" -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo pip install failed. Scroll up for the error, fix it, and run setup.bat again.
    pause
    exit /b 1
)

if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo Created .env from .env.example. Open it in Notepad to add Cyclomedia keys if you have them.
) else (
    echo .env already exists, left as is.
)

echo.
echo Setup done. Double-click start_notebook.bat to open the notebook.
pause
